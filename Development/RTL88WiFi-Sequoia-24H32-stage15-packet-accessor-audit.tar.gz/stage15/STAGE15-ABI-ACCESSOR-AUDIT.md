# Stage 15 — generic Skywalk packet-access ABI audit

**Status:** PASS

- Input archive: `RTL88WiFi-Sequoia-24H32-stage14-generic-skywalk-segment-packet-kcabi.tar.gz`
- Input SHA-256: `0c86675b0a9e3dd3d5e41aa626c2fe1f4b9915450f5af7bbc808e8e9e595ba3a`
- Platform: `macOS 15.8.1 (24H32), x86_64`
- Demangler: `/usr/bin/c++filt`
- Method lists: 8 / 8 classes
- Required accessor methods with disassembly: 18 / 18

## Method-list inventory

- `IOSkywalkPacketQueue`: 67 exact symbols
- `IOSkywalkPacketBufferPool`: 74 exact symbols
- `IOSkywalkQueueSet`: 32 exact symbols
- `IOSkywalkLogicalLink`: 28 exact symbols
- `IOSkywalkMemorySegment`: 31 exact symbols
- `IOSkywalkPacketBuffer`: 50 exact symbols
- `IOSkywalkPacket`: 59 exact symbols
- `IOSkywalkNetworkPacket`: 69 exact symbols

## Required driver-call audit

| Class | Method | Result | Matched symbols |
|---|---|---:|---|
| `IOSkywalkPacket` | `getPacketType` | **PASS** | `__ZNK15IOSkywalkPacket13getPacketTypeEv` |
| `IOSkywalkPacket` | `getPacketBufferPool` | **PASS** | `__ZNK15IOSkywalkPacket19getPacketBufferPoolEv` |
| `IOSkywalkPacket` | `getPacketBufferCount` | **PASS** | `__ZNK15IOSkywalkPacket20getPacketBufferCountEv` |
| `IOSkywalkPacket` | `getPacketBuffers` | **PASS** | `__ZNK15IOSkywalkPacket16getPacketBuffersEPP21IOSkywalkPacketBufferj` |
| `IOSkywalkPacket` | `getDataOffset` | **PASS** | `__ZNK15IOSkywalkPacket13getDataOffsetEv` |
| `IOSkywalkPacket` | `getDataLength` | **PASS** | `__ZNK15IOSkywalkPacket13getDataLengthEv` |
| `IOSkywalkPacket` | `setDataOffsetAndLength` | **PASS** | `__ZN15IOSkywalkPacket22setDataOffsetAndLengthEtj` |
| `IOSkywalkPacketBufferPool` | `allocatePacket` | **PASS** | `__ZN25IOSkywalkPacketBufferPool14allocatePacketEPP15IOSkywalkPacketj`, `__ZN25IOSkywalkPacketBufferPool14allocatePacketEjPP15IOSkywalkPacketj` |
| `IOSkywalkPacketBufferPool` | `deallocatePacket` | **PASS** | `__ZN25IOSkywalkPacketBufferPool16deallocatePacketEP15IOSkywalkPacket` |
| `IOSkywalkPacketBuffer` | `getPacketBufferPool` | **PASS** | `__ZNK21IOSkywalkPacketBuffer19getPacketBufferPoolEv` |
| `IOSkywalkPacketBuffer` | `getMemorySegment` | **PASS** | `__ZNK21IOSkywalkPacketBuffer16getMemorySegmentEv` |
| `IOSkywalkPacketBuffer` | `getMemorySegmentOffset` | **PASS** | `__ZNK21IOSkywalkPacketBuffer22getMemorySegmentOffsetEv` |
| `IOSkywalkPacketBuffer` | `getBufferSize` | **PASS** | `__ZNK21IOSkywalkPacketBuffer13getBufferSizeEv` |
| `IOSkywalkPacketBuffer` | `getDataOffset` | **PASS** | `__ZNK21IOSkywalkPacketBuffer13getDataOffsetEv` |
| `IOSkywalkPacketBuffer` | `getDataLength` | **PASS** | `__ZNK21IOSkywalkPacketBuffer13getDataLengthEv` |
| `IOSkywalkMemorySegment` | `getMemoryDescriptor` | **PASS** | `__ZNK22IOSkywalkMemorySegment19getMemoryDescriptorEv` |
| `IOSkywalkMemorySegment` | `getVirtualAddress` | **PASS** | `__ZNK22IOSkywalkMemorySegment17getVirtualAddressEv` |
| `IOSkywalkNetworkPacket` | `setCompletionStatus` | **PASS** | `__ZN22IOSkywalkNetworkPacket19setCompletionStatusEi` |

## Interpretation and safety boundary

A PASS means the exact method name was present in the matching class method list and at least one corresponding disassembly reference was collected. It does not prove argument semantics, locking rules, packet ownership transitions, mapping lifetime, or that calling the method from a callback is safe.

This stage is read-only. It does not alter Kext source, register queues, enable TX/RX callbacks, publish an interface, or start the radio.
