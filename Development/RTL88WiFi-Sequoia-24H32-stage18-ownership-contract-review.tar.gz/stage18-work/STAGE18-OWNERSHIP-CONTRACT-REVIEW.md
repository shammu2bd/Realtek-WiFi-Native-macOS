# Stage 18 — RX/TX ownership contract review dossier

**Status:** READY_FOR_MANUAL_REVIEW

This stage collects evidence for manual review. It does not infer ownership from names and does not authorize datapath activation.

## Verified inputs

- Stage 14: `0c86675b0a9e3dd3d5e41aa626c2fe1f4b9915450f5af7bbc808e8e9e595ba3a`
- Stage 15: `e132214d113fac85f0911d98de017a531a6df8406b535a1b7e9dad48d72f8e38`
- Stage 16: `183e1f6568f7e7f1eaad0e407833c1c5f8334c16ecf6bdeeecb016bf2268cc3d`
- Stage 17: `24f5b5869fae1e3ad7e9a23c26f99d53e085ca36bfe9c63644ff293dce281239`
- Kernel collection: `cd013c14a7f21dbb8181fb06c44e079de8646b6a674abe21f6e47f42e8979af3`

- Stage 17 all class symbols: 782
- Stage 17 executable bodies: 743/743
- Stage 17 non-code symbols excluded: 39
- Stage 17 source checks: 19/19
- Exact method bodies copied into this dossier: 743

## rx_completion_enqueue: RX completion enqueue ownership and callback packet-array semantics

**Status:** MANUAL_REVIEW_REQUIRED
**Candidate method bodies:** 255

### Kernel method candidates

| Class | Address | Instructions | Exact symbol | Assembly file |
|---|---:|---:|---|---|
| `IOSkywalkRxCompletionQueue` | `0xffffff80029863e0` | 54 | `__ZN26IOSkywalkRxCompletionQueue8withPoolEP25IOSkywalkPacketBufferPooljjP8OSObjectPFjS3_PS_PP15IOSkywalkPacketjPvES8_j` | `asm/ZN26IOSkywalkRxCompletionQueue8withPoolEP25IOSkywalkPacketBufferPooljjP8OSObjectPFjS3_PS_PP15IOSkywalkPacketjPvES8_j.asm.txt` |
| `IOSkywalkRxCompletionQueue` | `0xffffff800298648a` | 50 | `__ZN26IOSkywalkRxCompletionQueue12initWithPoolEP25IOSkywalkPacketBufferPooljjP8OSObjectPFjS3_PS_PP15IOSkywalkPacketjPvES8_j` | `asm/ZN26IOSkywalkRxCompletionQueue12initWithPoolEP25IOSkywalkPacketBufferPooljjP8OSObjectPFjS3_PS_PP15IOSkywalkPacketjPvES8_j.asm.txt` |
| `IOSkywalkRxCompletionQueue` | `0xffffff80029865bc` | 30 | `__ZN26IOSkywalkRxCompletionQueue6enableEv` | `asm/ZN26IOSkywalkRxCompletionQueue6enableEv.asm.txt` |
| `IOSkywalkRxCompletionQueue` | `0xffffff800298661c` | 23 | `__ZN26IOSkywalkRxCompletionQueue7disableEv` | `asm/ZN26IOSkywalkRxCompletionQueue7disableEv.asm.txt` |
| `IOSkywalkRxCompletionQueue` | `0xffffff8002986748` | 104 | `__ZN26IOSkywalkRxCompletionQueue11synchronizeEj` | `asm/ZN26IOSkywalkRxCompletionQueue11synchronizeEj.asm.txt` |
| `IOSkywalkRxCompletionQueue` | `0xffffff80029868d0` | 25 | `__ZN26IOSkywalkRxCompletionQueue15setPacketPollerEP21IOSkywalkPacketPoller` | `asm/ZN26IOSkywalkRxCompletionQueue15setPacketPollerEP21IOSkywalkPacketPoller.asm.txt` |
| `IOSkywalkRxCompletionQueue` | `0xffffff8002986918` | 91 | `__ZN26IOSkywalkRxCompletionQueue27enqueuePacketsForNetworkingEPKP15IOSkywalkPacketjj` | `asm/ZN26IOSkywalkRxCompletionQueue27enqueuePacketsForNetworkingEPKP15IOSkywalkPacketjj.asm.txt` |
| `IOSkywalkRxCompletionQueue` | `0xffffff8002986a5a` | 65 | `__ZN26IOSkywalkRxCompletionQueue22enqueuePacketsForKPipeEPKP15IOSkywalkPacketjj` | `asm/ZN26IOSkywalkRxCompletionQueue22enqueuePacketsForKPipeEPKP15IOSkywalkPacketjj.asm.txt` |
| `IOSkywalkRxCompletionQueue` | `0xffffff8002986bc6` | 84 | `__ZN26IOSkywalkRxCompletionQueue12addReportersEP9IOServiceP5OSSet` | `asm/ZN26IOSkywalkRxCompletionQueue12addReportersEP9IOServiceP5OSSet.asm.txt` |
| `IOSkywalkRxCompletionQueue` | `0xffffff80029a34e6` | 96 | `__ZN26IOSkywalkRxCompletionQueue12gatedEnqueueEPv` | `asm/ZN26IOSkywalkRxCompletionQueue12gatedEnqueueEPv.asm.txt` |
| `IOSkywalkRxCompletionQueue` | `0xffffff80029a3628` | 43 | `__ZN26IOSkywalkRxCompletionQueue14requestEnqueueEPvj` | `asm/ZN26IOSkywalkRxCompletionQueue14requestEnqueueEPvj.asm.txt` |
| `IOSkywalkRxCompletionQueue` | `0xffffff80029a36b6` | 54 | `__ZN26IOSkywalkRxCompletionQueue14enqueuePacketsEPKP15IOSkywalkPacketjj` | `asm/ZN26IOSkywalkRxCompletionQueue14enqueuePacketsEPKP15IOSkywalkPacketjj.asm.txt` |
| `IOSkywalkRxCompletionQueue` | `0xffffff80029a3760` | 117 | `__ZN26IOSkywalkRxCompletionQueue14enqueuePacketsEP15IOSkywalkPacketjj` | `asm/ZN26IOSkywalkRxCompletionQueue14enqueuePacketsEP15IOSkywalkPacketjj.asm.txt` |
| `IOSkywalkRxCompletionQueue` | `0xffffff80029a390e` | 18 | `__ZNK26IOSkywalkRxCompletionQueue14getPacketCountEv` | `asm/ZNK26IOSkywalkRxCompletionQueue14getPacketCountEv.asm.txt` |
| `IOSkywalkRxCompletionQueue` | `0xffffff80029a3982` | 15 | `__ZN26IOSkywalkRxCompletionQueue11synchronizeEj.cold.1` | `asm/ZN26IOSkywalkRxCompletionQueue11synchronizeEj.cold.1.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297ee1e` | 15 | `__ZN22IOSkywalkNetworkPacket9MetaClassC1Ev` | `asm/ZN22IOSkywalkNetworkPacket9MetaClassC1Ev.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297ee50` | 4 | `__ZN22IOSkywalkNetworkPacket9MetaClassD1Ev` | `asm/ZN22IOSkywalkNetworkPacket9MetaClassD1Ev.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297ee5a` | 13 | `__ZN22IOSkywalkNetworkPacketC2EPK11OSMetaClass` | `asm/ZN22IOSkywalkNetworkPacketC2EPK11OSMetaClass.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297ee7a` | 13 | `__ZN22IOSkywalkNetworkPacketC1EPK11OSMetaClass` | `asm/ZN22IOSkywalkNetworkPacketC1EPK11OSMetaClass.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297ee9a` | 4 | `__ZN22IOSkywalkNetworkPacketD2Ev` | `asm/ZN22IOSkywalkNetworkPacketD2Ev.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297eea4` | 4 | `__ZN22IOSkywalkNetworkPacketD1Ev` | `asm/ZN22IOSkywalkNetworkPacketD1Ev.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297eeae` | 13 | `__ZN22IOSkywalkNetworkPacketD0Ev` | `asm/ZN22IOSkywalkNetworkPacketD0Ev.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297eed6` | 8 | `__ZN22IOSkywalkNetworkPacketdlEPvm` | `asm/ZN22IOSkywalkNetworkPacketdlEPvm.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297eeee` | 6 | `__ZNK22IOSkywalkNetworkPacket12getMetaClassEv` | `asm/ZNK22IOSkywalkNetworkPacket12getMetaClassEv.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297eefc` | 15 | `__ZN22IOSkywalkNetworkPacket9MetaClassC2Ev` | `asm/ZN22IOSkywalkNetworkPacket9MetaClassC2Ev.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297ef2e` | 22 | `__ZNK22IOSkywalkNetworkPacket9MetaClass5allocEv` | `asm/ZNK22IOSkywalkNetworkPacket9MetaClass5allocEv.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297ef76` | 6 | `__ZN22IOSkywalkNetworkPacketnwEm` | `asm/ZN22IOSkywalkNetworkPacketnwEm.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297ef8a` | 16 | `__ZN22IOSkywalkNetworkPacketC1Ev` | `asm/ZN22IOSkywalkNetworkPacketC1Ev.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297efba` | 16 | `__ZN22IOSkywalkNetworkPacketC2Ev` | `asm/ZN22IOSkywalkNetworkPacketC2Ev.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297efea` | 45 | `__ZN22IOSkywalkNetworkPacket8withPoolEP25IOSkywalkPacketBufferPoolP25IOSkywalkPacketDescriptorj` | `asm/ZN22IOSkywalkNetworkPacket8withPoolEP25IOSkywalkPacketBufferPoolP25IOSkywalkPacketDescriptorj.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297f070` | 10 | `__ZN22IOSkywalkNetworkPacket11setHeadroomEh` | `asm/ZN22IOSkywalkNetworkPacket11setHeadroomEh.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297f08a` | 5 | `__ZNK22IOSkywalkNetworkPacket11getHeadroomEv` | `asm/ZNK22IOSkywalkNetworkPacket11getHeadroomEv.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297f098` | 10 | `__ZN22IOSkywalkNetworkPacket19setLinkHeaderLengthEh` | `asm/ZN22IOSkywalkNetworkPacket19setLinkHeaderLengthEh.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297f0b2` | 5 | `__ZNK22IOSkywalkNetworkPacket19getLinkHeaderLengthEv` | `asm/ZNK22IOSkywalkNetworkPacket19getLinkHeaderLengthEv.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297f0c0` | 14 | `__ZN22IOSkywalkNetworkPacket19setLinkHeaderOffsetEj` | `asm/ZN22IOSkywalkNetworkPacket19setLinkHeaderOffsetEj.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297f0ec` | 19 | `__ZNK22IOSkywalkNetworkPacket19getLinkHeaderOffsetEPj` | `asm/ZNK22IOSkywalkNetworkPacket19getLinkHeaderOffsetEPj.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297f118` | 14 | `__ZN22IOSkywalkNetworkPacket22setNetworkHeaderOffsetEj` | `asm/ZN22IOSkywalkNetworkPacket22setNetworkHeaderOffsetEj.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297f144` | 19 | `__ZNK22IOSkywalkNetworkPacket22getNetworkHeaderOffsetEPj` | `asm/ZNK22IOSkywalkNetworkPacket22getNetworkHeaderOffsetEPj.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297f170` | 5 | `__ZNK22IOSkywalkNetworkPacket15getServiceClassEv` | `asm/ZNK22IOSkywalkNetworkPacket15getServiceClassEv.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297f17e` | 8 | `__ZNK22IOSkywalkNetworkPacket14isHighPriorityEv` | `asm/ZNK22IOSkywalkNetworkPacket14isHighPriorityEv.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297f192` | 6 | `__ZNK22IOSkywalkNetworkPacket13getPacketTypeEv` | `asm/ZNK22IOSkywalkNetworkPacket13getPacketTypeEv.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297f19e` | 5 | `__ZN22IOSkywalkNetworkPacket11setWakeFlagEv` | `asm/ZN22IOSkywalkNetworkPacket11setWakeFlagEv.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297f1ac` | 5 | `__ZNK22IOSkywalkNetworkPacket9isPureAckEv` | `asm/ZNK22IOSkywalkNetworkPacket9isPureAckEv.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297f1b4` | 14 | `__ZNK22IOSkywalkNetworkPacket29getCompressionGenerationCountEPj` | `asm/ZNK22IOSkywalkNetworkPacket29getCompressionGenerationCountEPj.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297f1da` | 13 | `__ZN22IOSkywalkNetworkPacket18setDataContainsFCSEb` | `asm/ZN22IOSkywalkNetworkPacket18setDataContainsFCSEb.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297f1fe` | 8 | `__ZNK22IOSkywalkNetworkPacket18getDataContainsFCSEv` | `asm/ZNK22IOSkywalkNetworkPacket18getDataContainsFCSEv.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297f212` | 8 | `__ZNK22IOSkywalkNetworkPacket18isTransportNewFlowEv` | `asm/ZNK22IOSkywalkNetworkPacket18isTransportNewFlowEv.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297f226` | 8 | `__ZNK22IOSkywalkNetworkPacket21isTransportLastPacketEv` | `asm/ZNK22IOSkywalkNetworkPacket21isTransportLastPacketEv.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297f23a` | 8 | `__ZNK22IOSkywalkNetworkPacket28isTransportTrafficBackgroundEv` | `asm/ZNK22IOSkywalkNetworkPacket28isTransportTrafficBackgroundEv.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297f24e` | 8 | `__ZNK22IOSkywalkNetworkPacket26isTransportTrafficRealtimeEv` | `asm/ZNK22IOSkywalkNetworkPacket26isTransportTrafficRealtimeEv.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297f262` | 10 | `__ZN22IOSkywalkNetworkPacket18setIsLinkBroadcastEb` | `asm/ZN22IOSkywalkNetworkPacket18setIsLinkBroadcastEb.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297f27c` | 8 | `__ZNK22IOSkywalkNetworkPacket15isLinkBroadcastEv` | `asm/ZNK22IOSkywalkNetworkPacket15isLinkBroadcastEv.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297f290` | 10 | `__ZN22IOSkywalkNetworkPacket18setIsLinkMulticastEb` | `asm/ZN22IOSkywalkNetworkPacket18setIsLinkMulticastEb.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297f2aa` | 8 | `__ZNK22IOSkywalkNetworkPacket15isLinkMulticastEv` | `asm/ZNK22IOSkywalkNetworkPacket15isLinkMulticastEv.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297f2be` | 24 | `__ZNK22IOSkywalkNetworkPacket12getTimestampEPy` | `asm/ZNK22IOSkywalkNetworkPacket12getTimestampEPy.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297f302` | 10 | `__ZN22IOSkywalkNetworkPacket12setTimestampEy` | `asm/ZN22IOSkywalkNetworkPacket12setTimestampEy.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297f320` | 12 | `__ZN22IOSkywalkNetworkPacket14clearTimestampEv` | `asm/ZN22IOSkywalkNetworkPacket14clearTimestampEv.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297f33e` | 18 | `__ZNK22IOSkywalkNetworkPacket20isTimestampRequestedEv` | `asm/ZNK22IOSkywalkNetworkPacket20isTimestampRequestedEv.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297f36c` | 10 | `__ZN22IOSkywalkNetworkPacket19setCompletionStatusEi` | `asm/ZN22IOSkywalkNetworkPacket19setCompletionStatusEi.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297f386` | 17 | `__ZNK22IOSkywalkNetworkPacket13getExpiryTimeEPy` | `asm/ZNK22IOSkywalkNetworkPacket13getExpiryTimeEPy.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297f3b6` | 29 | `__ZNK22IOSkywalkNetworkPacket15getExpiryActionEPh` | `asm/ZNK22IOSkywalkNetworkPacket15getExpiryActionEPh.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297f404` | 8 | `__ZNK22IOSkywalkNetworkPacket18isPacketGroupStartEv` | `asm/ZNK22IOSkywalkNetworkPacket18isPacketGroupStartEv.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297f418` | 8 | `__ZNK22IOSkywalkNetworkPacket16isPacketGroupEndEv` | `asm/ZNK22IOSkywalkNetworkPacket16isPacketGroupEndEv.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297f42c` | 17 | `__ZNK22IOSkywalkNetworkPacket12getTokenDataEPvPt` | `asm/ZNK22IOSkywalkNetworkPacket12getTokenDataEPvPt.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297f45c` | 17 | `__ZNK22IOSkywalkNetworkPacket11getPacketIDEP9packet_id` | `asm/ZNK22IOSkywalkNetworkPacket11getPacketIDEP9packet_id.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297f48c` | 5 | `__ZNK22IOSkywalkNetworkPacket10getTraceIDEv` | `asm/ZNK22IOSkywalkNetworkPacket10getTraceIDEv.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297f49a` | 5 | `__ZN22IOSkywalkNetworkPacket10setTraceIDEj` | `asm/ZN22IOSkywalkNetworkPacket10setTraceIDEj.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297f4a8` | 5 | `__ZN22IOSkywalkNetworkPacket10traceEventEj` | `asm/ZN22IOSkywalkNetworkPacket10traceEventEj.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297f4b6` | 5 | `__ZN22IOSkywalkNetworkPacket20setFPDSequenceNumberEj` | `asm/ZN22IOSkywalkNetworkPacket20setFPDSequenceNumberEj.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297f4c4` | 5 | `__ZN22IOSkywalkNetworkPacket15setFPDContextIDEt` | `asm/ZN22IOSkywalkNetworkPacket15setFPDContextIDEt.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297f4d2` | 5 | `__ZN22IOSkywalkNetworkPacket13setFPDCommandEh` | `asm/ZN22IOSkywalkNetworkPacket13setFPDCommandEh.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297f4e0` | 17 | `__ZNK22IOSkywalkNetworkPacket9getFlowIDEPj` | `asm/ZNK22IOSkywalkNetworkPacket9getFlowIDEPj.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297f510` | 21 | `__ZN22IOSkywalkNetworkPacket17setRxChecksumInfoEjt` | `asm/ZN22IOSkywalkNetworkPacket17setRxChecksumInfoEjt.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297f548` | 28 | `__ZNK22IOSkywalkNetworkPacket10getTSOInfoEPtPj` | `asm/ZNK22IOSkywalkNetworkPacket10getTSOInfoEPtPj.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297f59a` | 37 | `__ZNK22IOSkywalkNetworkPacket17getTxChecksumInfoEPjPtS1_` | `asm/ZNK22IOSkywalkNetworkPacket17getTxChecksumInfoEPjPtS1_.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297f606` | 9 | `__ZN22IOSkywalkNetworkPacket10setLROInfoEjh` | `asm/ZN22IOSkywalkNetworkPacket10setLROInfoEjh.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297f61a` | 5 | `__ZN22IOSkywalkNetworkPacket15getTrafficClassEv` | `asm/ZN22IOSkywalkNetworkPacket15getTrafficClassEv.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297f628` | 17 | `__ZN22IOSkywalkNetworkPacket15setTrafficClassEj` | `asm/ZN22IOSkywalkNetworkPacket15setTrafficClassEj.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297f658` | 5 | `__ZNK22IOSkywalkNetworkPacket6getMSSEv` | `asm/ZNK22IOSkywalkNetworkPacket6getMSSEv.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297f666` | 16 | `__ZNK22IOSkywalkNetworkPacket14getTxCsumFlagsEv` | `asm/ZNK22IOSkywalkNetworkPacket14getTxCsumFlagsEv.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297f69a` | 4 | `__ZN22IOSkywalkNetworkPacket9MetaClassD0Ev` | `asm/ZN22IOSkywalkNetworkPacket9MetaClassD0Ev.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e086` | 15 | `__ZN15IOSkywalkPacket9MetaClassC1Ev` | `asm/ZN15IOSkywalkPacket9MetaClassC1Ev.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e0b8` | 4 | `__ZN15IOSkywalkPacket9MetaClassD1Ev` | `asm/ZN15IOSkywalkPacket9MetaClassD1Ev.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e0c2` | 13 | `__ZN15IOSkywalkPacketC2EPK11OSMetaClass` | `asm/ZN15IOSkywalkPacketC2EPK11OSMetaClass.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e0e2` | 13 | `__ZN15IOSkywalkPacketC1EPK11OSMetaClass` | `asm/ZN15IOSkywalkPacketC1EPK11OSMetaClass.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e102` | 4 | `__ZN15IOSkywalkPacketD2Ev` | `asm/ZN15IOSkywalkPacketD2Ev.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e10c` | 4 | `__ZN15IOSkywalkPacketD1Ev` | `asm/ZN15IOSkywalkPacketD1Ev.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e116` | 13 | `__ZN15IOSkywalkPacketD0Ev` | `asm/ZN15IOSkywalkPacketD0Ev.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e13e` | 8 | `__ZN15IOSkywalkPacketdlEPvm` | `asm/ZN15IOSkywalkPacketdlEPvm.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e156` | 6 | `__ZNK15IOSkywalkPacket12getMetaClassEv` | `asm/ZNK15IOSkywalkPacket12getMetaClassEv.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e164` | 15 | `__ZN15IOSkywalkPacket9MetaClassC2Ev` | `asm/ZN15IOSkywalkPacket9MetaClassC2Ev.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e196` | 22 | `__ZNK15IOSkywalkPacket9MetaClass5allocEv` | `asm/ZNK15IOSkywalkPacket9MetaClass5allocEv.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e1de` | 6 | `__ZN15IOSkywalkPacketnwEm` | `asm/ZN15IOSkywalkPacketnwEm.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e1f2` | 16 | `__ZN15IOSkywalkPacketC1Ev` | `asm/ZN15IOSkywalkPacketC1Ev.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e222` | 16 | `__ZN15IOSkywalkPacketC2Ev` | `asm/ZN15IOSkywalkPacketC2Ev.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e252` | 45 | `__ZN15IOSkywalkPacket8withPoolEP25IOSkywalkPacketBufferPoolP25IOSkywalkPacketDescriptorj` | `asm/ZN15IOSkywalkPacket8withPoolEP25IOSkywalkPacketBufferPoolP25IOSkywalkPacketDescriptorj.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e2d8` | 52 | `__ZN15IOSkywalkPacket12initWithPoolEP25IOSkywalkPacketBufferPoolP25IOSkywalkPacketDescriptorj` | `asm/ZN15IOSkywalkPacket12initWithPoolEP25IOSkywalkPacketBufferPoolP25IOSkywalkPacketDescriptorj.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e376` | 23 | `__ZN15IOSkywalkPacket4freeEv` | `asm/ZN15IOSkywalkPacket4freeEv.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e3c6` | 5 | `__ZNK15IOSkywalkPacket19getPacketBufferPoolEv` | `asm/ZNK15IOSkywalkPacket19getPacketBufferPoolEv.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e3d0` | 7 | `__ZNK15IOSkywalkPacket13getBufferSizeEv` | `asm/ZNK15IOSkywalkPacket13getBufferSizeEv.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e3de` | 6 | `__ZNK15IOSkywalkPacket20getPacketBufferCountEv` | `asm/ZNK15IOSkywalkPacket20getPacketBufferCountEv.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e3e8` | 29 | `__ZNK15IOSkywalkPacket13getDataLengthEv` | `asm/ZNK15IOSkywalkPacket13getDataLengthEv.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e430` | 19 | `__ZNK15IOSkywalkPacket21getDataVirtualAddressEv` | `asm/ZNK15IOSkywalkPacket21getDataVirtualAddressEv.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e462` | 20 | `__ZNK15IOSkywalkPacket23getDataIOVirtualAddressEv` | `asm/ZNK15IOSkywalkPacket23getDataIOVirtualAddressEv.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e498` | 5 | `__ZNK15IOSkywalkPacket14getSourceQueueEv` | `asm/ZNK15IOSkywalkPacket14getSourceQueueEv.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e4a2` | 31 | `__ZN15IOSkywalkPacket7prepareEP20IOSkywalkPacketQueueyj` | `asm/ZN15IOSkywalkPacket7prepareEP20IOSkywalkPacketQueueyj.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e4ee` | 67 | `__ZN15IOSkywalkPacket16prepareWithQueueEP20IOSkywalkPacketQueuejj` | `asm/ZN15IOSkywalkPacket16prepareWithQueueEP20IOSkywalkPacketQueuejj.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e5c6` | 31 | `__ZN15IOSkywalkPacket8completeEP20IOSkywalkPacketQueuej` | `asm/ZN15IOSkywalkPacket8completeEP20IOSkywalkPacketQueuej.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e612` | 53 | `__ZN15IOSkywalkPacket17completeWithQueueEP20IOSkywalkPacketQueuejj` | `asm/ZN15IOSkywalkPacket17completeWithQueueEP20IOSkywalkPacketQueuejj.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e6aa` | 23 | `__ZN15IOSkywalkPacket8finalizeEv` | `asm/ZN15IOSkywalkPacket8finalizeEv.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e6e6` | 16 | `__ZNK15IOSkywalkPacket16generateTraceTagEP20IOSkywalkPacketQueue` | `asm/ZNK15IOSkywalkPacket16generateTraceTagEP20IOSkywalkPacketQueue.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e70c` | 5 | `__ZNK15IOSkywalkPacket11getTraceTagEv` | `asm/ZNK15IOSkywalkPacket11getTraceTagEv.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e71a` | 5 | `__ZNK15IOSkywalkPacket11setTraceTagEt` | `asm/ZNK15IOSkywalkPacket11setTraceTagEt.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e728` | 17 | `__ZN15IOSkywalkPacket14getAppMetadataEP26packet_app_metadata_type_tPh` | `asm/ZN15IOSkywalkPacket14getAppMetadataEP26packet_app_metadata_type_tPh.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e758` | 8 | `__ZN15IOSkywalkPacket23acquireWithPacketHandleEyj` | `asm/ZN15IOSkywalkPacket23acquireWithPacketHandleEyj.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e76c` | 29 | `__ZN15IOSkywalkPacket13disposePacketEv` | `asm/ZN15IOSkywalkPacket13disposePacketEv.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e7c2` | 6 | `__ZN15IOSkywalkPacket20setTransferDirectionEj` | `asm/ZN15IOSkywalkPacket20setTransferDirectionEj.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e7cc` | 6 | `__ZNK15IOSkywalkPacket20getTransferDirectionEv` | `asm/ZNK15IOSkywalkPacket20getTransferDirectionEv.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e7d6` | 6 | `__ZN15IOSkywalkPacket22clearTransferDirectionEv` | `asm/ZN15IOSkywalkPacket22clearTransferDirectionEv.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e7e4` | 5 | `__ZNK15IOSkywalkPacket13getPacketTypeEv` | `asm/ZNK15IOSkywalkPacket13getPacketTypeEv.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e7ec` | 5 | `__ZN15IOSkywalkPacket24cancelCompletionCallbackEv` | `asm/ZN15IOSkywalkPacket24cancelCompletionCallbackEv.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e7fa` | 5 | `__ZN15IOSkywalkPacket13setNextPacketEPS_` | `asm/ZN15IOSkywalkPacket13setNextPacketEPS_.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e804` | 5 | `__ZN15IOSkywalkPacket13getNextPacketEv` | `asm/ZN15IOSkywalkPacket13getNextPacketEv.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e80e` | 4 | `__ZN15IOSkywalkPacket9MetaClassD0Ev` | `asm/ZN15IOSkywalkPacket9MetaClassD0Ev.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e818` | 4 | `__ZN15IOSkywalkPacket11setWakeFlagEv` | `asm/ZN15IOSkywalkPacket11setWakeFlagEv.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e81e` | 5 | `__ZNK15IOSkywalkPacket10getTraceIDEv` | `asm/ZNK15IOSkywalkPacket10getTraceIDEv.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e826` | 4 | `__ZN15IOSkywalkPacket10setTraceIDEj` | `asm/ZN15IOSkywalkPacket10setTraceIDEj.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e82c` | 4 | `__ZN15IOSkywalkPacket10traceEventEj` | `asm/ZN15IOSkywalkPacket10traceEventEj.asm.txt` |
| `IOSkywalkPacket` | `0xffffff80029a2398` | 25 | `__ZNK15IOSkywalkPacket16getPacketBuffersEPP21IOSkywalkPacketBufferj` | `asm/ZNK15IOSkywalkPacket16getPacketBuffersEPP21IOSkywalkPacketBufferj.asm.txt` |
| `IOSkywalkPacket` | `0xffffff80029a23d2` | 11 | `__ZNK15IOSkywalkPacket19getMemoryDescriptorEv` | `asm/ZNK15IOSkywalkPacket19getMemoryDescriptorEv.asm.txt` |
| `IOSkywalkPacket` | `0xffffff80029a23ec` | 11 | `__ZN15IOSkywalkPacket13setDataLengthEj` | `asm/ZN15IOSkywalkPacket13setDataLengthEj.asm.txt` |
| `IOSkywalkPacket` | `0xffffff80029a240a` | 11 | `__ZN15IOSkywalkPacket10setDataOffEx` | `asm/ZN15IOSkywalkPacket10setDataOffEx.asm.txt` |
| `IOSkywalkPacket` | `0xffffff80029a2428` | 12 | `__ZNK15IOSkywalkPacket10getDataOffEv` | `asm/ZNK15IOSkywalkPacket10getDataOffEv.asm.txt` |
| `IOSkywalkPacket` | `0xffffff80029a2444` | 53 | `__ZN15IOSkywalkPacket16setDataOffAndLenExm` | `asm/ZN15IOSkywalkPacket16setDataOffAndLenExm.asm.txt` |
| `IOSkywalkPacket` | `0xffffff80029a24d0` | 52 | `__ZN15IOSkywalkPacket22setDataOffsetAndLengthEtj` | `asm/ZN15IOSkywalkPacket22setDataOffsetAndLengthEtj.asm.txt` |
| `IOSkywalkPacket` | `0xffffff80029a2558` | 13 | `__ZN15IOSkywalkPacket13setDataOffsetEt` | `asm/ZN15IOSkywalkPacket13setDataOffsetEt.asm.txt` |
| `IOSkywalkPacket` | `0xffffff80029a257a` | 13 | `__ZNK15IOSkywalkPacket13getDataOffsetEv` | `asm/ZNK15IOSkywalkPacket13getDataOffsetEv.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297c9ec` | 15 | `__ZN25IOSkywalkPacketBufferPool9MetaClassC1Ev` | `asm/ZN25IOSkywalkPacketBufferPool9MetaClassC1Ev.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297ca1e` | 4 | `__ZN25IOSkywalkPacketBufferPool9MetaClassD1Ev` | `asm/ZN25IOSkywalkPacketBufferPool9MetaClassD1Ev.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297ca28` | 13 | `__ZN25IOSkywalkPacketBufferPoolC2EPK11OSMetaClass` | `asm/ZN25IOSkywalkPacketBufferPoolC2EPK11OSMetaClass.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297ca48` | 13 | `__ZN25IOSkywalkPacketBufferPoolC1EPK11OSMetaClass` | `asm/ZN25IOSkywalkPacketBufferPoolC1EPK11OSMetaClass.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297ca68` | 4 | `__ZN25IOSkywalkPacketBufferPoolD2Ev` | `asm/ZN25IOSkywalkPacketBufferPoolD2Ev.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297ca72` | 4 | `__ZN25IOSkywalkPacketBufferPoolD1Ev` | `asm/ZN25IOSkywalkPacketBufferPoolD1Ev.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297ca7c` | 13 | `__ZN25IOSkywalkPacketBufferPoolD0Ev` | `asm/ZN25IOSkywalkPacketBufferPoolD0Ev.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297caa4` | 8 | `__ZN25IOSkywalkPacketBufferPooldlEPvm` | `asm/ZN25IOSkywalkPacketBufferPooldlEPvm.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297cabc` | 6 | `__ZNK25IOSkywalkPacketBufferPool12getMetaClassEv` | `asm/ZNK25IOSkywalkPacketBufferPool12getMetaClassEv.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297caca` | 15 | `__ZN25IOSkywalkPacketBufferPool9MetaClassC2Ev` | `asm/ZN25IOSkywalkPacketBufferPool9MetaClassC2Ev.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297cafc` | 22 | `__ZNK25IOSkywalkPacketBufferPool9MetaClass5allocEv` | `asm/ZNK25IOSkywalkPacketBufferPool9MetaClass5allocEv.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297cb44` | 6 | `__ZN25IOSkywalkPacketBufferPoolnwEm` | `asm/ZN25IOSkywalkPacketBufferPoolnwEm.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297cb58` | 16 | `__ZN25IOSkywalkPacketBufferPoolC1Ev` | `asm/ZN25IOSkywalkPacketBufferPoolC1Ev.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297cb88` | 16 | `__ZN25IOSkywalkPacketBufferPoolC2Ev` | `asm/ZN25IOSkywalkPacketBufferPoolC2Ev.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297cbb8` | 47 | `__ZN25IOSkywalkPacketBufferPool8withNameEPKcP8OSObjectjPKNS_11PoolOptionsE` | `asm/ZN25IOSkywalkPacketBufferPool8withNameEPKcP8OSObjectjPKNS_11PoolOptionsE.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297cc46` | 7 | `__ZN25IOSkywalkPacketBufferPool12initWithNameEPKcPvjPKNS_11PoolOptionsE` | `asm/ZN25IOSkywalkPacketBufferPool12initWithNameEPKcPvjPKNS_11PoolOptionsE.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297cc58` | 263 | `__ZN25IOSkywalkPacketBufferPool12initWithNameEPKcP8OSObjectjPKNS_11PoolOptionsE` | `asm/ZN25IOSkywalkPacketBufferPool12initWithNameEPKcP8OSObjectjPKNS_11PoolOptionsE.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297d0c6` | 58 | `__ZN25IOSkywalkPacketBufferPool27reportingChangeNotificationEv` | `asm/ZN25IOSkywalkPacketBufferPool27reportingChangeNotificationEv.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297d17c` | 51 | `__ZN25IOSkywalkPacketBufferPool18segmentConstructorEP13kern_pbufpoolP9sksegmentP18IOMemoryDescriptor` | `asm/ZN25IOSkywalkPacketBufferPool18segmentConstructorEP13kern_pbufpoolP9sksegmentP18IOMemoryDescriptor.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297d20e` | 31 | `__ZN25IOSkywalkPacketBufferPool17segmentDestructorEP13kern_pbufpoolP9sksegmentP18IOMemoryDescriptor` | `asm/ZN25IOSkywalkPacketBufferPool17segmentDestructorEP13kern_pbufpoolP9sksegmentP18IOMemoryDescriptor.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297d276` | 26 | `__ZNK25IOSkywalkPacketBufferPool7releaseEv` | `asm/ZNK25IOSkywalkPacketBufferPool7releaseEv.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297d2ca` | 46 | `__ZN25IOSkywalkPacketBufferPool17disposeAllPacketsEv` | `asm/ZN25IOSkywalkPacketBufferPool17disposeAllPacketsEv.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297d366` | 22 | `__ZN25IOSkywalkPacketBufferPool17disposeAllBuffersEv` | `asm/ZN25IOSkywalkPacketBufferPool17disposeAllBuffersEv.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297d3bc` | 57 | `__ZN25IOSkywalkPacketBufferPool4freeEv` | `asm/ZN25IOSkywalkPacketBufferPool4freeEv.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297d4c0` | 27 | `__ZN25IOSkywalkPacketBufferPool17releaseAllPacketsEv` | `asm/ZN25IOSkywalkPacketBufferPool17releaseAllPacketsEv.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297d518` | 19 | `__ZN25IOSkywalkPacketBufferPool24releaseAllMemorySegmentsEv` | `asm/ZN25IOSkywalkPacketBufferPool24releaseAllMemorySegmentsEv.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297d556` | 18 | `__ZNK25IOSkywalkPacketBufferPool11getPoolNameEv` | `asm/ZNK25IOSkywalkPacketBufferPool11getPoolNameEv.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297d592` | 15 | `__ZN25IOSkywalkPacketBufferPool19acquireKernelPacketEy` | `asm/ZN25IOSkywalkPacketBufferPool19acquireKernelPacketEy.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297d5b6` | 44 | `__ZN25IOSkywalkPacketBufferPool21allocateKernelPacketsEjPyPjj` | `asm/ZN25IOSkywalkPacketBufferPool21allocateKernelPacketsEjPyPjj.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297d626` | 18 | `__ZN25IOSkywalkPacketBufferPool16freeKernelPacketEy` | `asm/ZN25IOSkywalkPacketBufferPool16freeKernelPacketEy.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297d65a` | 14 | `__ZN25IOSkywalkPacketBufferPool19disposeKernelPacketEy` | `asm/ZN25IOSkywalkPacketBufferPool19disposeKernelPacketEy.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297d680` | 35 | `__ZN25IOSkywalkPacketBufferPool17freeKernelPacketsEPyj` | `asm/ZN25IOSkywalkPacketBufferPool17freeKernelPacketsEPyj.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297d6dc` | 11 | `__ZNK25IOSkywalkPacketBufferPool24getKernelPacketWithIndexEj` | `asm/ZNK25IOSkywalkPacketBufferPool24getKernelPacketWithIndexEj.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297d6f4` | 7 | `__ZN25IOSkywalkPacketBufferPool28disposeKernelPacketWithIndexEyj` | `asm/ZN25IOSkywalkPacketBufferPool28disposeKernelPacketWithIndexEyj.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297d708` | 7 | `__ZN25IOSkywalkPacketBufferPool28acquireKernelPacketWithIndexEyj` | `asm/ZN25IOSkywalkPacketBufferPool28acquireKernelPacketWithIndexEyj.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297d718` | 16 | `__ZNK25IOSkywalkPacketBufferPool26getMemorySegmentWithHandleEP9sksegment` | `asm/ZNK25IOSkywalkPacketBufferPool26getMemorySegmentWithHandleEP9sksegment.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297d742` | 28 | `__ZN25IOSkywalkPacketBufferPool9newPacketEP25IOSkywalkPacketDescriptorPP15IOSkywalkPacket` | `asm/ZN25IOSkywalkPacketBufferPool9newPacketEP25IOSkywalkPacketDescriptorPP15IOSkywalkPacket.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297d78c` | 16 | `__ZN25IOSkywalkPacketBufferPool15newPacketBufferEP31IOSkywalkPacketBufferDescriptorPP21IOSkywalkPacketBuffer` | `asm/ZN25IOSkywalkPacketBufferPool15newPacketBufferEP31IOSkywalkPacketBufferDescriptorPP21IOSkywalkPacketBuffer.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297d7b4` | 16 | `__ZN25IOSkywalkPacketBufferPool16newMemorySegmentEP32IOSkywalkMemorySegmentDescriptorPP22IOSkywalkMemorySegment` | `asm/ZN25IOSkywalkPacketBufferPool16newMemorySegmentEP32IOSkywalkMemorySegmentDescriptorPP22IOSkywalkMemorySegment.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297d7dc` | 16 | `__ZNK25IOSkywalkPacketBufferPool19getPacketWithHandleEy` | `asm/ZNK25IOSkywalkPacketBufferPool19getPacketWithHandleEy.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297d806` | 17 | `__ZNK25IOSkywalkPacketBufferPool18getPacketWithIndexEj` | `asm/ZNK25IOSkywalkPacketBufferPool18getPacketWithIndexEj.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297d82e` | 10 | `__ZN25IOSkywalkPacketBufferPool14allocatePacketEPP15IOSkywalkPacketj` | `asm/ZN25IOSkywalkPacketBufferPool14allocatePacketEPP15IOSkywalkPacketj.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297d84a` | 38 | `__ZN25IOSkywalkPacketBufferPool22completePreparedPacketEP15IOSkywalkPacket` | `asm/ZN25IOSkywalkPacketBufferPool22completePreparedPacketEP15IOSkywalkPacket.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297d8ae` | 29 | `__ZN25IOSkywalkPacketBufferPool20deallocatePacketListEP15IOSkywalkPacket` | `asm/ZN25IOSkywalkPacketBufferPool20deallocatePacketListEP15IOSkywalkPacket.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297da3c` | 46 | `__ZN25IOSkywalkPacketBufferPool18checkInPacketQueueEPK20IOSkywalkPacketQueue` | `asm/ZN25IOSkywalkPacketBufferPool18checkInPacketQueueEPK20IOSkywalkPacketQueue.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297dad0` | 63 | `__ZN25IOSkywalkPacketBufferPool19checkOutPacketQueueEPK20IOSkywalkPacketQueue` | `asm/ZN25IOSkywalkPacketBufferPool19checkOutPacketQueueEPK20IOSkywalkPacketQueue.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297dbb6` | 36 | `__ZN25IOSkywalkPacketBufferPool23checkInReportingServiceEP9IOServicePK18IOSkywalkInterface` | `asm/ZN25IOSkywalkPacketBufferPool23checkInReportingServiceEP9IOServicePK18IOSkywalkInterface.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297dc2e` | 67 | `__ZN25IOSkywalkPacketBufferPool25createReportersForServiceEP9IOServicePK18IOSkywalkInterface` | `asm/ZN25IOSkywalkPacketBufferPool25createReportersForServiceEP9IOServicePK18IOSkywalkInterface.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297dd18` | 22 | `__ZN25IOSkywalkPacketBufferPool24checkOutReportingServiceEPK9IOService` | `asm/ZN25IOSkywalkPacketBufferPool24checkOutReportingServiceEPK9IOService.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297dd64` | 48 | `__ZN25IOSkywalkPacketBufferPool25removeReportersForServiceEPK9IOService` | `asm/ZN25IOSkywalkPacketBufferPool25removeReportersForServiceEPK9IOService.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297ddf2` | 69 | `__ZN25IOSkywalkPacketBufferPool15addPoolReporterEP9IOServiceP5OSSet` | `asm/ZN25IOSkywalkPacketBufferPool15addPoolReporterEP9IOServiceP5OSSet.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297ded4` | 56 | `__ZN25IOSkywalkPacketBufferPool23copyReportersForServiceEPK9IOService` | `asm/ZN25IOSkywalkPacketBufferPool23copyReportersForServiceEPK9IOService.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297df90` | 62 | `__ZN25IOSkywalkPacketBufferPool21getReportChannelValueEy` | `asm/ZN25IOSkywalkPacketBufferPool21getReportChannelValueEy.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297e038` | 4 | `__ZN25IOSkywalkPacketBufferPool9MetaClassD0Ev` | `asm/ZN25IOSkywalkPacketBufferPool9MetaClassD0Ev.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff80029a1aca` | 33 | `__ZN25IOSkywalkPacketBufferPool20allocateKernelPacketEjPyj` | `asm/ZN25IOSkywalkPacketBufferPool20allocateKernelPacketEjPyj.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff80029a1b1c` | 122 | `__ZN25IOSkywalkPacketBufferPool20createSegmentBuffersEP22IOSkywalkMemorySegmentjb` | `asm/ZN25IOSkywalkPacketBufferPool20createSegmentBuffersEP22IOSkywalkMemorySegmentjb.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff80029a1cb2` | 16 | `__ZN25IOSkywalkPacketBufferPool21destroySegmentBuffersEP22IOSkywalkMemorySegment` | `asm/ZN25IOSkywalkPacketBufferPool21destroySegmentBuffersEP22IOSkywalkMemorySegment.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff80029a1cda` | 73 | `__ZN25IOSkywalkPacketBufferPool20prepareMemorySegmentEP22IOSkywalkMemorySegmentP24IOBufferMemoryDescriptory` | `asm/ZN25IOSkywalkPacketBufferPool20prepareMemorySegmentEP22IOSkywalkMemorySegmentP24IOBufferMemoryDescriptory.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff80029a1dc8` | 31 | `__ZNK25IOSkywalkPacketBufferPool31getPacketBufferWithBufletHandleEP13__kern_buflet` | `asm/ZNK25IOSkywalkPacketBufferPool31getPacketBufferWithBufletHandleEP13__kern_buflet.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff80029a1e20` | 28 | `__ZNK25IOSkywalkPacketBufferPool30getPacketBufferWithSegmentInfoEP9sksegmentj` | `asm/ZNK25IOSkywalkPacketBufferPool30getPacketBufferWithSegmentInfoEP9sksegmentj.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff80029a1e66` | 55 | `__ZN25IOSkywalkPacketBufferPool14allocatePacketEjPP15IOSkywalkPacketj` | `asm/ZN25IOSkywalkPacketBufferPool14allocatePacketEjPP15IOSkywalkPacketj.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff80029a1f10` | 108 | `__ZN25IOSkywalkPacketBufferPool15allocatePacketsEjPjPP15IOSkywalkPacketj` | `asm/ZN25IOSkywalkPacketBufferPool15allocatePacketsEjPjPP15IOSkywalkPacketj.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff80029a2072` | 28 | `__ZN25IOSkywalkPacketBufferPool16deallocatePacketEP15IOSkywalkPacket` | `asm/ZN25IOSkywalkPacketBufferPool16deallocatePacketEP15IOSkywalkPacket.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff80029a20be` | 53 | `__ZN25IOSkywalkPacketBufferPool17deallocatePacketsEPP15IOSkywalkPacketj` | `asm/ZN25IOSkywalkPacketBufferPool17deallocatePacketsEPP15IOSkywalkPacketj.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff80029a214a` | 10 | `__ZN25IOSkywalkPacketBufferPool21deallocatePacketChainEy` | `asm/ZN25IOSkywalkPacketBufferPool21deallocatePacketChainEy.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff80029a2160` | 49 | `__ZN25IOSkywalkPacketBufferPool20allocatePacketBufferEPP21IOSkywalkPacketBufferj` | `asm/ZN25IOSkywalkPacketBufferPool20allocatePacketBufferEPP21IOSkywalkPacketBufferj.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff80029a21fe` | 48 | `__ZN25IOSkywalkPacketBufferPool21allocatePacketBuffersEPjPP21IOSkywalkPacketBufferj` | `asm/ZN25IOSkywalkPacketBufferPool21allocatePacketBuffersEPjPP21IOSkywalkPacketBufferj.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff80029a2278` | 32 | `__ZN25IOSkywalkPacketBufferPool22deallocatePacketBufferEP21IOSkywalkPacketBuffer` | `asm/ZN25IOSkywalkPacketBufferPool22deallocatePacketBufferEP21IOSkywalkPacketBuffer.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff80029a22d0` | 28 | `__ZN25IOSkywalkPacketBufferPool23deallocatePacketBuffersEPP21IOSkywalkPacketBufferj` | `asm/ZN25IOSkywalkPacketBufferPool23deallocatePacketBuffersEPP21IOSkywalkPacketBufferj.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff80029a2316` | 25 | `__ZN25IOSkywalkPacketBufferPool17segmentDestructorEP13kern_pbufpoolP9sksegmentP18IOMemoryDescriptor.cold.1` | `asm/ZN25IOSkywalkPacketBufferPool17segmentDestructorEP13kern_pbufpoolP9sksegmentP18IOMemoryDescriptor.cold.1.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff80029a235f` | 15 | `__ZN25IOSkywalkPacketBufferPool9newPacketEP25IOSkywalkPacketDescriptorPP15IOSkywalkPacket.cold.1` | `asm/ZN25IOSkywalkPacketBufferPool9newPacketEP25IOSkywalkPacketDescriptorPP15IOSkywalkPacket.cold.1.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297e876` | 15 | `__ZN21IOSkywalkPacketBuffer9MetaClassC1Ev` | `asm/ZN21IOSkywalkPacketBuffer9MetaClassC1Ev.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297e8a8` | 4 | `__ZN21IOSkywalkPacketBuffer9MetaClassD1Ev` | `asm/ZN21IOSkywalkPacketBuffer9MetaClassD1Ev.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297e8b2` | 13 | `__ZN21IOSkywalkPacketBufferC2EPK11OSMetaClass` | `asm/ZN21IOSkywalkPacketBufferC2EPK11OSMetaClass.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297e8d2` | 13 | `__ZN21IOSkywalkPacketBufferC1EPK11OSMetaClass` | `asm/ZN21IOSkywalkPacketBufferC1EPK11OSMetaClass.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297e8f2` | 4 | `__ZN21IOSkywalkPacketBufferD2Ev` | `asm/ZN21IOSkywalkPacketBufferD2Ev.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297e8fc` | 4 | `__ZN21IOSkywalkPacketBufferD1Ev` | `asm/ZN21IOSkywalkPacketBufferD1Ev.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297e906` | 13 | `__ZN21IOSkywalkPacketBufferD0Ev` | `asm/ZN21IOSkywalkPacketBufferD0Ev.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297e92e` | 8 | `__ZN21IOSkywalkPacketBufferdlEPvm` | `asm/ZN21IOSkywalkPacketBufferdlEPvm.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297e946` | 6 | `__ZNK21IOSkywalkPacketBuffer12getMetaClassEv` | `asm/ZNK21IOSkywalkPacketBuffer12getMetaClassEv.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297e954` | 15 | `__ZN21IOSkywalkPacketBuffer9MetaClassC2Ev` | `asm/ZN21IOSkywalkPacketBuffer9MetaClassC2Ev.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297e986` | 22 | `__ZNK21IOSkywalkPacketBuffer9MetaClass5allocEv` | `asm/ZNK21IOSkywalkPacketBuffer9MetaClass5allocEv.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297e9ce` | 6 | `__ZN21IOSkywalkPacketBuffernwEm` | `asm/ZN21IOSkywalkPacketBuffernwEm.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297e9e2` | 16 | `__ZN21IOSkywalkPacketBufferC1Ev` | `asm/ZN21IOSkywalkPacketBufferC1Ev.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297ea12` | 16 | `__ZN21IOSkywalkPacketBufferC2Ev` | `asm/ZN21IOSkywalkPacketBufferC2Ev.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297ea42` | 45 | `__ZN21IOSkywalkPacketBuffer8withPoolEP25IOSkywalkPacketBufferPoolP31IOSkywalkPacketBufferDescriptorj` | `asm/ZN21IOSkywalkPacketBuffer8withPoolEP25IOSkywalkPacketBufferPoolP31IOSkywalkPacketBufferDescriptorj.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297eac8` | 48 | `__ZN21IOSkywalkPacketBuffer12initWithPoolEP25IOSkywalkPacketBufferPoolP31IOSkywalkPacketBufferDescriptorj` | `asm/ZN21IOSkywalkPacketBuffer12initWithPoolEP25IOSkywalkPacketBufferPoolP31IOSkywalkPacketBufferDescriptorj.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297eb56` | 25 | `__ZN21IOSkywalkPacketBuffer4freeEv` | `asm/ZN21IOSkywalkPacketBuffer4freeEv.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297ebac` | 5 | `__ZNK21IOSkywalkPacketBuffer19getPacketBufferPoolEv` | `asm/ZNK21IOSkywalkPacketBuffer19getPacketBufferPoolEv.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297ebb6` | 5 | `__ZNK21IOSkywalkPacketBuffer9getPacketEv` | `asm/ZNK21IOSkywalkPacketBuffer9getPacketEv.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297ebc0` | 7 | `__ZNK21IOSkywalkPacketBuffer13getBufferSizeEv` | `asm/ZNK21IOSkywalkPacketBuffer13getBufferSizeEv.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297ebce` | 6 | `__ZNK21IOSkywalkPacketBuffer13getDataLengthEv` | `asm/ZNK21IOSkywalkPacketBuffer13getDataLengthEv.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297ebd8` | 6 | `__ZNK21IOSkywalkPacketBuffer13getDataOffsetEv` | `asm/ZNK21IOSkywalkPacketBuffer13getDataOffsetEv.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297ebe6` | 5 | `__ZNK21IOSkywalkPacketBuffer10getDataOffEv` | `asm/ZNK21IOSkywalkPacketBuffer10getDataOffEv.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297ebf2` | 5 | `__ZNK21IOSkywalkPacketBuffer16getMemorySegmentEv` | `asm/ZNK21IOSkywalkPacketBuffer16getMemorySegmentEv.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297ebfc` | 5 | `__ZNK21IOSkywalkPacketBuffer22getMemorySegmentOffsetEv` | `asm/ZNK21IOSkywalkPacketBuffer22getMemorySegmentOffsetEv.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297ec06` | 5 | `__ZNK21IOSkywalkPacketBuffer15getBufletHandleEv` | `asm/ZNK21IOSkywalkPacketBuffer15getBufletHandleEv.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297ec10` | 5 | `__ZN21IOSkywalkPacketBuffer15setBufletHandleEP13__kern_buflet` | `asm/ZN21IOSkywalkPacketBuffer15setBufletHandleEP13__kern_buflet.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297ec1a` | 5 | `__ZNK21IOSkywalkPacketBuffer15getBufferHandleEv` | `asm/ZNK21IOSkywalkPacketBuffer15getBufferHandleEv.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297ec24` | 5 | `__ZN21IOSkywalkPacketBuffer7prepareEj` | `asm/ZN21IOSkywalkPacketBuffer7prepareEj.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297ec2c` | 5 | `__ZN21IOSkywalkPacketBuffer8completeEj` | `asm/ZN21IOSkywalkPacketBuffer8completeEj.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297ec34` | 8 | `__ZN21IOSkywalkPacketBuffer24prepareWithMemorySegmentEP22IOSkywalkMemorySegmentyj` | `asm/ZN21IOSkywalkPacketBuffer24prepareWithMemorySegmentEP22IOSkywalkMemorySegmentyj.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297ec48` | 8 | `__ZN21IOSkywalkPacketBuffer25completeWithMemorySegmentEP22IOSkywalkMemorySegmentyj` | `asm/ZN21IOSkywalkPacketBuffer25completeWithMemorySegmentEP22IOSkywalkMemorySegmentyj.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297ec5c` | 5 | `__ZNK21IOSkywalkPacketBuffer14getSourceQueueEv` | `asm/ZNK21IOSkywalkPacketBuffer14getSourceQueueEv.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297ec66` | 51 | `__ZN21IOSkywalkPacketBuffer16prepareWithQueueEP20IOSkywalkPacketQueuejj` | `asm/ZN21IOSkywalkPacketBuffer16prepareWithQueueEP20IOSkywalkPacketQueuejj.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297ed00` | 27 | `__ZN21IOSkywalkPacketBuffer17completeWithQueueEP20IOSkywalkPacketQueuejj` | `asm/ZN21IOSkywalkPacketBuffer17completeWithQueueEP20IOSkywalkPacketQueuejj.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297ed48` | 18 | `__ZN21IOSkywalkPacketBuffer8finalizeEv` | `asm/ZN21IOSkywalkPacketBuffer8finalizeEv.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297ed7a` | 5 | `__ZN21IOSkywalkPacketBuffer9setPacketEP15IOSkywalkPacketj` | `asm/ZN21IOSkywalkPacketBuffer9setPacketEP15IOSkywalkPacketj.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297ed84` | 6 | `__ZN21IOSkywalkPacketBuffer23acquireWithBufletHandleEP13__kern_buflet` | `asm/ZN21IOSkywalkPacketBuffer23acquireWithBufletHandleEP13__kern_buflet.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297ed94` | 6 | `__ZN21IOSkywalkPacketBuffer23acquireWithBufferHandleEy` | `asm/ZN21IOSkywalkPacketBuffer23acquireWithBufferHandleEy.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297eda4` | 10 | `__ZN21IOSkywalkPacketBuffer19disposePacketBufferEv` | `asm/ZN21IOSkywalkPacketBuffer19disposePacketBufferEv.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297edc2` | 5 | `__ZN21IOSkywalkPacketBuffer24cancelCompletionCallbackEv` | `asm/ZN21IOSkywalkPacketBuffer24cancelCompletionCallbackEv.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297edd0` | 4 | `__ZN21IOSkywalkPacketBuffer9MetaClassD0Ev` | `asm/ZN21IOSkywalkPacketBuffer9MetaClassD0Ev.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff80029a259a` | 14 | `__ZN21IOSkywalkPacketBuffer13setDataLengthEj` | `asm/ZN21IOSkywalkPacketBuffer13setDataLengthEj.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff80029a25be` | 14 | `__ZN21IOSkywalkPacketBuffer13setDataOffsetEt` | `asm/ZN21IOSkywalkPacketBuffer13setDataOffsetEt.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff80029a25e2` | 19 | `__ZN21IOSkywalkPacketBuffer10setDataOffEx` | `asm/ZN21IOSkywalkPacketBuffer10setDataOffEx.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff80029a2616` | 14 | `__ZN21IOSkywalkPacketBuffer22setDataOffsetAndLengthEtj` | `asm/ZN21IOSkywalkPacketBuffer22setDataOffsetAndLengthEtj.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff80029a263c` | 27 | `__ZN21IOSkywalkPacketBuffer16setDataOffAndLenExm` | `asm/ZN21IOSkywalkPacketBuffer16setDataOffAndLenExm.asm.txt` |

### Source evidence snippets

**RTW88WCLSkywalkQueues.cpp:24-44**

```cpp
   24:         return false;
   25:     _txPool = nullptr;
   26:     _rxPool = nullptr;
   27:     _txSubmission = nullptr;
   28:     _txCompletion = nullptr;
   29:     _rxSubmission = nullptr;
   30:     _rxCompletion = nullptr;
   31:     _allocated = false;
   32:     return true;
   33: }
   34: 
   35: IOReturn RTW88WCLSkywalkQueues::createQueues()
   36: {
   37:     if (_allocated)
   38:         return kIOReturnSuccess;
   39:     if (_txPool || _rxPool || _txSubmission || _txCompletion ||
   40:         _rxSubmission || _rxCompletion)
   41:         return kIOReturnBusy;
   42: 
   43:     RTW88WCLPoolOptionsAccess::PoolOptions txOptions = {};
   44:     txOptions.packetCount = kQueueCapacity;
```

**RTW88WCLSkywalkQueues.cpp:72-95**

```cpp
   72:         &RTW88WCLSkywalkQueues::txSubmissionAction, this, 0);
   73:     if (!_txSubmission)
   74:         goto no_memory;
   75: 
   76:     _txCompletion = IOSkywalkTxCompletionQueue::withPool(
   77:         _txPool, kQueueCapacity, 0, this,
   78:         &RTW88WCLSkywalkQueues::txCompletionAction, this, 0);
   79:     if (!_txCompletion)
   80:         goto no_memory;
   81: 
   82:     _rxSubmission = IOSkywalkRxSubmissionQueue::withPool(
   83:         _rxPool, kQueueCapacity, 0, static_cast<kern_packet_svc_class_t>(0),
   84:         this, &RTW88WCLSkywalkQueues::rxSubmissionAction, this, 0);
   85:     if (!_rxSubmission)
   86:         goto no_memory;
   87: 
   88:     _rxCompletion = IOSkywalkRxCompletionQueue::withPool(
   89:         _rxPool, kQueueCapacity, 0, this,
   90:         &RTW88WCLSkywalkQueues::rxCompletionAction, this, 0);
   91:     if (!_rxCompletion)
   92:         goto no_memory;
   93: 
   94:     _allocated = true;
   95:     IOLog("rtl88wifi-wcl: allocated Skywalk pools and four queue objects (not registered)\n");
```

**RTW88WCLSkywalkQueues.cpp:103-121**

```cpp
  103: void RTW88WCLSkywalkQueues::destroyQueues()
  104: {
  105:     /* Release queues before their pools: queue implementations retain and
  106:      * reference their associated pool for packet and buffer accounting. */
  107:     if (_rxCompletion) {
  108:         _rxCompletion->release();
  109:         _rxCompletion = nullptr;
  110:     }
  111:     if (_rxSubmission) {
  112:         _rxSubmission->release();
  113:         _rxSubmission = nullptr;
  114:     }
  115:     if (_txCompletion) {
  116:         _txCompletion->release();
  117:         _txCompletion = nullptr;
  118:     }
  119:     if (_txSubmission) {
  120:         _txSubmission->release();
  121:         _txSubmission = nullptr;
```

**RTW88WCLSkywalkQueues.cpp:133-141**

```cpp
  133: 
  134: bool RTW88WCLSkywalkQueues::queuesAllocated() const
  135: {
  136:     return _allocated && _txPool && _rxPool && _txSubmission &&
  137:            _txCompletion && _rxSubmission && _rxCompletion;
  138: }
  139: 
  140: IOReturn RTW88WCLSkywalkQueues::txSubmissionAction(
  141:     OSObject *owner, IOSkywalkTxSubmissionQueue *queue,
```

**RTW88WCLSkywalkQueues.cpp:147-156**

```cpp
  147:         return kIOReturnBadArgument;
  148: 
  149:     /* Validate every descriptor before a future TX path is allowed to copy
  150:      * bytes or hand ownership to RTW88. The callback remains fail-closed:
  151:      * a validated packet is not yet accepted until its hardware completion
  152:      * cookie is connected to the native completion queue. */
  153:     for (UInt32 i = 0; i < packetCount; ++i) {
  154:         if (!packets[i])
  155:             return kIOReturnBadArgument;
  156:         RTW88WCLPacketView view = {};
```

**RTW88WCLSkywalkQueues.cpp:161-170**

```cpp
  161: 
  162:     return kIOReturnNotReady;
  163: }
  164: 
  165: IOReturn RTW88WCLSkywalkQueues::txCompletionAction(
  166:     OSObject *owner, IOSkywalkTxCompletionQueue *queue,
  167:     IOSkywalkPacket **packets, UInt32 packetCount, void *refCon)
  168: {
  169:     (void)owner; (void)queue; (void)packets; (void)packetCount; (void)refCon;
  170:     return kIOReturnNotReady;
```

**RTW88WCLSkywalkQueues.cpp:174-187**

```cpp
  174:     OSObject *owner, IOSkywalkRxSubmissionQueue *queue,
  175:     const IOSkywalkPacket **packets, UInt32 packetCount, void *refCon)
  176: {
  177:     (void)owner; (void)queue; (void)packets; (void)packetCount; (void)refCon;
  178:     /* RX buffer ownership/refill is intentionally not accepted yet. */
  179:     return kIOReturnNotReady;
  180: }
  181: 
  182: IOReturn RTW88WCLSkywalkQueues::rxCompletionAction(
  183:     OSObject *owner, IOSkywalkRxCompletionQueue *queue,
  184:     IOSkywalkPacket **packets, UInt32 packetCount, void *refCon)
  185: {
  186:     (void)owner; (void)queue; (void)packets; (void)packetCount; (void)refCon;
  187:     return kIOReturnNotReady;
```

**RTW88WCLSkywalkRxAdapter.cpp:1-7**

```cpp
    1: /* SPDX-License-Identifier: GPL-2.0-only
    2:  * Deferred bounded RX conversion. Packet delivery stays disabled until the
    3:  * 24H32 registration and RX-completion ownership contract is verified.
    4:  */
    5: #include "RTW88WCLSkywalkRxAdapter.hpp"
    6: #include "RTW88WCLPacketSpanValidation.hpp"
    7: 
```

**RTW88WCLSkywalkRxAdapter.cpp:15-23**

```cpp
   15: OSDefineMetaClassAndStructors(RTW88WCLSkywalkRxAdapter, IOEventSource)
   16: 
   17: bool RTW88WCLSkywalkRxAdapter::init(OSObject *owner, IOWorkLoop *workLoop,
   18:                                     IOSkywalkPacketBufferPool *rxPool,
   19:                                     FrameSink sink, void *context)
   20: {
   21:     if (!owner || !workLoop || !rxPool || _workLoop || _rxPool || _registered)
   22:         return false;
   23:     if (!super::init(owner, nullptr))
```

**RTW88WCLSkywalkRxAdapter.cpp:26-35**

```cpp
   26:     _frames.reset();
   27:     _workLoop = workLoop;
   28:     _rxPool = rxPool;
   29:     _rxPool->retain();
   30:     _sink = sink;
   31:     _sinkContext = context;
   32:     __atomic_store_n(&_pendingSignal, 0U, __ATOMIC_RELAXED);
   33:     __atomic_store_n(&_stopping, 0U, __ATOMIC_RELAXED);
   34:     __atomic_store_n(&_dropped, 0U, __ATOMIC_RELAXED);
   35:     __atomic_store_n(&_prepared, 0U, __ATOMIC_RELAXED);
```

**RTW88WCLSkywalkRxAdapter.cpp:38-47**

```cpp
   38:     if (status != kIOReturnSuccess) {
   39:         _rxPool->release();
   40:         _rxPool = nullptr;
   41:         _workLoop = nullptr;
   42:         _sink = nullptr;
   43:         _sinkContext = nullptr;
   44:         return false;
   45:     }
   46:     _registered = true;
   47:     return true;
```

**RTW88WCLSkywalkRxAdapter.cpp:128-148**

```cpp
  128:         auto *destination = reinterpret_cast<void *>(destinationAddress);
  129:         if (mbuf_copydata(source, 0, packetLength, destination) != 0)
  130:             break;
  131: 
  132:         if (networkPacket->setCompletionStatus(0) != kIOReturnSuccess)
  133:             break;
  134: 
  135:         *outPacket = packet;
  136:         valid = true;
  137:     } while (false);
  138: 
  139:     if (!valid)
  140:         (void)pool->deallocatePacket(packet);
  141:     return valid;
  142: }
  143: 
  144: IOReturn RTW88WCLSkywalkRxAdapter::enqueueFrame(mbuf_t packet)
  145: {
  146:     if (!packet)
  147:         return kIOReturnBadArgument;
  148: 
```

**RTW88WCLSkywalkRxAdapter.cpp:170-202**

```cpp
  170: {
  171:     if (__atomic_load_n(&_stopping, __ATOMIC_ACQUIRE))
  172:         return false;
  173: 
  174:     uint32_t drained = 0;
  175:     mbuf_t source = nullptr;
  176:     while (drained < kDrainBudget && _frames.pop(&source)) {
  177:         if (source) {
  178:             IOSkywalkPacket *packet = nullptr;
  179:             if (copyMbufToSkywalkPacket(_rxPool, source, &packet)) {
  180:                 __atomic_add_fetch(&_prepared, 1U, __ATOMIC_RELAXED);
  181:                 /* A true return means the sink has accepted ownership. The
  182:                  * current controller sink returns false because the RX
  183:                  * completion queue is still unregistered. */
  184:                 const bool accepted = _sink && _sink(packet, _sinkContext);
  185:                 if (!accepted) {
  186:                     (void)_rxPool->deallocatePacket(packet);
  187:                     __atomic_add_fetch(&_dropped, 1U, __ATOMIC_RELAXED);
  188:                 }
  189:             } else {
  190:                 __atomic_add_fetch(&_dropped, 1U, __ATOMIC_RELAXED);
  191:             }
  192:             mbuf_freem(source);
  193:             source = nullptr;
  194:         }
  195:         ++drained;
  196:     }
  197: 
  198:     if (drained == kDrainBudget)
  199:         return true; // bounded workloop occupancy; schedule another pass
  200: 
  201:     __atomic_store_n(&_pendingSignal, 0U, __ATOMIC_RELEASE);
  202:     if (!_frames.empty()) {
```

**RTW88WCLSkywalkRxAdapter.cpp:224-233**

```cpp
  224:         if (packet)
  225:             mbuf_freem(packet);
  226:         packet = nullptr;
  227:     }
  228:     _sink = nullptr;
  229:     _sinkContext = nullptr;
  230:     _workLoop = nullptr;
  231:     if (_rxPool) {
  232:         _rxPool->release();
  233:         _rxPool = nullptr;
```

**RTW88WCLController.cpp:26-34**

```cpp
   26:     _packetPathInFlight = 0;
   27:     _pciBackend = nullptr;
   28:     _skywalkQueues = nullptr;
   29:     _rxAdapter = nullptr;
   30:     _stagedRxPackets.reset();
   31:     _radio = nullptr;
   32:     _baseStarted = false;
   33:     _radioStarted = false;
   34:     return true;
```

**RTW88WCLController.cpp:115-123**

```cpp
  115: 
  116:     /* Stage D: reserve native Skywalk queue/pool objects while the PCI and
  117:      * RTW88 owners are still available for orderly unwind. These objects are
  118:      * intentionally not registered or scheduled until packet descriptor
  119:      * conversion and hardware completion correlation are implemented. */
  120:     _skywalkQueues = new RTW88WCLSkywalkQueues;
  121:     if (!_skywalkQueues || !_skywalkQueues->init()) {
  122:         if (_skywalkQueues) {
  123:             _skywalkQueues->release();
```

**RTW88WCLController.cpp:135-148**

```cpp
  135:         }
  136:     }
  137: 
  138:     /* Stage E: bind the RX workloop consumer to the now-owned 4 KiB RX pool.
  139:      * It copies frames into native packet buffers, but its sink remains
  140:      * rejecting until the registration/completion ABI is closed. */
  141:     _rxAdapter = new RTW88WCLSkywalkRxAdapter;
  142:     if (!_rxAdapter || !_rxAdapter->init(
  143:             this, _workLoop, _skywalkQueues->rxPacketPool(),
  144:             &RTW88WCLController::stagedRxFrame, this)) {
  145:         if (_rxAdapter) {
  146:             _rxAdapter->release();
  147:             _rxAdapter = nullptr;
  148:         }
```

**RTW88WCLController.cpp:202-222**

```cpp
  202:         _rxAdapter->release();
  203:         _rxAdapter = nullptr;
  204:     }
  205: 
  206:     /* The RX adapter transfers accepted native packets into the controller's
  207:      * bounded ready ring. Recycle those packets while their pool still exists;
  208:      * on a pool error, retain the queue owner and PCI/backend context so a later
  209:      * stop/free attempt can retry rather than releasing live packet memory. */
  210:     const IOReturn recycleStatus = recycleStagedRxPackets();
  211:     if (recycleStatus != kIOReturnSuccess) {
  212:         IOLog("rtl88wifi-wcl: staged RX packet recycle deferred: 0x%08x\n",
  213:               recycleStatus);
  214:         return;
  215:     }
  216: 
  217:     /* Skywalk packet pools/queues are released only after both the mbuf staging
  218:      * adapter and the prepared-packet ownership ring have been drained. */
  219:     if (_skywalkQueues) {
  220:         _skywalkQueues->destroyQueues();
  221:         _skywalkQueues->release();
  222:         _skywalkQueues = nullptr;
```

**RTW88WCLController.cpp:494-529**

```cpp
  494:         mbuf_freem(packet);
  495:         return;
  496:     }
  497: 
  498:     /* enqueueFrame consumes the mbuf on both success and failure. The native
  499:      * RX completion queue is not registered yet, so the workloop sink below
  500:      * deliberately drops frames after staging rather than exposing them. */
  501:     (void)_rxAdapter->enqueueFrame(packet);
  502:     leavePacketPath();
  503: }
  504: 
  505: IOReturn RTW88WCLController::recycleStagedRxPackets()
  506: {
  507:     if (_stagedRxPackets.empty())
  508:         return kIOReturnSuccess;
  509:     if (!_skywalkQueues || !_skywalkQueues->rxPacketPool())
  510:         return kIOReturnNotReady;
  511: 
  512:     IOSkywalkPacketBufferPool *pool = _skywalkQueues->rxPacketPool();
  513:     IOSkywalkPacket *packet = nullptr;
  514:     bool disposalRequired = false;
  515:     while (_stagedRxPackets.pop(&packet)) {
  516:         if (!packet)
  517:             continue;
  518: 
  519:         const IOReturn status = pool->deallocatePacket(packet);
  520:         if (status != kIOReturnSuccess) {
  521:             /* The radio and RX event source are already quiesced, and these
  522:              * queues were never registered. If a packet cannot be returned
  523:              * individually, dispose the pool's packet set as one teardown
  524:              * operation before its memory segments are released. */
  525:             IOLog("rtl88wifi-wcl: RX packet recycle returned 0x%08x; pool disposal required\n",
  526:                   status);
  527:             disposalRequired = true;
  528:         }
  529:         packet = nullptr;
```

**RTW88WCLController.cpp:533-552**

```cpp
  533:         pool->disposeAllPackets();
  534:     return kIOReturnSuccess;
  535: }
  536: 
  537: bool RTW88WCLController::stagedRxFrame(
  538:     IOSkywalkPacket *preparedPacket, void *context)
  539: {
  540:     auto *self = static_cast<RTW88WCLController *>(context);
  541:     if (!self || !preparedPacket)
  542:         return false;
  543: 
  544:     /* Preserve the pool-backed packet in a fixed-capacity owner ring. The
  545:      * ring is bounded to the RX pool's 128 packets; overflow returns false,
  546:      * causing the RX adapter to recycle the packet immediately. No queue API
  547:      * is called here: completion-queue registration/ownership is still fenced. */
  548:     return self->_stagedRxPackets.push(preparedPacket);
  549: }
  550: 
  551: IOWorkLoop *RTW88WCLController::getRxWorkLoop()
  552: {
```

**RTW88WCLController.hpp:75-93**

```cpp
   75:      * Skywalk interface has completed registration. */
   76:     void rtw88Event(RTW88Event event, void *data) override;
   77: 
   78:     /* RTW88RxDelegate: receive mbufs enter a bounded workloop staging ring,
   79:      * then become pool-backed Skywalk packets. The sink still rejects them
   80:      * until the RX completion queue is registered and verified. */
   81:     mbuf_t allocateInputPacket(uint32_t length) override;
   82:     void injectRxFrame(mbuf_t packet) override;
   83:     IOWorkLoop *getRxWorkLoop() override;
   84:     void setLinkStatus(UInt32 status) override;
   85: 
   86: private:
   87:     void releaseNativeResources();
   88:     IOReturn recycleStagedRxPackets();
   89:     static bool stagedRxFrame(IOSkywalkPacket *preparedPacket, void *context);
   90: 
   91:     enum : uint32_t {
   92:         kPacketPathDisabled = 0,
   93:         kPacketPathActive = 1,
```

**RTW88WCLController.hpp:98-117**

```cpp
   98: 
   99:     bool enterPacketPath();
  100:     void leavePacketPath();
  101: 
  102:     static constexpr uint32_t kStagedRxPacketCapacity = 128;
  103: 
  104:     IOWorkLoop *_workLoop = nullptr;
  105:     IO80211SkywalkInterface *_packetPathInterface = nullptr; // retained while active
  106:     volatile uint32_t _packetPathState = kPacketPathDisabled;
  107:     volatile uint32_t _packetPathInFlight = 0;
  108:     RTW88WCLPCIBackend *_pciBackend = nullptr; // retained
  109:     RTW88WCLSkywalkQueues *_skywalkQueues = nullptr; // retained, unregistered
  110:     RTW88WCLSkywalkRxAdapter *_rxAdapter = nullptr; // retained, workloop-bound
  111:     /* Accepted RX packets remain pool-owned here until a verified completion
  112:      * queue can consume them. This ring is bounded to the RX pool packet count. */
  113:     RTW88WCLMbufRing<IOSkywalkPacket *, kStagedRxPacketCapacity> _stagedRxPackets;
  114:     RTW88IEEE80211 *_radio = nullptr;          // retained via bindRadioBackend
  115:     bool _baseStarted = false;
  116:     bool _radioStarted = false;
  117: };
```

### Manual questions

- [ ] What exact argument shape and packet-array ownership does the kernel callback require?
- [ ] At what instruction/API boundary does ownership transfer on success?
- [ ] What must happen on partial acceptance or callback failure?
- [ ] Which context invokes completion and what operations are legal there?

**Review outcome:** `UNRESOLVED — do not enable this contract`

## rx_submission_replenish: RX submission dequeue, buffer replenishment and retry ownership

**Status:** MANUAL_REVIEW_REQUIRED
**Candidate method bodies:** 283

### Kernel method candidates

| Class | Address | Instructions | Exact symbol | Assembly file |
|---|---:|---:|---|---|
| `IOSkywalkRxSubmissionQueue` | `0xffffff8002985724` | 56 | `__ZN26IOSkywalkRxSubmissionQueue8withPoolEP25IOSkywalkPacketBufferPooljjjP8OSObjectPFjS3_PS_PKP15IOSkywalkPacketjPvES9_j` | `asm/ZN26IOSkywalkRxSubmissionQueue8withPoolEP25IOSkywalkPacketBufferPooljjjP8OSObjectPFjS3_PS_PKP15IOSkywalkPacketjPvES9_j.asm.txt` |
| `IOSkywalkRxSubmissionQueue` | `0xffffff80029857d4` | 11 | `__ZN26IOSkywalkRxSubmissionQueue8withPoolEP25IOSkywalkPacketBufferPooljjjP8OSObjectPFjS3_PS_PP15IOSkywalkPacketjPvES8_j` | `asm/ZN26IOSkywalkRxSubmissionQueue8withPoolEP25IOSkywalkPacketBufferPooljjjP8OSObjectPFjS3_PS_PP15IOSkywalkPacketjPvES8_j.asm.txt` |
| `IOSkywalkRxSubmissionQueue` | `0xffffff80029857ee` | 80 | `__ZN26IOSkywalkRxSubmissionQueue12initWithPoolEP25IOSkywalkPacketBufferPooljjjP8OSObjectPFjS3_PS_PKP15IOSkywalkPacketjPvES9_j` | `asm/ZN26IOSkywalkRxSubmissionQueue12initWithPoolEP25IOSkywalkPacketBufferPooljjjP8OSObjectPFjS3_PS_PKP15IOSkywalkPacketjPvES9_j.asm.txt` |
| `IOSkywalkRxSubmissionQueue` | `0xffffff8002985914` | 15 | `__ZN26IOSkywalkRxSubmissionQueue12retryDequeueEv` | `asm/ZN26IOSkywalkRxSubmissionQueue12retryDequeueEv.asm.txt` |
| `IOSkywalkRxSubmissionQueue` | `0xffffff80029859de` | 7 | `__ZN26IOSkywalkRxSubmissionQueue20adjustPacketCountersEv` | `asm/ZN26IOSkywalkRxSubmissionQueue20adjustPacketCountersEv.asm.txt` |
| `IOSkywalkRxSubmissionQueue` | `0xffffff80029859fa` | 14 | `__ZN26IOSkywalkRxSubmissionQueue6enableEv` | `asm/ZN26IOSkywalkRxSubmissionQueue6enableEv.asm.txt` |
| `IOSkywalkRxSubmissionQueue` | `0xffffff8002985a26` | 25 | `__ZN26IOSkywalkRxSubmissionQueue7disableEv` | `asm/ZN26IOSkywalkRxSubmissionQueue7disableEv.asm.txt` |
| `IOSkywalkRxSubmissionQueue` | `0xffffff8002985a6c` | 122 | `__ZN26IOSkywalkRxSubmissionQueue12refillRxRingEj` | `asm/ZN26IOSkywalkRxSubmissionQueue12refillRxRingEj.asm.txt` |
| `IOSkywalkRxSubmissionQueue` | `0xffffff8002985c32` | 32 | `__ZN26IOSkywalkRxSubmissionQueue12purgePacketsEv` | `asm/ZN26IOSkywalkRxSubmissionQueue12purgePacketsEv.asm.txt` |
| `IOSkywalkRxSubmissionQueue` | `0xffffff8002985caa` | 19 | `__ZN26IOSkywalkRxSubmissionQueue16packetCompletionEP15IOSkywalkPacketP20IOSkywalkPacketQueuej` | `asm/ZN26IOSkywalkRxSubmissionQueue16packetCompletionEP15IOSkywalkPacketP20IOSkywalkPacketQueuej.asm.txt` |
| `IOSkywalkRxSubmissionQueue` | `0xffffff8002985e2e` | 84 | `__ZN26IOSkywalkRxSubmissionQueue12addReportersEP9IOServiceP5OSSet` | `asm/ZN26IOSkywalkRxSubmissionQueue12addReportersEP9IOServiceP5OSSet.asm.txt` |
| `IOSkywalkRxSubmissionQueue` | `0xffffff80029a3028` | 58 | `__ZN26IOSkywalkRxSubmissionQueue12gatedDequeueEPv` | `asm/ZN26IOSkywalkRxSubmissionQueue12gatedDequeueEPv.asm.txt` |
| `IOSkywalkRxSubmissionQueue` | `0xffffff80029a30f2` | 79 | `__ZN26IOSkywalkRxSubmissionQueue13legacyDequeueEPv` | `asm/ZN26IOSkywalkRxSubmissionQueue13legacyDequeueEPv.asm.txt` |
| `IOSkywalkRxSubmissionQueue` | `0xffffff80029a31fa` | 124 | `__ZN26IOSkywalkRxSubmissionQueue11listDequeueEPv` | `asm/ZN26IOSkywalkRxSubmissionQueue11listDequeueEPv.asm.txt` |
| `IOSkywalkRxSubmissionQueue` | `0xffffff80029a33c0` | 45 | `__ZN26IOSkywalkRxSubmissionQueue14requestDequeueEPvj` | `asm/ZN26IOSkywalkRxSubmissionQueue14requestDequeueEPvj.asm.txt` |
| `IOSkywalkRxSubmissionQueue` | `0xffffff80029a3450` | 20 | `__ZNK26IOSkywalkRxSubmissionQueue14getPacketCountEv` | `asm/ZNK26IOSkywalkRxSubmissionQueue14getPacketCountEv.asm.txt` |
| `IOSkywalkRxSubmissionQueue` | `0xffffff80029a3486` | 13 | `__ZN26IOSkywalkRxSubmissionQueue16packetCompletionEP15IOSkywalkPacketP20IOSkywalkPacketQueuej.cold.1` | `asm/ZN26IOSkywalkRxSubmissionQueue16packetCompletionEP15IOSkywalkPacketP20IOSkywalkPacketQueuej.cold.1.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff800298077a` | 15 | `__ZN20IOSkywalkPacketQueue9MetaClassC1Ev` | `asm/ZN20IOSkywalkPacketQueue9MetaClassC1Ev.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff80029807ac` | 4 | `__ZN20IOSkywalkPacketQueue9MetaClassD1Ev` | `asm/ZN20IOSkywalkPacketQueue9MetaClassD1Ev.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff80029807b6` | 13 | `__ZN20IOSkywalkPacketQueueC2EPK11OSMetaClass` | `asm/ZN20IOSkywalkPacketQueueC2EPK11OSMetaClass.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff80029807d6` | 4 | `__ZN20IOSkywalkPacketQueueD2Ev` | `asm/ZN20IOSkywalkPacketQueueD2Ev.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff80029807e0` | 3 | `__ZN20IOSkywalkPacketQueueD1Ev` | `asm/ZN20IOSkywalkPacketQueueD1Ev.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff80029807e6` | 3 | `__ZN20IOSkywalkPacketQueueD0Ev` | `asm/ZN20IOSkywalkPacketQueueD0Ev.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff80029807ec` | 6 | `__ZNK20IOSkywalkPacketQueue12getMetaClassEv` | `asm/ZNK20IOSkywalkPacketQueue12getMetaClassEv.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff80029807fa` | 15 | `__ZN20IOSkywalkPacketQueue9MetaClassC2Ev` | `asm/ZN20IOSkywalkPacketQueue9MetaClassC2Ev.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff800298082c` | 5 | `__ZNK20IOSkywalkPacketQueue9MetaClass5allocEv` | `asm/ZNK20IOSkywalkPacketQueue9MetaClass5allocEv.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff8002980834` | 6 | `__ZN20IOSkywalkPacketQueuenwEm` | `asm/ZN20IOSkywalkPacketQueuenwEm.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff8002980848` | 8 | `__ZN20IOSkywalkPacketQueuedlEPvm` | `asm/ZN20IOSkywalkPacketQueuedlEPvm.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff8002980860` | 56 | `__ZN20IOSkywalkPacketQueue12initWithPoolEP25IOSkywalkPacketBufferPooljjjjP8OSObjectPFvS3_zEPv` | `asm/ZN20IOSkywalkPacketQueue12initWithPoolEP25IOSkywalkPacketBufferPooljjjjP8OSObjectPFvS3_zEPv.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff800298091a` | 20 | `__ZN20IOSkywalkPacketQueue4freeEv` | `asm/ZN20IOSkywalkPacketQueue4freeEv.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff800298095a` | 54 | `__ZN20IOSkywalkPacketQueue10initializeEPv` | `asm/ZN20IOSkywalkPacketQueue10initializeEPv.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff8002980a20` | 21 | `__ZNK20IOSkywalkPacketQueue12getInterfaceEv` | `asm/ZNK20IOSkywalkPacketQueue12getInterfaceEv.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff8002980a58` | 35 | `__ZN20IOSkywalkPacketQueue8finalizeEv` | `asm/ZN20IOSkywalkPacketQueue8finalizeEv.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff8002980ac0` | 15 | `__ZN20IOSkywalkPacketQueue7disableEv` | `asm/ZN20IOSkywalkPacketQueue7disableEv.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff8002980aee` | 25 | `__ZN20IOSkywalkPacketQueue9resetABFSEv` | `asm/ZN20IOSkywalkPacketQueue9resetABFSEv.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff8002980b44` | 6 | `__ZN20IOSkywalkPacketQueue11synchronizeEj` | `asm/ZN20IOSkywalkPacketQueue11synchronizeEj.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff8002980b50` | 6 | `__ZN20IOSkywalkPacketQueue16packetSubmissionEPyPjS1_` | `asm/ZN20IOSkywalkPacketQueue16packetSubmissionEPyPjS1_.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff8002980b5c` | 6 | `__ZN20IOSkywalkPacketQueue16packetSubmissionEb` | `asm/ZN20IOSkywalkPacketQueue16packetSubmissionEb.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff8002980b68` | 6 | `__ZN20IOSkywalkPacketQueue16sendNotificationEj` | `asm/ZN20IOSkywalkPacketQueue16sendNotificationEj.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff8002980b74` | 5 | `__ZNK20IOSkywalkPacketQueue12getDirectionEv` | `asm/ZNK20IOSkywalkPacketQueue12getDirectionEv.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff8002980b80` | 5 | `__ZNK20IOSkywalkPacketQueue10getQueueIdEv` | `asm/ZNK20IOSkywalkPacketQueue10getQueueIdEv.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff8002980b8c` | 5 | `__ZNK20IOSkywalkPacketQueue11getCapacityEv` | `asm/ZNK20IOSkywalkPacketQueue11getCapacityEv.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff8002980b98` | 5 | `__ZNK20IOSkywalkPacketQueue13getBufferSizeEv` | `asm/ZNK20IOSkywalkPacketQueue13getBufferSizeEv.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff8002980ba4` | 5 | `__ZNK20IOSkywalkPacketQueue12isQueueReadyEv` | `asm/ZNK20IOSkywalkPacketQueue12isQueueReadyEv.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff8002980bb0` | 5 | `__ZNK20IOSkywalkPacketQueue15getServiceClassEv` | `asm/ZNK20IOSkywalkPacketQueue15getServiceClassEv.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff8002980bbc` | 5 | `__ZNK20IOSkywalkPacketQueue9getRefconEv` | `asm/ZNK20IOSkywalkPacketQueue9getRefconEv.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff8002980bc6` | 5 | `__ZNK20IOSkywalkPacketQueue19getPacketBufferPoolEv` | `asm/ZNK20IOSkywalkPacketQueue19getPacketBufferPoolEv.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff8002980bd0` | 6 | `__ZN20IOSkywalkPacketQueue19setPacketBufferPoolEP25IOSkywalkPacketBufferPool` | `asm/ZN20IOSkywalkPacketQueue19setPacketBufferPoolEP25IOSkywalkPacketBufferPool.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff8002980bdc` | 6 | `__ZN20IOSkywalkPacketQueue15setPacketPollerEP21IOSkywalkPacketPoller` | `asm/ZN20IOSkywalkPacketQueue15setPacketPollerEP21IOSkywalkPacketPoller.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff8002980be8` | 5 | `__ZNK20IOSkywalkPacketQueue20getPacketBufferCountEv` | `asm/ZNK20IOSkywalkPacketQueue20getPacketBufferCountEv.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff8002980bf0` | 19 | `__ZNK20IOSkywalkPacketQueue12getFreeSpaceEv` | `asm/ZNK20IOSkywalkPacketQueue12getFreeSpaceEv.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff8002980c1e` | 7 | `__ZN20IOSkywalkPacketQueue16packetCompletionEP15IOSkywalkPacketPS_j` | `asm/ZN20IOSkywalkPacketQueue16packetCompletionEP15IOSkywalkPacketPS_j.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff8002980c3c` | 7 | `__ZN20IOSkywalkPacketQueue16bufferCompletionEP21IOSkywalkPacketBufferPS_j` | `asm/ZN20IOSkywalkPacketQueue16bufferCompletionEP21IOSkywalkPacketBufferPS_j.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff8002980c5a` | 6 | `__ZN20IOSkywalkPacketQueue14performCommandEjPvm` | `asm/ZN20IOSkywalkPacketQueue14performCommandEjPvm.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff8002980c66` | 19 | `__ZN20IOSkywalkPacketQueue12setInterfaceEP18IOSkywalkInterface` | `asm/ZN20IOSkywalkPacketQueue12setInterfaceEP18IOSkywalkInterface.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff8002980c9a` | 20 | `__ZN20IOSkywalkPacketQueue18statGetElapsedTimeEPKy` | `asm/ZN20IOSkywalkPacketQueue18statGetElapsedTimeEPKy.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff8002980cd8` | 5 | `__ZN20IOSkywalkPacketQueue17setKernNetifQueueEP11netif_queue` | `asm/ZN20IOSkywalkPacketQueue17setKernNetifQueueEP11netif_queue.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff8002980ce2` | 5 | `__ZN20IOSkywalkPacketQueue17getKernNetifQueueEv` | `asm/ZN20IOSkywalkPacketQueue17getKernNetifQueueEv.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff8002980cec` | 6 | `__ZN20IOSkywalkPacketQueue11getQueueSetEv` | `asm/ZN20IOSkywalkPacketQueue11getQueueSetEv.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff8002980cfa` | 6 | `__ZN20IOSkywalkPacketQueue11setQueueSetEP17IOSkywalkQueueSet` | `asm/ZN20IOSkywalkPacketQueue11setQueueSetEP17IOSkywalkQueueSet.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff8002980d08` | 80 | `__ZN20IOSkywalkPacketQueue14getDescriptionEPcm` | `asm/ZN20IOSkywalkPacketQueue14getDescriptionEPcm.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff8002980e2a` | 6 | `__ZN20IOSkywalkPacketQueue10setOwnerIdEy` | `asm/ZN20IOSkywalkPacketQueue10setOwnerIdEy.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff8002980e38` | 11 | `__ZN20IOSkywalkPacketQueue17setTraceTagActionEPFtPS_E` | `asm/ZN20IOSkywalkPacketQueue17setTraceTagActionEPFtPS_E.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff8002980e54` | 25 | `__ZN20IOSkywalkPacketQueue8initABFSEv` | `asm/ZN20IOSkywalkPacketQueue8initABFSEv.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff8002980eae` | 7 | `__ZN20IOSkywalkPacketQueue21setABFSHysteresisTimeEj` | `asm/ZN20IOSkywalkPacketQueue21setABFSHysteresisTimeEj.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff8002980ec2` | 37 | `__ZN20IOSkywalkPacketQueue14notifySrcQueueEbPS_j` | `asm/ZN20IOSkywalkPacketQueue14notifySrcQueueEbPS_j.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff8002980f36` | 32 | `__ZN20IOSkywalkPacketQueue16packetSubmissionEjj` | `asm/ZN20IOSkywalkPacketQueue16packetSubmissionEjj.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff8002980f88` | 146 | `__ZN20IOSkywalkPacketQueue16packetCompletionEjjb` | `asm/ZN20IOSkywalkPacketQueue16packetCompletionEjjb.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff800298115a` | 10 | `__ZN20IOSkywalkPacketQueue18queryByteFreeSpaceEv` | `asm/ZN20IOSkywalkPacketQueue18queryByteFreeSpaceEv.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff8002981170` | 7 | `__ZN20IOSkywalkPacketQueue30_RESERVEDIOSkywalkPacketQueue0Ev` | `asm/ZN20IOSkywalkPacketQueue30_RESERVEDIOSkywalkPacketQueue0Ev.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff8002981184` | 6 | `__ZN20IOSkywalkPacketQueue30_RESERVEDIOSkywalkPacketQueue1Ev` | `asm/ZN20IOSkywalkPacketQueue30_RESERVEDIOSkywalkPacketQueue1Ev.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff800298119a` | 6 | `__ZN20IOSkywalkPacketQueue30_RESERVEDIOSkywalkPacketQueue2Ev` | `asm/ZN20IOSkywalkPacketQueue30_RESERVEDIOSkywalkPacketQueue2Ev.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff80029811b0` | 6 | `__ZN20IOSkywalkPacketQueue30_RESERVEDIOSkywalkPacketQueue3Ev` | `asm/ZN20IOSkywalkPacketQueue30_RESERVEDIOSkywalkPacketQueue3Ev.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff80029811c6` | 6 | `__ZN20IOSkywalkPacketQueue30_RESERVEDIOSkywalkPacketQueue4Ev` | `asm/ZN20IOSkywalkPacketQueue30_RESERVEDIOSkywalkPacketQueue4Ev.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff80029811dc` | 6 | `__ZN20IOSkywalkPacketQueue30_RESERVEDIOSkywalkPacketQueue5Ev` | `asm/ZN20IOSkywalkPacketQueue30_RESERVEDIOSkywalkPacketQueue5Ev.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff80029811f2` | 6 | `__ZN20IOSkywalkPacketQueue30_RESERVEDIOSkywalkPacketQueue6Ev` | `asm/ZN20IOSkywalkPacketQueue30_RESERVEDIOSkywalkPacketQueue6Ev.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff8002981208` | 6 | `__ZN20IOSkywalkPacketQueue30_RESERVEDIOSkywalkPacketQueue7Ev` | `asm/ZN20IOSkywalkPacketQueue30_RESERVEDIOSkywalkPacketQueue7Ev.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff800298121e` | 6 | `__ZN20IOSkywalkPacketQueue30_RESERVEDIOSkywalkPacketQueue8Ev` | `asm/ZN20IOSkywalkPacketQueue30_RESERVEDIOSkywalkPacketQueue8Ev.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff8002981234` | 6 | `__ZN20IOSkywalkPacketQueue30_RESERVEDIOSkywalkPacketQueue9Ev` | `asm/ZN20IOSkywalkPacketQueue30_RESERVEDIOSkywalkPacketQueue9Ev.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff800298124a` | 6 | `__ZN20IOSkywalkPacketQueue31_RESERVEDIOSkywalkPacketQueue10Ev` | `asm/ZN20IOSkywalkPacketQueue31_RESERVEDIOSkywalkPacketQueue10Ev.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff8002981260` | 4 | `__ZN20IOSkywalkPacketQueue9MetaClassD0Ev` | `asm/ZN20IOSkywalkPacketQueue9MetaClassD0Ev.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297c9ec` | 15 | `__ZN25IOSkywalkPacketBufferPool9MetaClassC1Ev` | `asm/ZN25IOSkywalkPacketBufferPool9MetaClassC1Ev.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297ca1e` | 4 | `__ZN25IOSkywalkPacketBufferPool9MetaClassD1Ev` | `asm/ZN25IOSkywalkPacketBufferPool9MetaClassD1Ev.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297ca28` | 13 | `__ZN25IOSkywalkPacketBufferPoolC2EPK11OSMetaClass` | `asm/ZN25IOSkywalkPacketBufferPoolC2EPK11OSMetaClass.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297ca48` | 13 | `__ZN25IOSkywalkPacketBufferPoolC1EPK11OSMetaClass` | `asm/ZN25IOSkywalkPacketBufferPoolC1EPK11OSMetaClass.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297ca68` | 4 | `__ZN25IOSkywalkPacketBufferPoolD2Ev` | `asm/ZN25IOSkywalkPacketBufferPoolD2Ev.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297ca72` | 4 | `__ZN25IOSkywalkPacketBufferPoolD1Ev` | `asm/ZN25IOSkywalkPacketBufferPoolD1Ev.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297ca7c` | 13 | `__ZN25IOSkywalkPacketBufferPoolD0Ev` | `asm/ZN25IOSkywalkPacketBufferPoolD0Ev.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297caa4` | 8 | `__ZN25IOSkywalkPacketBufferPooldlEPvm` | `asm/ZN25IOSkywalkPacketBufferPooldlEPvm.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297cabc` | 6 | `__ZNK25IOSkywalkPacketBufferPool12getMetaClassEv` | `asm/ZNK25IOSkywalkPacketBufferPool12getMetaClassEv.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297caca` | 15 | `__ZN25IOSkywalkPacketBufferPool9MetaClassC2Ev` | `asm/ZN25IOSkywalkPacketBufferPool9MetaClassC2Ev.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297cafc` | 22 | `__ZNK25IOSkywalkPacketBufferPool9MetaClass5allocEv` | `asm/ZNK25IOSkywalkPacketBufferPool9MetaClass5allocEv.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297cb44` | 6 | `__ZN25IOSkywalkPacketBufferPoolnwEm` | `asm/ZN25IOSkywalkPacketBufferPoolnwEm.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297cb58` | 16 | `__ZN25IOSkywalkPacketBufferPoolC1Ev` | `asm/ZN25IOSkywalkPacketBufferPoolC1Ev.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297cb88` | 16 | `__ZN25IOSkywalkPacketBufferPoolC2Ev` | `asm/ZN25IOSkywalkPacketBufferPoolC2Ev.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297cbb8` | 47 | `__ZN25IOSkywalkPacketBufferPool8withNameEPKcP8OSObjectjPKNS_11PoolOptionsE` | `asm/ZN25IOSkywalkPacketBufferPool8withNameEPKcP8OSObjectjPKNS_11PoolOptionsE.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297cc46` | 7 | `__ZN25IOSkywalkPacketBufferPool12initWithNameEPKcPvjPKNS_11PoolOptionsE` | `asm/ZN25IOSkywalkPacketBufferPool12initWithNameEPKcPvjPKNS_11PoolOptionsE.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297cc58` | 263 | `__ZN25IOSkywalkPacketBufferPool12initWithNameEPKcP8OSObjectjPKNS_11PoolOptionsE` | `asm/ZN25IOSkywalkPacketBufferPool12initWithNameEPKcP8OSObjectjPKNS_11PoolOptionsE.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297d0c6` | 58 | `__ZN25IOSkywalkPacketBufferPool27reportingChangeNotificationEv` | `asm/ZN25IOSkywalkPacketBufferPool27reportingChangeNotificationEv.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297d17c` | 51 | `__ZN25IOSkywalkPacketBufferPool18segmentConstructorEP13kern_pbufpoolP9sksegmentP18IOMemoryDescriptor` | `asm/ZN25IOSkywalkPacketBufferPool18segmentConstructorEP13kern_pbufpoolP9sksegmentP18IOMemoryDescriptor.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297d20e` | 31 | `__ZN25IOSkywalkPacketBufferPool17segmentDestructorEP13kern_pbufpoolP9sksegmentP18IOMemoryDescriptor` | `asm/ZN25IOSkywalkPacketBufferPool17segmentDestructorEP13kern_pbufpoolP9sksegmentP18IOMemoryDescriptor.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297d276` | 26 | `__ZNK25IOSkywalkPacketBufferPool7releaseEv` | `asm/ZNK25IOSkywalkPacketBufferPool7releaseEv.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297d2ca` | 46 | `__ZN25IOSkywalkPacketBufferPool17disposeAllPacketsEv` | `asm/ZN25IOSkywalkPacketBufferPool17disposeAllPacketsEv.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297d366` | 22 | `__ZN25IOSkywalkPacketBufferPool17disposeAllBuffersEv` | `asm/ZN25IOSkywalkPacketBufferPool17disposeAllBuffersEv.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297d3bc` | 57 | `__ZN25IOSkywalkPacketBufferPool4freeEv` | `asm/ZN25IOSkywalkPacketBufferPool4freeEv.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297d4c0` | 27 | `__ZN25IOSkywalkPacketBufferPool17releaseAllPacketsEv` | `asm/ZN25IOSkywalkPacketBufferPool17releaseAllPacketsEv.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297d518` | 19 | `__ZN25IOSkywalkPacketBufferPool24releaseAllMemorySegmentsEv` | `asm/ZN25IOSkywalkPacketBufferPool24releaseAllMemorySegmentsEv.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297d556` | 18 | `__ZNK25IOSkywalkPacketBufferPool11getPoolNameEv` | `asm/ZNK25IOSkywalkPacketBufferPool11getPoolNameEv.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297d592` | 15 | `__ZN25IOSkywalkPacketBufferPool19acquireKernelPacketEy` | `asm/ZN25IOSkywalkPacketBufferPool19acquireKernelPacketEy.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297d5b6` | 44 | `__ZN25IOSkywalkPacketBufferPool21allocateKernelPacketsEjPyPjj` | `asm/ZN25IOSkywalkPacketBufferPool21allocateKernelPacketsEjPyPjj.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297d626` | 18 | `__ZN25IOSkywalkPacketBufferPool16freeKernelPacketEy` | `asm/ZN25IOSkywalkPacketBufferPool16freeKernelPacketEy.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297d65a` | 14 | `__ZN25IOSkywalkPacketBufferPool19disposeKernelPacketEy` | `asm/ZN25IOSkywalkPacketBufferPool19disposeKernelPacketEy.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297d680` | 35 | `__ZN25IOSkywalkPacketBufferPool17freeKernelPacketsEPyj` | `asm/ZN25IOSkywalkPacketBufferPool17freeKernelPacketsEPyj.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297d6dc` | 11 | `__ZNK25IOSkywalkPacketBufferPool24getKernelPacketWithIndexEj` | `asm/ZNK25IOSkywalkPacketBufferPool24getKernelPacketWithIndexEj.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297d6f4` | 7 | `__ZN25IOSkywalkPacketBufferPool28disposeKernelPacketWithIndexEyj` | `asm/ZN25IOSkywalkPacketBufferPool28disposeKernelPacketWithIndexEyj.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297d708` | 7 | `__ZN25IOSkywalkPacketBufferPool28acquireKernelPacketWithIndexEyj` | `asm/ZN25IOSkywalkPacketBufferPool28acquireKernelPacketWithIndexEyj.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297d718` | 16 | `__ZNK25IOSkywalkPacketBufferPool26getMemorySegmentWithHandleEP9sksegment` | `asm/ZNK25IOSkywalkPacketBufferPool26getMemorySegmentWithHandleEP9sksegment.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297d742` | 28 | `__ZN25IOSkywalkPacketBufferPool9newPacketEP25IOSkywalkPacketDescriptorPP15IOSkywalkPacket` | `asm/ZN25IOSkywalkPacketBufferPool9newPacketEP25IOSkywalkPacketDescriptorPP15IOSkywalkPacket.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297d78c` | 16 | `__ZN25IOSkywalkPacketBufferPool15newPacketBufferEP31IOSkywalkPacketBufferDescriptorPP21IOSkywalkPacketBuffer` | `asm/ZN25IOSkywalkPacketBufferPool15newPacketBufferEP31IOSkywalkPacketBufferDescriptorPP21IOSkywalkPacketBuffer.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297d7b4` | 16 | `__ZN25IOSkywalkPacketBufferPool16newMemorySegmentEP32IOSkywalkMemorySegmentDescriptorPP22IOSkywalkMemorySegment` | `asm/ZN25IOSkywalkPacketBufferPool16newMemorySegmentEP32IOSkywalkMemorySegmentDescriptorPP22IOSkywalkMemorySegment.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297d7dc` | 16 | `__ZNK25IOSkywalkPacketBufferPool19getPacketWithHandleEy` | `asm/ZNK25IOSkywalkPacketBufferPool19getPacketWithHandleEy.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297d806` | 17 | `__ZNK25IOSkywalkPacketBufferPool18getPacketWithIndexEj` | `asm/ZNK25IOSkywalkPacketBufferPool18getPacketWithIndexEj.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297d82e` | 10 | `__ZN25IOSkywalkPacketBufferPool14allocatePacketEPP15IOSkywalkPacketj` | `asm/ZN25IOSkywalkPacketBufferPool14allocatePacketEPP15IOSkywalkPacketj.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297d84a` | 38 | `__ZN25IOSkywalkPacketBufferPool22completePreparedPacketEP15IOSkywalkPacket` | `asm/ZN25IOSkywalkPacketBufferPool22completePreparedPacketEP15IOSkywalkPacket.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297d8ae` | 29 | `__ZN25IOSkywalkPacketBufferPool20deallocatePacketListEP15IOSkywalkPacket` | `asm/ZN25IOSkywalkPacketBufferPool20deallocatePacketListEP15IOSkywalkPacket.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297da3c` | 46 | `__ZN25IOSkywalkPacketBufferPool18checkInPacketQueueEPK20IOSkywalkPacketQueue` | `asm/ZN25IOSkywalkPacketBufferPool18checkInPacketQueueEPK20IOSkywalkPacketQueue.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297dad0` | 63 | `__ZN25IOSkywalkPacketBufferPool19checkOutPacketQueueEPK20IOSkywalkPacketQueue` | `asm/ZN25IOSkywalkPacketBufferPool19checkOutPacketQueueEPK20IOSkywalkPacketQueue.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297dbb6` | 36 | `__ZN25IOSkywalkPacketBufferPool23checkInReportingServiceEP9IOServicePK18IOSkywalkInterface` | `asm/ZN25IOSkywalkPacketBufferPool23checkInReportingServiceEP9IOServicePK18IOSkywalkInterface.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297dc2e` | 67 | `__ZN25IOSkywalkPacketBufferPool25createReportersForServiceEP9IOServicePK18IOSkywalkInterface` | `asm/ZN25IOSkywalkPacketBufferPool25createReportersForServiceEP9IOServicePK18IOSkywalkInterface.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297dd18` | 22 | `__ZN25IOSkywalkPacketBufferPool24checkOutReportingServiceEPK9IOService` | `asm/ZN25IOSkywalkPacketBufferPool24checkOutReportingServiceEPK9IOService.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297dd64` | 48 | `__ZN25IOSkywalkPacketBufferPool25removeReportersForServiceEPK9IOService` | `asm/ZN25IOSkywalkPacketBufferPool25removeReportersForServiceEPK9IOService.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297ddf2` | 69 | `__ZN25IOSkywalkPacketBufferPool15addPoolReporterEP9IOServiceP5OSSet` | `asm/ZN25IOSkywalkPacketBufferPool15addPoolReporterEP9IOServiceP5OSSet.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297ded4` | 56 | `__ZN25IOSkywalkPacketBufferPool23copyReportersForServiceEPK9IOService` | `asm/ZN25IOSkywalkPacketBufferPool23copyReportersForServiceEPK9IOService.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297df90` | 62 | `__ZN25IOSkywalkPacketBufferPool21getReportChannelValueEy` | `asm/ZN25IOSkywalkPacketBufferPool21getReportChannelValueEy.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297e038` | 4 | `__ZN25IOSkywalkPacketBufferPool9MetaClassD0Ev` | `asm/ZN25IOSkywalkPacketBufferPool9MetaClassD0Ev.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff80029a1aca` | 33 | `__ZN25IOSkywalkPacketBufferPool20allocateKernelPacketEjPyj` | `asm/ZN25IOSkywalkPacketBufferPool20allocateKernelPacketEjPyj.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff80029a1b1c` | 122 | `__ZN25IOSkywalkPacketBufferPool20createSegmentBuffersEP22IOSkywalkMemorySegmentjb` | `asm/ZN25IOSkywalkPacketBufferPool20createSegmentBuffersEP22IOSkywalkMemorySegmentjb.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff80029a1cb2` | 16 | `__ZN25IOSkywalkPacketBufferPool21destroySegmentBuffersEP22IOSkywalkMemorySegment` | `asm/ZN25IOSkywalkPacketBufferPool21destroySegmentBuffersEP22IOSkywalkMemorySegment.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff80029a1cda` | 73 | `__ZN25IOSkywalkPacketBufferPool20prepareMemorySegmentEP22IOSkywalkMemorySegmentP24IOBufferMemoryDescriptory` | `asm/ZN25IOSkywalkPacketBufferPool20prepareMemorySegmentEP22IOSkywalkMemorySegmentP24IOBufferMemoryDescriptory.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff80029a1dc8` | 31 | `__ZNK25IOSkywalkPacketBufferPool31getPacketBufferWithBufletHandleEP13__kern_buflet` | `asm/ZNK25IOSkywalkPacketBufferPool31getPacketBufferWithBufletHandleEP13__kern_buflet.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff80029a1e20` | 28 | `__ZNK25IOSkywalkPacketBufferPool30getPacketBufferWithSegmentInfoEP9sksegmentj` | `asm/ZNK25IOSkywalkPacketBufferPool30getPacketBufferWithSegmentInfoEP9sksegmentj.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff80029a1e66` | 55 | `__ZN25IOSkywalkPacketBufferPool14allocatePacketEjPP15IOSkywalkPacketj` | `asm/ZN25IOSkywalkPacketBufferPool14allocatePacketEjPP15IOSkywalkPacketj.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff80029a1f10` | 108 | `__ZN25IOSkywalkPacketBufferPool15allocatePacketsEjPjPP15IOSkywalkPacketj` | `asm/ZN25IOSkywalkPacketBufferPool15allocatePacketsEjPjPP15IOSkywalkPacketj.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff80029a2072` | 28 | `__ZN25IOSkywalkPacketBufferPool16deallocatePacketEP15IOSkywalkPacket` | `asm/ZN25IOSkywalkPacketBufferPool16deallocatePacketEP15IOSkywalkPacket.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff80029a20be` | 53 | `__ZN25IOSkywalkPacketBufferPool17deallocatePacketsEPP15IOSkywalkPacketj` | `asm/ZN25IOSkywalkPacketBufferPool17deallocatePacketsEPP15IOSkywalkPacketj.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff80029a214a` | 10 | `__ZN25IOSkywalkPacketBufferPool21deallocatePacketChainEy` | `asm/ZN25IOSkywalkPacketBufferPool21deallocatePacketChainEy.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff80029a2160` | 49 | `__ZN25IOSkywalkPacketBufferPool20allocatePacketBufferEPP21IOSkywalkPacketBufferj` | `asm/ZN25IOSkywalkPacketBufferPool20allocatePacketBufferEPP21IOSkywalkPacketBufferj.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff80029a21fe` | 48 | `__ZN25IOSkywalkPacketBufferPool21allocatePacketBuffersEPjPP21IOSkywalkPacketBufferj` | `asm/ZN25IOSkywalkPacketBufferPool21allocatePacketBuffersEPjPP21IOSkywalkPacketBufferj.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff80029a2278` | 32 | `__ZN25IOSkywalkPacketBufferPool22deallocatePacketBufferEP21IOSkywalkPacketBuffer` | `asm/ZN25IOSkywalkPacketBufferPool22deallocatePacketBufferEP21IOSkywalkPacketBuffer.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff80029a22d0` | 28 | `__ZN25IOSkywalkPacketBufferPool23deallocatePacketBuffersEPP21IOSkywalkPacketBufferj` | `asm/ZN25IOSkywalkPacketBufferPool23deallocatePacketBuffersEPP21IOSkywalkPacketBufferj.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff80029a2316` | 25 | `__ZN25IOSkywalkPacketBufferPool17segmentDestructorEP13kern_pbufpoolP9sksegmentP18IOMemoryDescriptor.cold.1` | `asm/ZN25IOSkywalkPacketBufferPool17segmentDestructorEP13kern_pbufpoolP9sksegmentP18IOMemoryDescriptor.cold.1.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff80029a235f` | 15 | `__ZN25IOSkywalkPacketBufferPool9newPacketEP25IOSkywalkPacketDescriptorPP15IOSkywalkPacket.cold.1` | `asm/ZN25IOSkywalkPacketBufferPool9newPacketEP25IOSkywalkPacketDescriptorPP15IOSkywalkPacket.cold.1.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297e876` | 15 | `__ZN21IOSkywalkPacketBuffer9MetaClassC1Ev` | `asm/ZN21IOSkywalkPacketBuffer9MetaClassC1Ev.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297e8a8` | 4 | `__ZN21IOSkywalkPacketBuffer9MetaClassD1Ev` | `asm/ZN21IOSkywalkPacketBuffer9MetaClassD1Ev.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297e8b2` | 13 | `__ZN21IOSkywalkPacketBufferC2EPK11OSMetaClass` | `asm/ZN21IOSkywalkPacketBufferC2EPK11OSMetaClass.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297e8d2` | 13 | `__ZN21IOSkywalkPacketBufferC1EPK11OSMetaClass` | `asm/ZN21IOSkywalkPacketBufferC1EPK11OSMetaClass.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297e8f2` | 4 | `__ZN21IOSkywalkPacketBufferD2Ev` | `asm/ZN21IOSkywalkPacketBufferD2Ev.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297e8fc` | 4 | `__ZN21IOSkywalkPacketBufferD1Ev` | `asm/ZN21IOSkywalkPacketBufferD1Ev.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297e906` | 13 | `__ZN21IOSkywalkPacketBufferD0Ev` | `asm/ZN21IOSkywalkPacketBufferD0Ev.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297e92e` | 8 | `__ZN21IOSkywalkPacketBufferdlEPvm` | `asm/ZN21IOSkywalkPacketBufferdlEPvm.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297e946` | 6 | `__ZNK21IOSkywalkPacketBuffer12getMetaClassEv` | `asm/ZNK21IOSkywalkPacketBuffer12getMetaClassEv.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297e954` | 15 | `__ZN21IOSkywalkPacketBuffer9MetaClassC2Ev` | `asm/ZN21IOSkywalkPacketBuffer9MetaClassC2Ev.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297e986` | 22 | `__ZNK21IOSkywalkPacketBuffer9MetaClass5allocEv` | `asm/ZNK21IOSkywalkPacketBuffer9MetaClass5allocEv.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297e9ce` | 6 | `__ZN21IOSkywalkPacketBuffernwEm` | `asm/ZN21IOSkywalkPacketBuffernwEm.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297e9e2` | 16 | `__ZN21IOSkywalkPacketBufferC1Ev` | `asm/ZN21IOSkywalkPacketBufferC1Ev.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297ea12` | 16 | `__ZN21IOSkywalkPacketBufferC2Ev` | `asm/ZN21IOSkywalkPacketBufferC2Ev.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297ea42` | 45 | `__ZN21IOSkywalkPacketBuffer8withPoolEP25IOSkywalkPacketBufferPoolP31IOSkywalkPacketBufferDescriptorj` | `asm/ZN21IOSkywalkPacketBuffer8withPoolEP25IOSkywalkPacketBufferPoolP31IOSkywalkPacketBufferDescriptorj.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297eac8` | 48 | `__ZN21IOSkywalkPacketBuffer12initWithPoolEP25IOSkywalkPacketBufferPoolP31IOSkywalkPacketBufferDescriptorj` | `asm/ZN21IOSkywalkPacketBuffer12initWithPoolEP25IOSkywalkPacketBufferPoolP31IOSkywalkPacketBufferDescriptorj.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297eb56` | 25 | `__ZN21IOSkywalkPacketBuffer4freeEv` | `asm/ZN21IOSkywalkPacketBuffer4freeEv.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297ebac` | 5 | `__ZNK21IOSkywalkPacketBuffer19getPacketBufferPoolEv` | `asm/ZNK21IOSkywalkPacketBuffer19getPacketBufferPoolEv.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297ebb6` | 5 | `__ZNK21IOSkywalkPacketBuffer9getPacketEv` | `asm/ZNK21IOSkywalkPacketBuffer9getPacketEv.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297ebc0` | 7 | `__ZNK21IOSkywalkPacketBuffer13getBufferSizeEv` | `asm/ZNK21IOSkywalkPacketBuffer13getBufferSizeEv.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297ebce` | 6 | `__ZNK21IOSkywalkPacketBuffer13getDataLengthEv` | `asm/ZNK21IOSkywalkPacketBuffer13getDataLengthEv.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297ebd8` | 6 | `__ZNK21IOSkywalkPacketBuffer13getDataOffsetEv` | `asm/ZNK21IOSkywalkPacketBuffer13getDataOffsetEv.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297ebe6` | 5 | `__ZNK21IOSkywalkPacketBuffer10getDataOffEv` | `asm/ZNK21IOSkywalkPacketBuffer10getDataOffEv.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297ebf2` | 5 | `__ZNK21IOSkywalkPacketBuffer16getMemorySegmentEv` | `asm/ZNK21IOSkywalkPacketBuffer16getMemorySegmentEv.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297ebfc` | 5 | `__ZNK21IOSkywalkPacketBuffer22getMemorySegmentOffsetEv` | `asm/ZNK21IOSkywalkPacketBuffer22getMemorySegmentOffsetEv.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297ec06` | 5 | `__ZNK21IOSkywalkPacketBuffer15getBufletHandleEv` | `asm/ZNK21IOSkywalkPacketBuffer15getBufletHandleEv.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297ec10` | 5 | `__ZN21IOSkywalkPacketBuffer15setBufletHandleEP13__kern_buflet` | `asm/ZN21IOSkywalkPacketBuffer15setBufletHandleEP13__kern_buflet.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297ec1a` | 5 | `__ZNK21IOSkywalkPacketBuffer15getBufferHandleEv` | `asm/ZNK21IOSkywalkPacketBuffer15getBufferHandleEv.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297ec24` | 5 | `__ZN21IOSkywalkPacketBuffer7prepareEj` | `asm/ZN21IOSkywalkPacketBuffer7prepareEj.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297ec2c` | 5 | `__ZN21IOSkywalkPacketBuffer8completeEj` | `asm/ZN21IOSkywalkPacketBuffer8completeEj.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297ec34` | 8 | `__ZN21IOSkywalkPacketBuffer24prepareWithMemorySegmentEP22IOSkywalkMemorySegmentyj` | `asm/ZN21IOSkywalkPacketBuffer24prepareWithMemorySegmentEP22IOSkywalkMemorySegmentyj.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297ec48` | 8 | `__ZN21IOSkywalkPacketBuffer25completeWithMemorySegmentEP22IOSkywalkMemorySegmentyj` | `asm/ZN21IOSkywalkPacketBuffer25completeWithMemorySegmentEP22IOSkywalkMemorySegmentyj.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297ec5c` | 5 | `__ZNK21IOSkywalkPacketBuffer14getSourceQueueEv` | `asm/ZNK21IOSkywalkPacketBuffer14getSourceQueueEv.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297ec66` | 51 | `__ZN21IOSkywalkPacketBuffer16prepareWithQueueEP20IOSkywalkPacketQueuejj` | `asm/ZN21IOSkywalkPacketBuffer16prepareWithQueueEP20IOSkywalkPacketQueuejj.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297ed00` | 27 | `__ZN21IOSkywalkPacketBuffer17completeWithQueueEP20IOSkywalkPacketQueuejj` | `asm/ZN21IOSkywalkPacketBuffer17completeWithQueueEP20IOSkywalkPacketQueuejj.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297ed48` | 18 | `__ZN21IOSkywalkPacketBuffer8finalizeEv` | `asm/ZN21IOSkywalkPacketBuffer8finalizeEv.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297ed7a` | 5 | `__ZN21IOSkywalkPacketBuffer9setPacketEP15IOSkywalkPacketj` | `asm/ZN21IOSkywalkPacketBuffer9setPacketEP15IOSkywalkPacketj.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297ed84` | 6 | `__ZN21IOSkywalkPacketBuffer23acquireWithBufletHandleEP13__kern_buflet` | `asm/ZN21IOSkywalkPacketBuffer23acquireWithBufletHandleEP13__kern_buflet.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297ed94` | 6 | `__ZN21IOSkywalkPacketBuffer23acquireWithBufferHandleEy` | `asm/ZN21IOSkywalkPacketBuffer23acquireWithBufferHandleEy.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297eda4` | 10 | `__ZN21IOSkywalkPacketBuffer19disposePacketBufferEv` | `asm/ZN21IOSkywalkPacketBuffer19disposePacketBufferEv.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297edc2` | 5 | `__ZN21IOSkywalkPacketBuffer24cancelCompletionCallbackEv` | `asm/ZN21IOSkywalkPacketBuffer24cancelCompletionCallbackEv.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297edd0` | 4 | `__ZN21IOSkywalkPacketBuffer9MetaClassD0Ev` | `asm/ZN21IOSkywalkPacketBuffer9MetaClassD0Ev.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff80029a259a` | 14 | `__ZN21IOSkywalkPacketBuffer13setDataLengthEj` | `asm/ZN21IOSkywalkPacketBuffer13setDataLengthEj.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff80029a25be` | 14 | `__ZN21IOSkywalkPacketBuffer13setDataOffsetEt` | `asm/ZN21IOSkywalkPacketBuffer13setDataOffsetEt.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff80029a25e2` | 19 | `__ZN21IOSkywalkPacketBuffer10setDataOffEx` | `asm/ZN21IOSkywalkPacketBuffer10setDataOffEx.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff80029a2616` | 14 | `__ZN21IOSkywalkPacketBuffer22setDataOffsetAndLengthEtj` | `asm/ZN21IOSkywalkPacketBuffer22setDataOffsetAndLengthEtj.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff80029a263c` | 27 | `__ZN21IOSkywalkPacketBuffer16setDataOffAndLenExm` | `asm/ZN21IOSkywalkPacketBuffer16setDataOffAndLenExm.asm.txt` |
| `IOSkywalkMemorySegment` | `0xffffff8002986f2e` | 15 | `__ZN22IOSkywalkMemorySegment9MetaClassC1Ev` | `asm/ZN22IOSkywalkMemorySegment9MetaClassC1Ev.asm.txt` |
| `IOSkywalkMemorySegment` | `0xffffff8002986f60` | 4 | `__ZN22IOSkywalkMemorySegment9MetaClassD1Ev` | `asm/ZN22IOSkywalkMemorySegment9MetaClassD1Ev.asm.txt` |
| `IOSkywalkMemorySegment` | `0xffffff8002986f6a` | 13 | `__ZN22IOSkywalkMemorySegmentC2EPK11OSMetaClass` | `asm/ZN22IOSkywalkMemorySegmentC2EPK11OSMetaClass.asm.txt` |
| `IOSkywalkMemorySegment` | `0xffffff8002986f8a` | 13 | `__ZN22IOSkywalkMemorySegmentC1EPK11OSMetaClass` | `asm/ZN22IOSkywalkMemorySegmentC1EPK11OSMetaClass.asm.txt` |
| `IOSkywalkMemorySegment` | `0xffffff8002986faa` | 4 | `__ZN22IOSkywalkMemorySegmentD2Ev` | `asm/ZN22IOSkywalkMemorySegmentD2Ev.asm.txt` |
| `IOSkywalkMemorySegment` | `0xffffff8002986fb4` | 4 | `__ZN22IOSkywalkMemorySegmentD1Ev` | `asm/ZN22IOSkywalkMemorySegmentD1Ev.asm.txt` |
| `IOSkywalkMemorySegment` | `0xffffff8002986fbe` | 13 | `__ZN22IOSkywalkMemorySegmentD0Ev` | `asm/ZN22IOSkywalkMemorySegmentD0Ev.asm.txt` |
| `IOSkywalkMemorySegment` | `0xffffff8002986fe6` | 8 | `__ZN22IOSkywalkMemorySegmentdlEPvm` | `asm/ZN22IOSkywalkMemorySegmentdlEPvm.asm.txt` |
| `IOSkywalkMemorySegment` | `0xffffff8002986ffe` | 6 | `__ZNK22IOSkywalkMemorySegment12getMetaClassEv` | `asm/ZNK22IOSkywalkMemorySegment12getMetaClassEv.asm.txt` |
| `IOSkywalkMemorySegment` | `0xffffff800298700c` | 15 | `__ZN22IOSkywalkMemorySegment9MetaClassC2Ev` | `asm/ZN22IOSkywalkMemorySegment9MetaClassC2Ev.asm.txt` |
| `IOSkywalkMemorySegment` | `0xffffff800298703e` | 22 | `__ZNK22IOSkywalkMemorySegment9MetaClass5allocEv` | `asm/ZNK22IOSkywalkMemorySegment9MetaClass5allocEv.asm.txt` |
| `IOSkywalkMemorySegment` | `0xffffff8002987086` | 6 | `__ZN22IOSkywalkMemorySegmentnwEm` | `asm/ZN22IOSkywalkMemorySegmentnwEm.asm.txt` |
| `IOSkywalkMemorySegment` | `0xffffff800298709a` | 16 | `__ZN22IOSkywalkMemorySegmentC1Ev` | `asm/ZN22IOSkywalkMemorySegmentC1Ev.asm.txt` |
| `IOSkywalkMemorySegment` | `0xffffff80029870ca` | 16 | `__ZN22IOSkywalkMemorySegmentC2Ev` | `asm/ZN22IOSkywalkMemorySegmentC2Ev.asm.txt` |
| `IOSkywalkMemorySegment` | `0xffffff80029870fa` | 45 | `__ZN22IOSkywalkMemorySegment8withPoolEP25IOSkywalkPacketBufferPoolP32IOSkywalkMemorySegmentDescriptorj` | `asm/ZN22IOSkywalkMemorySegment8withPoolEP25IOSkywalkPacketBufferPoolP32IOSkywalkMemorySegmentDescriptorj.asm.txt` |
| `IOSkywalkMemorySegment` | `0xffffff8002987180` | 57 | `__ZN22IOSkywalkMemorySegment12initWithPoolEP25IOSkywalkPacketBufferPoolP32IOSkywalkMemorySegmentDescriptorj` | `asm/ZN22IOSkywalkMemorySegment12initWithPoolEP25IOSkywalkPacketBufferPoolP32IOSkywalkMemorySegmentDescriptorj.asm.txt` |
| `IOSkywalkMemorySegment` | `0xffffff800298722a` | 39 | `__ZN22IOSkywalkMemorySegment4freeEv` | `asm/ZN22IOSkywalkMemorySegment4freeEv.asm.txt` |
| `IOSkywalkMemorySegment` | `0xffffff80029872b0` | 5 | `__ZNK22IOSkywalkMemorySegment19getPacketBufferPoolEv` | `asm/ZNK22IOSkywalkMemorySegment19getPacketBufferPoolEv.asm.txt` |
| `IOSkywalkMemorySegment` | `0xffffff80029872ba` | 5 | `__ZNK22IOSkywalkMemorySegment19getMemoryDescriptorEv` | `asm/ZNK22IOSkywalkMemorySegment19getMemoryDescriptorEv.asm.txt` |
| `IOSkywalkMemorySegment` | `0xffffff80029872c4` | 38 | `__ZN22IOSkywalkMemorySegment19setMemoryDescriptorEP18IOMemoryDescriptory` | `asm/ZN22IOSkywalkMemorySegment19setMemoryDescriptorEP18IOMemoryDescriptory.asm.txt` |
| `IOSkywalkMemorySegment` | `0xffffff800298732e` | 5 | `__ZNK22IOSkywalkMemorySegment17getVirtualAddressEv` | `asm/ZNK22IOSkywalkMemorySegment17getVirtualAddressEv.asm.txt` |
| `IOSkywalkMemorySegment` | `0xffffff8002987338` | 5 | `__ZN22IOSkywalkMemorySegment19getIOVirtualAddressEv` | `asm/ZN22IOSkywalkMemorySegment19getIOVirtualAddressEv.asm.txt` |
| `IOSkywalkMemorySegment` | `0xffffff8002987342` | 5 | `__ZN22IOSkywalkMemorySegment25setBufferMemoryDescriptorEP24IOBufferMemoryDescriptor` | `asm/ZN22IOSkywalkMemorySegment25setBufferMemoryDescriptorEP24IOBufferMemoryDescriptor.asm.txt` |
| `IOSkywalkMemorySegment` | `0xffffff800298734a` | 18 | `__ZN22IOSkywalkMemorySegment13setDMACommandEP12IODMACommandj` | `asm/ZN22IOSkywalkMemorySegment13setDMACommandEP12IODMACommandj.asm.txt` |
| `IOSkywalkMemorySegment` | `0xffffff8002987378` | 5 | `__ZNK22IOSkywalkMemorySegment13getDMACommandEv` | `asm/ZNK22IOSkywalkMemorySegment13getDMACommandEv.asm.txt` |
| `IOSkywalkMemorySegment` | `0xffffff8002987382` | 138 | `__ZN22IOSkywalkMemorySegment7prepareEj` | `asm/ZN22IOSkywalkMemorySegment7prepareEj.asm.txt` |
| `IOSkywalkMemorySegment` | `0xffffff8002987574` | 52 | `__ZN22IOSkywalkMemorySegment8completeEj` | `asm/ZN22IOSkywalkMemorySegment8completeEj.asm.txt` |
| `IOSkywalkMemorySegment` | `0xffffff8002987622` | 4 | `__ZN22IOSkywalkMemorySegment9MetaClassD0Ev` | `asm/ZN22IOSkywalkMemorySegment9MetaClassD0Ev.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e086` | 15 | `__ZN15IOSkywalkPacket9MetaClassC1Ev` | `asm/ZN15IOSkywalkPacket9MetaClassC1Ev.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e0b8` | 4 | `__ZN15IOSkywalkPacket9MetaClassD1Ev` | `asm/ZN15IOSkywalkPacket9MetaClassD1Ev.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e0c2` | 13 | `__ZN15IOSkywalkPacketC2EPK11OSMetaClass` | `asm/ZN15IOSkywalkPacketC2EPK11OSMetaClass.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e0e2` | 13 | `__ZN15IOSkywalkPacketC1EPK11OSMetaClass` | `asm/ZN15IOSkywalkPacketC1EPK11OSMetaClass.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e102` | 4 | `__ZN15IOSkywalkPacketD2Ev` | `asm/ZN15IOSkywalkPacketD2Ev.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e10c` | 4 | `__ZN15IOSkywalkPacketD1Ev` | `asm/ZN15IOSkywalkPacketD1Ev.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e116` | 13 | `__ZN15IOSkywalkPacketD0Ev` | `asm/ZN15IOSkywalkPacketD0Ev.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e13e` | 8 | `__ZN15IOSkywalkPacketdlEPvm` | `asm/ZN15IOSkywalkPacketdlEPvm.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e156` | 6 | `__ZNK15IOSkywalkPacket12getMetaClassEv` | `asm/ZNK15IOSkywalkPacket12getMetaClassEv.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e164` | 15 | `__ZN15IOSkywalkPacket9MetaClassC2Ev` | `asm/ZN15IOSkywalkPacket9MetaClassC2Ev.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e196` | 22 | `__ZNK15IOSkywalkPacket9MetaClass5allocEv` | `asm/ZNK15IOSkywalkPacket9MetaClass5allocEv.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e1de` | 6 | `__ZN15IOSkywalkPacketnwEm` | `asm/ZN15IOSkywalkPacketnwEm.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e1f2` | 16 | `__ZN15IOSkywalkPacketC1Ev` | `asm/ZN15IOSkywalkPacketC1Ev.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e222` | 16 | `__ZN15IOSkywalkPacketC2Ev` | `asm/ZN15IOSkywalkPacketC2Ev.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e252` | 45 | `__ZN15IOSkywalkPacket8withPoolEP25IOSkywalkPacketBufferPoolP25IOSkywalkPacketDescriptorj` | `asm/ZN15IOSkywalkPacket8withPoolEP25IOSkywalkPacketBufferPoolP25IOSkywalkPacketDescriptorj.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e2d8` | 52 | `__ZN15IOSkywalkPacket12initWithPoolEP25IOSkywalkPacketBufferPoolP25IOSkywalkPacketDescriptorj` | `asm/ZN15IOSkywalkPacket12initWithPoolEP25IOSkywalkPacketBufferPoolP25IOSkywalkPacketDescriptorj.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e376` | 23 | `__ZN15IOSkywalkPacket4freeEv` | `asm/ZN15IOSkywalkPacket4freeEv.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e3c6` | 5 | `__ZNK15IOSkywalkPacket19getPacketBufferPoolEv` | `asm/ZNK15IOSkywalkPacket19getPacketBufferPoolEv.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e3d0` | 7 | `__ZNK15IOSkywalkPacket13getBufferSizeEv` | `asm/ZNK15IOSkywalkPacket13getBufferSizeEv.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e3de` | 6 | `__ZNK15IOSkywalkPacket20getPacketBufferCountEv` | `asm/ZNK15IOSkywalkPacket20getPacketBufferCountEv.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e3e8` | 29 | `__ZNK15IOSkywalkPacket13getDataLengthEv` | `asm/ZNK15IOSkywalkPacket13getDataLengthEv.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e430` | 19 | `__ZNK15IOSkywalkPacket21getDataVirtualAddressEv` | `asm/ZNK15IOSkywalkPacket21getDataVirtualAddressEv.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e462` | 20 | `__ZNK15IOSkywalkPacket23getDataIOVirtualAddressEv` | `asm/ZNK15IOSkywalkPacket23getDataIOVirtualAddressEv.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e498` | 5 | `__ZNK15IOSkywalkPacket14getSourceQueueEv` | `asm/ZNK15IOSkywalkPacket14getSourceQueueEv.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e4a2` | 31 | `__ZN15IOSkywalkPacket7prepareEP20IOSkywalkPacketQueueyj` | `asm/ZN15IOSkywalkPacket7prepareEP20IOSkywalkPacketQueueyj.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e4ee` | 67 | `__ZN15IOSkywalkPacket16prepareWithQueueEP20IOSkywalkPacketQueuejj` | `asm/ZN15IOSkywalkPacket16prepareWithQueueEP20IOSkywalkPacketQueuejj.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e5c6` | 31 | `__ZN15IOSkywalkPacket8completeEP20IOSkywalkPacketQueuej` | `asm/ZN15IOSkywalkPacket8completeEP20IOSkywalkPacketQueuej.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e612` | 53 | `__ZN15IOSkywalkPacket17completeWithQueueEP20IOSkywalkPacketQueuejj` | `asm/ZN15IOSkywalkPacket17completeWithQueueEP20IOSkywalkPacketQueuejj.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e6aa` | 23 | `__ZN15IOSkywalkPacket8finalizeEv` | `asm/ZN15IOSkywalkPacket8finalizeEv.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e6e6` | 16 | `__ZNK15IOSkywalkPacket16generateTraceTagEP20IOSkywalkPacketQueue` | `asm/ZNK15IOSkywalkPacket16generateTraceTagEP20IOSkywalkPacketQueue.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e70c` | 5 | `__ZNK15IOSkywalkPacket11getTraceTagEv` | `asm/ZNK15IOSkywalkPacket11getTraceTagEv.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e71a` | 5 | `__ZNK15IOSkywalkPacket11setTraceTagEt` | `asm/ZNK15IOSkywalkPacket11setTraceTagEt.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e728` | 17 | `__ZN15IOSkywalkPacket14getAppMetadataEP26packet_app_metadata_type_tPh` | `asm/ZN15IOSkywalkPacket14getAppMetadataEP26packet_app_metadata_type_tPh.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e758` | 8 | `__ZN15IOSkywalkPacket23acquireWithPacketHandleEyj` | `asm/ZN15IOSkywalkPacket23acquireWithPacketHandleEyj.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e76c` | 29 | `__ZN15IOSkywalkPacket13disposePacketEv` | `asm/ZN15IOSkywalkPacket13disposePacketEv.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e7c2` | 6 | `__ZN15IOSkywalkPacket20setTransferDirectionEj` | `asm/ZN15IOSkywalkPacket20setTransferDirectionEj.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e7cc` | 6 | `__ZNK15IOSkywalkPacket20getTransferDirectionEv` | `asm/ZNK15IOSkywalkPacket20getTransferDirectionEv.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e7d6` | 6 | `__ZN15IOSkywalkPacket22clearTransferDirectionEv` | `asm/ZN15IOSkywalkPacket22clearTransferDirectionEv.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e7e4` | 5 | `__ZNK15IOSkywalkPacket13getPacketTypeEv` | `asm/ZNK15IOSkywalkPacket13getPacketTypeEv.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e7ec` | 5 | `__ZN15IOSkywalkPacket24cancelCompletionCallbackEv` | `asm/ZN15IOSkywalkPacket24cancelCompletionCallbackEv.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e7fa` | 5 | `__ZN15IOSkywalkPacket13setNextPacketEPS_` | `asm/ZN15IOSkywalkPacket13setNextPacketEPS_.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e804` | 5 | `__ZN15IOSkywalkPacket13getNextPacketEv` | `asm/ZN15IOSkywalkPacket13getNextPacketEv.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e80e` | 4 | `__ZN15IOSkywalkPacket9MetaClassD0Ev` | `asm/ZN15IOSkywalkPacket9MetaClassD0Ev.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e818` | 4 | `__ZN15IOSkywalkPacket11setWakeFlagEv` | `asm/ZN15IOSkywalkPacket11setWakeFlagEv.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e81e` | 5 | `__ZNK15IOSkywalkPacket10getTraceIDEv` | `asm/ZNK15IOSkywalkPacket10getTraceIDEv.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e826` | 4 | `__ZN15IOSkywalkPacket10setTraceIDEj` | `asm/ZN15IOSkywalkPacket10setTraceIDEj.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e82c` | 4 | `__ZN15IOSkywalkPacket10traceEventEj` | `asm/ZN15IOSkywalkPacket10traceEventEj.asm.txt` |
| `IOSkywalkPacket` | `0xffffff80029a2398` | 25 | `__ZNK15IOSkywalkPacket16getPacketBuffersEPP21IOSkywalkPacketBufferj` | `asm/ZNK15IOSkywalkPacket16getPacketBuffersEPP21IOSkywalkPacketBufferj.asm.txt` |
| `IOSkywalkPacket` | `0xffffff80029a23d2` | 11 | `__ZNK15IOSkywalkPacket19getMemoryDescriptorEv` | `asm/ZNK15IOSkywalkPacket19getMemoryDescriptorEv.asm.txt` |
| `IOSkywalkPacket` | `0xffffff80029a23ec` | 11 | `__ZN15IOSkywalkPacket13setDataLengthEj` | `asm/ZN15IOSkywalkPacket13setDataLengthEj.asm.txt` |
| `IOSkywalkPacket` | `0xffffff80029a240a` | 11 | `__ZN15IOSkywalkPacket10setDataOffEx` | `asm/ZN15IOSkywalkPacket10setDataOffEx.asm.txt` |
| `IOSkywalkPacket` | `0xffffff80029a2428` | 12 | `__ZNK15IOSkywalkPacket10getDataOffEv` | `asm/ZNK15IOSkywalkPacket10getDataOffEv.asm.txt` |
| `IOSkywalkPacket` | `0xffffff80029a2444` | 53 | `__ZN15IOSkywalkPacket16setDataOffAndLenExm` | `asm/ZN15IOSkywalkPacket16setDataOffAndLenExm.asm.txt` |
| `IOSkywalkPacket` | `0xffffff80029a24d0` | 52 | `__ZN15IOSkywalkPacket22setDataOffsetAndLengthEtj` | `asm/ZN15IOSkywalkPacket22setDataOffsetAndLengthEtj.asm.txt` |
| `IOSkywalkPacket` | `0xffffff80029a2558` | 13 | `__ZN15IOSkywalkPacket13setDataOffsetEt` | `asm/ZN15IOSkywalkPacket13setDataOffsetEt.asm.txt` |
| `IOSkywalkPacket` | `0xffffff80029a257a` | 13 | `__ZNK15IOSkywalkPacket13getDataOffsetEv` | `asm/ZNK15IOSkywalkPacket13getDataOffsetEv.asm.txt` |

### Source evidence snippets

**RTW88WCLSkywalkQueues.cpp:25-33**

```cpp
   25:     _txPool = nullptr;
   26:     _rxPool = nullptr;
   27:     _txSubmission = nullptr;
   28:     _txCompletion = nullptr;
   29:     _rxSubmission = nullptr;
   30:     _rxCompletion = nullptr;
   31:     _allocated = false;
   32:     return true;
   33: }
```

**RTW88WCLSkywalkQueues.cpp:36-44**

```cpp
   36: {
   37:     if (_allocated)
   38:         return kIOReturnSuccess;
   39:     if (_txPool || _rxPool || _txSubmission || _txCompletion ||
   40:         _rxSubmission || _rxCompletion)
   41:         return kIOReturnBusy;
   42: 
   43:     RTW88WCLPoolOptionsAccess::PoolOptions txOptions = {};
   44:     txOptions.packetCount = kQueueCapacity;
```

**RTW88WCLSkywalkQueues.cpp:78-89**

```cpp
   78:         &RTW88WCLSkywalkQueues::txCompletionAction, this, 0);
   79:     if (!_txCompletion)
   80:         goto no_memory;
   81: 
   82:     _rxSubmission = IOSkywalkRxSubmissionQueue::withPool(
   83:         _rxPool, kQueueCapacity, 0, static_cast<kern_packet_svc_class_t>(0),
   84:         this, &RTW88WCLSkywalkQueues::rxSubmissionAction, this, 0);
   85:     if (!_rxSubmission)
   86:         goto no_memory;
   87: 
   88:     _rxCompletion = IOSkywalkRxCompletionQueue::withPool(
   89:         _rxPool, kQueueCapacity, 0, this,
```

**RTW88WCLSkywalkQueues.cpp:107-117**

```cpp
  107:     if (_rxCompletion) {
  108:         _rxCompletion->release();
  109:         _rxCompletion = nullptr;
  110:     }
  111:     if (_rxSubmission) {
  112:         _rxSubmission->release();
  113:         _rxSubmission = nullptr;
  114:     }
  115:     if (_txCompletion) {
  116:         _txCompletion->release();
  117:         _txCompletion = nullptr;
```

**RTW88WCLSkywalkQueues.cpp:133-141**

```cpp
  133: 
  134: bool RTW88WCLSkywalkQueues::queuesAllocated() const
  135: {
  136:     return _allocated && _txPool && _rxPool && _txSubmission &&
  137:            _txCompletion && _rxSubmission && _rxCompletion;
  138: }
  139: 
  140: IOReturn RTW88WCLSkywalkQueues::txSubmissionAction(
  141:     OSObject *owner, IOSkywalkTxSubmissionQueue *queue,
```

**RTW88WCLSkywalkQueues.cpp:169-182**

```cpp
  169:     (void)owner; (void)queue; (void)packets; (void)packetCount; (void)refCon;
  170:     return kIOReturnNotReady;
  171: }
  172: 
  173: IOReturn RTW88WCLSkywalkQueues::rxSubmissionAction(
  174:     OSObject *owner, IOSkywalkRxSubmissionQueue *queue,
  175:     const IOSkywalkPacket **packets, UInt32 packetCount, void *refCon)
  176: {
  177:     (void)owner; (void)queue; (void)packets; (void)packetCount; (void)refCon;
  178:     /* RX buffer ownership/refill is intentionally not accepted yet. */
  179:     return kIOReturnNotReady;
  180: }
  181: 
  182: IOReturn RTW88WCLSkywalkQueues::rxCompletionAction(
```

**RTW88WCLSkywalkRxAdapter.cpp:31-39**

```cpp
   31:     _sinkContext = context;
   32:     __atomic_store_n(&_pendingSignal, 0U, __ATOMIC_RELAXED);
   33:     __atomic_store_n(&_stopping, 0U, __ATOMIC_RELAXED);
   34:     __atomic_store_n(&_dropped, 0U, __ATOMIC_RELAXED);
   35:     __atomic_store_n(&_prepared, 0U, __ATOMIC_RELAXED);
   36: 
   37:     const IOReturn status = workLoop->addEventSource(this);
   38:     if (status != kIOReturnSuccess) {
   39:         _rxPool->release();
```

**RTW88WCLSkywalkRxAdapter.cpp:74-82**

```cpp
   74:         return false;
   75: 
   76:     IOSkywalkPacket *packet = nullptr;
   77:     /* Option bit 0 requests non-blocking allocation in a packet callback. */
   78:     if (pool->allocatePacket(1, &packet, 1) != kIOReturnSuccess || !packet)
   79:         return false;
   80: 
   81:     bool valid = false;
   82:     do {
```

**RTW88WCLSkywalkRxAdapter.cpp:136-148**

```cpp
  136:         valid = true;
  137:     } while (false);
  138: 
  139:     if (!valid)
  140:         (void)pool->deallocatePacket(packet);
  141:     return valid;
  142: }
  143: 
  144: IOReturn RTW88WCLSkywalkRxAdapter::enqueueFrame(mbuf_t packet)
  145: {
  146:     if (!packet)
  147:         return kIOReturnBadArgument;
  148: 
```

**RTW88WCLSkywalkRxAdapter.cpp:165-202**

```cpp
  165:         signalWorkAvailable();
  166:     return kIOReturnSuccess;
  167: }
  168: 
  169: bool RTW88WCLSkywalkRxAdapter::checkForWork()
  170: {
  171:     if (__atomic_load_n(&_stopping, __ATOMIC_ACQUIRE))
  172:         return false;
  173: 
  174:     uint32_t drained = 0;
  175:     mbuf_t source = nullptr;
  176:     while (drained < kDrainBudget && _frames.pop(&source)) {
  177:         if (source) {
  178:             IOSkywalkPacket *packet = nullptr;
  179:             if (copyMbufToSkywalkPacket(_rxPool, source, &packet)) {
  180:                 __atomic_add_fetch(&_prepared, 1U, __ATOMIC_RELAXED);
  181:                 /* A true return means the sink has accepted ownership. The
  182:                  * current controller sink returns false because the RX
  183:                  * completion queue is still unregistered. */
  184:                 const bool accepted = _sink && _sink(packet, _sinkContext);
  185:                 if (!accepted) {
  186:                     (void)_rxPool->deallocatePacket(packet);
  187:                     __atomic_add_fetch(&_dropped, 1U, __ATOMIC_RELAXED);
  188:                 }
  189:             } else {
  190:                 __atomic_add_fetch(&_dropped, 1U, __ATOMIC_RELAXED);
  191:             }
  192:             mbuf_freem(source);
  193:             source = nullptr;
  194:         }
  195:         ++drained;
  196:     }
  197: 
  198:     if (drained == kDrainBudget)
  199:         return true; // bounded workloop occupancy; schedule another pass
  200: 
  201:     __atomic_store_n(&_pendingSignal, 0U, __ATOMIC_RELEASE);
  202:     if (!_frames.empty()) {
```

**RTW88WCLSkywalkRxAdapter.cpp:208-221**

```cpp
  208:     }
  209:     return false;
  210: }
  211: 
  212: void RTW88WCLSkywalkRxAdapter::stop()
  213: {
  214:     __atomic_store_n(&_stopping, 1U, __ATOMIC_RELEASE);
  215:     if (_registered && _workLoop) {
  216:         /* Synchronous removal serializes against checkForWork(). The owner
  217:          * must stop/quiesce RTW88 RX producers before invoking stop(). */
  218:         _workLoop->removeEventSource(this);
  219:         _registered = false;
  220:     }
  221: 
```

**RTW88WCLSkywalkRxAdapter.cpp:235-254**

```cpp
  235: }
  236: 
  237: void RTW88WCLSkywalkRxAdapter::free()
  238: {
  239:     stop();
  240:     super::free();
  241: }
  242: 
  243: uint32_t RTW88WCLSkywalkRxAdapter::droppedFrames() const
  244: {
  245:     return __atomic_load_n(&_dropped, __ATOMIC_ACQUIRE);
  246: }
  247: 
  248: uint32_t RTW88WCLSkywalkRxAdapter::preparedFrames() const
  249: {
  250:     return __atomic_load_n(&_prepared, __ATOMIC_ACQUIRE);
  251: }
  252: 
  253: uint32_t RTW88WCLSkywalkRxAdapter::queuedFrames() const
  254: {
```

**RTW88WCLController.cpp:46-58**

```cpp
   46: {
   47:     return _workLoop;
   48: }
   49: 
   50: bool RTW88WCLController::start(IOService *provider)
   51: {
   52:     if (!provider || _baseStarted || _pciBackend || _radio)
   53:         return false;
   54:     if (!super::start(provider))
   55:         return false;
   56:     _baseStarted = true;
   57: 
   58:     /* Stage A: the controller workloop must exist before acquiring a PCI
```

**RTW88WCLController.cpp:161-179**

```cpp
  161: 
  162: fail:
  163:     releaseNativeResources();
  164:     if (_baseStarted) {
  165:         super::stop(provider);
  166:         _baseStarted = false;
  167:     }
  168:     return false;
  169: }
  170: 
  171: void RTW88WCLController::stop(IOService *provider)
  172: {
  173:     releaseNativeResources();
  174:     if (_baseStarted) {
  175:         super::stop(provider);
  176:         _baseStarted = false;
  177:     }
  178: }
  179: 
```

**RTW88WCLController.cpp:190-222**

```cpp
  190:      * disabling PCI interrupts. The staged path currently leaves
  191:      * _radioStarted false; preserve this ordering when native radio start is
  192:      * enabled after queue registration. */
  193:     if (_radio && _radioStarted) {
  194:         _radio->stop();
  195:         _radioStarted = false;
  196:     }
  197: 
  198:     /* Remove the RX workloop source only after the RTW88 producer is stopped.
  199:      * stop() waits out an active checkForWork() and releases all staged mbufs. */
  200:     if (_rxAdapter) {
  201:         _rxAdapter->stop();
  202:         _rxAdapter->release();
  203:         _rxAdapter = nullptr;
  204:     }
  205: 
  206:     /* The RX adapter transfers accepted native packets into the controller's
  207:      * bounded ready ring. Recycle those packets while their pool still exists;
  208:      * on a pool error, retain the queue owner and PCI/backend context so a later
  209:      * stop/free attempt can retry rather than releasing live packet memory. */
  210:     const IOReturn recycleStatus = recycleStagedRxPackets();
  211:     if (recycleStatus != kIOReturnSuccess) {
  212:         IOLog("rtl88wifi-wcl: staged RX packet recycle deferred: 0x%08x\n",
  213:               recycleStatus);
  214:         return;
  215:     }
  216: 
  217:     /* Skywalk packet pools/queues are released only after both the mbuf staging
  218:      * adapter and the prepared-packet ownership ring have been drained. */
  219:     if (_skywalkQueues) {
  220:         _skywalkQueues->destroyQueues();
  221:         _skywalkQueues->release();
  222:         _skywalkQueues = nullptr;
```

**RTW88WCLController.cpp:479-487**

```cpp
  479:         return nullptr;
  480: 
  481:     /* IO80211Controller inherits the IONetworkController packet allocator.
  482:      * Keep its mbuf metadata initialization rather than hand-rolling m_len. */
  483:     mbuf_t packet = allocatePacket(length);
  484:     leavePacketPath();
  485:     return packet;
  486: }
  487: 
```

**RTW88WCLController.cpp:494-509**

```cpp
  494:         mbuf_freem(packet);
  495:         return;
  496:     }
  497: 
  498:     /* enqueueFrame consumes the mbuf on both success and failure. The native
  499:      * RX completion queue is not registered yet, so the workloop sink below
  500:      * deliberately drops frames after staging rather than exposing them. */
  501:     (void)_rxAdapter->enqueueFrame(packet);
  502:     leavePacketPath();
  503: }
  504: 
  505: IOReturn RTW88WCLController::recycleStagedRxPackets()
  506: {
  507:     if (_stagedRxPackets.empty())
  508:         return kIOReturnSuccess;
  509:     if (!_skywalkQueues || !_skywalkQueues->rxPacketPool())
```

**RTW88WCLController.cpp:515-529**

```cpp
  515:     while (_stagedRxPackets.pop(&packet)) {
  516:         if (!packet)
  517:             continue;
  518: 
  519:         const IOReturn status = pool->deallocatePacket(packet);
  520:         if (status != kIOReturnSuccess) {
  521:             /* The radio and RX event source are already quiesced, and these
  522:              * queues were never registered. If a packet cannot be returned
  523:              * individually, dispose the pool's packet set as one teardown
  524:              * operation before its memory segments are released. */
  525:             IOLog("rtl88wifi-wcl: RX packet recycle returned 0x%08x; pool disposal required\n",
  526:                   status);
  527:             disposalRequired = true;
  528:         }
  529:         packet = nullptr;
```

**RTW88WCLController.cpp:534-552**

```cpp
  534:     return kIOReturnSuccess;
  535: }
  536: 
  537: bool RTW88WCLController::stagedRxFrame(
  538:     IOSkywalkPacket *preparedPacket, void *context)
  539: {
  540:     auto *self = static_cast<RTW88WCLController *>(context);
  541:     if (!self || !preparedPacket)
  542:         return false;
  543: 
  544:     /* Preserve the pool-backed packet in a fixed-capacity owner ring. The
  545:      * ring is bounded to the RX pool's 128 packets; overflow returns false,
  546:      * causing the RX adapter to recycle the packet immediately. No queue API
  547:      * is called here: completion-queue registration/ownership is still fenced. */
  548:     return self->_stagedRxPackets.push(preparedPacket);
  549: }
  550: 
  551: IOWorkLoop *RTW88WCLController::getRxWorkLoop()
  552: {
```

**RTW88WCLController.hpp:25-34**

```cpp
   25:     OSDeclareDefaultStructors(RTW88WCLController)
   26: 
   27: public:
   28:     bool init(OSDictionary *properties) override;
   29:     bool start(IOService *provider) override;
   30:     void stop(IOService *provider) override;
   31:     void free() override;
   32:     bool createWorkLoop() override;
   33:     IOWorkLoop *getWorkLoop() const override;
   34: 
```

**RTW88WCLController.hpp:84-93**

```cpp
   84:     void setLinkStatus(UInt32 status) override;
   85: 
   86: private:
   87:     void releaseNativeResources();
   88:     IOReturn recycleStagedRxPackets();
   89:     static bool stagedRxFrame(IOSkywalkPacket *preparedPacket, void *context);
   90: 
   91:     enum : uint32_t {
   92:         kPacketPathDisabled = 0,
   93:         kPacketPathActive = 1,
```

### Manual questions

- [ ] Does dequeue transfer a packet/buffer reference or merely borrow it?
- [ ] What is the exact replenishment trigger and minimum buffer count?
- [ ] How are no-buffer and transient errors retried without double-free?
- [ ] Which prepare/complete calls are required before reuse?

**Review outcome:** `UNRESOLVED — do not enable this contract`

## tx_completion_acceptance: TX completion queue acceptance and packet-retain transfer

**Status:** MANUAL_REVIEW_REQUIRED
**Candidate method bodies:** 275

### Kernel method candidates

| Class | Address | Instructions | Exact symbol | Assembly file |
|---|---:|---:|---|---|
| `IOSkywalkTxCompletionQueue` | `0xffffff8002989dec` | 54 | `__ZN26IOSkywalkTxCompletionQueue8withPoolEP25IOSkywalkPacketBufferPooljjP8OSObjectPFjS3_PS_PP15IOSkywalkPacketjPvES8_j` | `asm/ZN26IOSkywalkTxCompletionQueue8withPoolEP25IOSkywalkPacketBufferPooljjP8OSObjectPFjS3_PS_PP15IOSkywalkPacketjPvES8_j.asm.txt` |
| `IOSkywalkTxCompletionQueue` | `0xffffff8002989e96` | 57 | `__ZN26IOSkywalkTxCompletionQueue12initWithPoolEP25IOSkywalkPacketBufferPooljjP8OSObjectPFjS3_PS_PP15IOSkywalkPacketjPvES8_j` | `asm/ZN26IOSkywalkTxCompletionQueue12initWithPoolEP25IOSkywalkPacketBufferPooljjP8OSObjectPFjS3_PS_PP15IOSkywalkPacketjPvES8_j.asm.txt` |
| `IOSkywalkTxCompletionQueue` | `0xffffff8002989fca` | 14 | `__ZN26IOSkywalkTxCompletionQueue6enableEv` | `asm/ZN26IOSkywalkTxCompletionQueue6enableEv.asm.txt` |
| `IOSkywalkTxCompletionQueue` | `0xffffff8002989ff6` | 25 | `__ZN26IOSkywalkTxCompletionQueue7disableEv` | `asm/ZN26IOSkywalkTxCompletionQueue7disableEv.asm.txt` |
| `IOSkywalkTxCompletionQueue` | `0xffffff800298a03c` | 84 | `__ZN26IOSkywalkTxCompletionQueue15completePacketsEPP15IOSkywalkPacketj` | `asm/ZN26IOSkywalkTxCompletionQueue15completePacketsEPP15IOSkywalkPacketj.asm.txt` |
| `IOSkywalkTxCompletionQueue` | `0xffffff800298a14e` | 5 | `__ZNK26IOSkywalkTxCompletionQueue14getPacketCountEv` | `asm/ZNK26IOSkywalkTxCompletionQueue14getPacketCountEv.asm.txt` |
| `IOSkywalkTxCompletionQueue` | `0xffffff800298a156` | 25 | `__ZN26IOSkywalkTxCompletionQueue15setPacketPollerEP21IOSkywalkPacketPoller` | `asm/ZN26IOSkywalkTxCompletionQueue15setPacketPollerEP21IOSkywalkPacketPoller.asm.txt` |
| `IOSkywalkTxCompletionQueue` | `0xffffff800298a2fe` | 84 | `__ZN26IOSkywalkTxCompletionQueue12addReportersEP9IOServiceP5OSSet` | `asm/ZN26IOSkywalkTxCompletionQueue12addReportersEP9IOServiceP5OSSet.asm.txt` |
| `IOSkywalkTxCompletionQueue` | `0xffffff80029a39f8` | 37 | `__ZN26IOSkywalkTxCompletionQueue25enqueueAndCompletePacketsEPv` | `asm/ZN26IOSkywalkTxCompletionQueue25enqueueAndCompletePacketsEPv.asm.txt` |
| `IOSkywalkTxCompletionQueue` | `0xffffff80029a3a6e` | 44 | `__ZN26IOSkywalkTxCompletionQueue14requestEnqueueEPvj` | `asm/ZN26IOSkywalkTxCompletionQueue14requestEnqueueEPvj.asm.txt` |
| `IOSkywalkTxCompletionQueue` | `0xffffff80029a3afc` | 55 | `__ZN26IOSkywalkTxCompletionQueue14enqueuePacketsEPKP15IOSkywalkPacketjj` | `asm/ZN26IOSkywalkTxCompletionQueue14enqueuePacketsEPKP15IOSkywalkPacketjj.asm.txt` |
| `IOSkywalkTxCompletionQueue` | `0xffffff80029a3bb4` | 114 | `__ZN26IOSkywalkTxCompletionQueue14enqueuePacketsEP15IOSkywalkPacketjj` | `asm/ZN26IOSkywalkTxCompletionQueue14enqueuePacketsEP15IOSkywalkPacketjj.asm.txt` |
| `IOSkywalkTxSubmissionQueue` | `0xffffff8002983ff0` | 55 | `__ZN26IOSkywalkTxSubmissionQueue8withPoolEP25IOSkywalkPacketBufferPooljjP8OSObjectPFjS3_PS_PjEPFjS3_S4_PKP15IOSkywalkPacketjPvESC_jj` | `asm/ZN26IOSkywalkTxSubmissionQueue8withPoolEP25IOSkywalkPacketBufferPooljjP8OSObjectPFjS3_PS_PjEPFjS3_S4_PKP15IOSkywalkPacketjPvESC_jj.asm.txt` |
| `IOSkywalkTxSubmissionQueue` | `0xffffff800298409e` | 13 | `__ZN26IOSkywalkTxSubmissionQueue8withPoolEP25IOSkywalkPacketBufferPooljjP8OSObjectPFjS3_PS_PjEPFjS3_S4_PP15IOSkywalkPacketjPvESB_jj` | `asm/ZN26IOSkywalkTxSubmissionQueue8withPoolEP25IOSkywalkPacketBufferPooljjP8OSObjectPFjS3_PS_PjEPFjS3_S4_PP15IOSkywalkPacketjPvESB_jj.asm.txt` |
| `IOSkywalkTxSubmissionQueue` | `0xffffff80029840c2` | 15 | `__ZN26IOSkywalkTxSubmissionQueue8withPoolEP25IOSkywalkPacketBufferPooljjP8OSObjectPFjS3_PS_PKP15IOSkywalkPacketjPvES9_j` | `asm/ZN26IOSkywalkTxSubmissionQueue8withPoolEP25IOSkywalkPacketBufferPooljjP8OSObjectPFjS3_PS_PKP15IOSkywalkPacketjPvES9_j.asm.txt` |
| `IOSkywalkTxSubmissionQueue` | `0xffffff80029840e8` | 78 | `__ZN26IOSkywalkTxSubmissionQueue12initWithPoolEP25IOSkywalkPacketBufferPooljjjP8OSObjectPFjS3_PS_PjEPFjS3_S4_PKP15IOSkywalkPacketjPvESC_j` | `asm/ZN26IOSkywalkTxSubmissionQueue12initWithPoolEP25IOSkywalkPacketBufferPooljjjP8OSObjectPFjS3_PS_PjEPFjS3_S4_PKP15IOSkywalkPacketjPvESC_j.asm.txt` |
| `IOSkywalkTxSubmissionQueue` | `0xffffff800298420a` | 7 | `__ZN26IOSkywalkTxSubmissionQueue20adjustPacketCountersEv` | `asm/ZN26IOSkywalkTxSubmissionQueue20adjustPacketCountersEv.asm.txt` |
| `IOSkywalkTxSubmissionQueue` | `0xffffff80029842b2` | 29 | `__ZN26IOSkywalkTxSubmissionQueue6enableEv` | `asm/ZN26IOSkywalkTxSubmissionQueue6enableEv.asm.txt` |
| `IOSkywalkTxSubmissionQueue` | `0xffffff8002984312` | 23 | `__ZN26IOSkywalkTxSubmissionQueue7disableEv` | `asm/ZN26IOSkywalkTxSubmissionQueue7disableEv.asm.txt` |
| `IOSkywalkTxSubmissionQueue` | `0xffffff8002984356` | 99 | `__ZN26IOSkywalkTxSubmissionQueue24packetSubmissionForKPipeEb` | `asm/ZN26IOSkywalkTxSubmissionQueue24packetSubmissionForKPipeEb.asm.txt` |
| `IOSkywalkTxSubmissionQueue` | `0xffffff80029845c0` | 18 | `__ZN26IOSkywalkTxSubmissionQueue11synchronizeEj` | `asm/ZN26IOSkywalkTxSubmissionQueue11synchronizeEj.asm.txt` |
| `IOSkywalkTxSubmissionQueue` | `0xffffff80029847a0` | 136 | `__ZN26IOSkywalkTxSubmissionQueue21getPacketListForKPipeEv` | `asm/ZN26IOSkywalkTxSubmissionQueue21getPacketListForKPipeEv.asm.txt` |
| `IOSkywalkTxSubmissionQueue` | `0xffffff8002984c04` | 150 | `__ZN26IOSkywalkTxSubmissionQueue26getPacketListForNetworkingEjjb` | `asm/ZN26IOSkywalkTxSubmissionQueue26getPacketListForNetworkingEjjb.asm.txt` |
| `IOSkywalkTxSubmissionQueue` | `0xffffff8002984e32` | 34 | `__ZN26IOSkywalkTxSubmissionQueue16packetCompletionEP15IOSkywalkPacketP20IOSkywalkPacketQueuej` | `asm/ZN26IOSkywalkTxSubmissionQueue16packetCompletionEP15IOSkywalkPacketP20IOSkywalkPacketQueuej.asm.txt` |
| `IOSkywalkTxSubmissionQueue` | `0xffffff8002984e9c` | 55 | `__ZN26IOSkywalkTxSubmissionQueue16packetCompletionEjjb` | `asm/ZN26IOSkywalkTxSubmissionQueue16packetCompletionEjjb.asm.txt` |
| `IOSkywalkTxSubmissionQueue` | `0xffffff8002984f4a` | 9 | `__ZN26IOSkywalkTxSubmissionQueue12purgePacketsEv` | `asm/ZN26IOSkywalkTxSubmissionQueue12purgePacketsEv.asm.txt` |
| `IOSkywalkTxSubmissionQueue` | `0xffffff8002984f5e` | 15 | `__ZNK26IOSkywalkTxSubmissionQueue14getPacketCountEv` | `asm/ZNK26IOSkywalkTxSubmissionQueue14getPacketCountEv.asm.txt` |
| `IOSkywalkTxSubmissionQueue` | `0xffffff8002985064` | 106 | `__ZN26IOSkywalkTxSubmissionQueue12addReportersEP9IOServiceP5OSSet` | `asm/ZN26IOSkywalkTxSubmissionQueue12addReportersEP9IOServiceP5OSSet.asm.txt` |
| `IOSkywalkTxSubmissionQueue` | `0xffffff80029a27a4` | 82 | `__ZN26IOSkywalkTxSubmissionQueue13legacyDequeueEv` | `asm/ZN26IOSkywalkTxSubmissionQueue13legacyDequeueEv.asm.txt` |
| `IOSkywalkTxSubmissionQueue` | `0xffffff80029a28c8` | 68 | `__ZN26IOSkywalkTxSubmissionQueue11listDequeueEv` | `asm/ZN26IOSkywalkTxSubmissionQueue11listDequeueEv.asm.txt` |
| `IOSkywalkTxSubmissionQueue` | `0xffffff80029a29be` | 41 | `__ZN26IOSkywalkTxSubmissionQueue14requestDequeueEPvj` | `asm/ZN26IOSkywalkTxSubmissionQueue14requestDequeueEPvj.asm.txt` |
| `IOSkywalkTxSubmissionQueue` | `0xffffff80029a2a6e` | 154 | `__ZN26IOSkywalkTxSubmissionQueue16packetSubmissionEPyPjS1_` | `asm/ZN26IOSkywalkTxSubmissionQueue16packetSubmissionEPyPjS1_.asm.txt` |
| `IOSkywalkTxSubmissionQueue` | `0xffffff80029a2cac` | 139 | `__ZN26IOSkywalkTxSubmissionQueue16packetSubmissionEb` | `asm/ZN26IOSkywalkTxSubmissionQueue16packetSubmissionEb.asm.txt` |
| `IOSkywalkTxSubmissionQueue` | `0xffffff80029a2eb2` | 50 | `__ZN26IOSkywalkTxSubmissionQueue11synchronizeEj.cold.1` | `asm/ZN26IOSkywalkTxSubmissionQueue11synchronizeEj.cold.1.asm.txt` |
| `IOSkywalkTxSubmissionQueue` | `0xffffff80029a2f59` | 40 | `__ZN26IOSkywalkTxSubmissionQueue12purgePacketsEv.cold.1` | `asm/ZN26IOSkywalkTxSubmissionQueue12purgePacketsEv.cold.1.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297ee1e` | 15 | `__ZN22IOSkywalkNetworkPacket9MetaClassC1Ev` | `asm/ZN22IOSkywalkNetworkPacket9MetaClassC1Ev.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297ee50` | 4 | `__ZN22IOSkywalkNetworkPacket9MetaClassD1Ev` | `asm/ZN22IOSkywalkNetworkPacket9MetaClassD1Ev.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297ee5a` | 13 | `__ZN22IOSkywalkNetworkPacketC2EPK11OSMetaClass` | `asm/ZN22IOSkywalkNetworkPacketC2EPK11OSMetaClass.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297ee7a` | 13 | `__ZN22IOSkywalkNetworkPacketC1EPK11OSMetaClass` | `asm/ZN22IOSkywalkNetworkPacketC1EPK11OSMetaClass.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297ee9a` | 4 | `__ZN22IOSkywalkNetworkPacketD2Ev` | `asm/ZN22IOSkywalkNetworkPacketD2Ev.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297eea4` | 4 | `__ZN22IOSkywalkNetworkPacketD1Ev` | `asm/ZN22IOSkywalkNetworkPacketD1Ev.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297eeae` | 13 | `__ZN22IOSkywalkNetworkPacketD0Ev` | `asm/ZN22IOSkywalkNetworkPacketD0Ev.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297eed6` | 8 | `__ZN22IOSkywalkNetworkPacketdlEPvm` | `asm/ZN22IOSkywalkNetworkPacketdlEPvm.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297eeee` | 6 | `__ZNK22IOSkywalkNetworkPacket12getMetaClassEv` | `asm/ZNK22IOSkywalkNetworkPacket12getMetaClassEv.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297eefc` | 15 | `__ZN22IOSkywalkNetworkPacket9MetaClassC2Ev` | `asm/ZN22IOSkywalkNetworkPacket9MetaClassC2Ev.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297ef2e` | 22 | `__ZNK22IOSkywalkNetworkPacket9MetaClass5allocEv` | `asm/ZNK22IOSkywalkNetworkPacket9MetaClass5allocEv.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297ef76` | 6 | `__ZN22IOSkywalkNetworkPacketnwEm` | `asm/ZN22IOSkywalkNetworkPacketnwEm.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297ef8a` | 16 | `__ZN22IOSkywalkNetworkPacketC1Ev` | `asm/ZN22IOSkywalkNetworkPacketC1Ev.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297efba` | 16 | `__ZN22IOSkywalkNetworkPacketC2Ev` | `asm/ZN22IOSkywalkNetworkPacketC2Ev.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297efea` | 45 | `__ZN22IOSkywalkNetworkPacket8withPoolEP25IOSkywalkPacketBufferPoolP25IOSkywalkPacketDescriptorj` | `asm/ZN22IOSkywalkNetworkPacket8withPoolEP25IOSkywalkPacketBufferPoolP25IOSkywalkPacketDescriptorj.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297f070` | 10 | `__ZN22IOSkywalkNetworkPacket11setHeadroomEh` | `asm/ZN22IOSkywalkNetworkPacket11setHeadroomEh.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297f08a` | 5 | `__ZNK22IOSkywalkNetworkPacket11getHeadroomEv` | `asm/ZNK22IOSkywalkNetworkPacket11getHeadroomEv.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297f098` | 10 | `__ZN22IOSkywalkNetworkPacket19setLinkHeaderLengthEh` | `asm/ZN22IOSkywalkNetworkPacket19setLinkHeaderLengthEh.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297f0b2` | 5 | `__ZNK22IOSkywalkNetworkPacket19getLinkHeaderLengthEv` | `asm/ZNK22IOSkywalkNetworkPacket19getLinkHeaderLengthEv.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297f0c0` | 14 | `__ZN22IOSkywalkNetworkPacket19setLinkHeaderOffsetEj` | `asm/ZN22IOSkywalkNetworkPacket19setLinkHeaderOffsetEj.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297f0ec` | 19 | `__ZNK22IOSkywalkNetworkPacket19getLinkHeaderOffsetEPj` | `asm/ZNK22IOSkywalkNetworkPacket19getLinkHeaderOffsetEPj.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297f118` | 14 | `__ZN22IOSkywalkNetworkPacket22setNetworkHeaderOffsetEj` | `asm/ZN22IOSkywalkNetworkPacket22setNetworkHeaderOffsetEj.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297f144` | 19 | `__ZNK22IOSkywalkNetworkPacket22getNetworkHeaderOffsetEPj` | `asm/ZNK22IOSkywalkNetworkPacket22getNetworkHeaderOffsetEPj.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297f170` | 5 | `__ZNK22IOSkywalkNetworkPacket15getServiceClassEv` | `asm/ZNK22IOSkywalkNetworkPacket15getServiceClassEv.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297f17e` | 8 | `__ZNK22IOSkywalkNetworkPacket14isHighPriorityEv` | `asm/ZNK22IOSkywalkNetworkPacket14isHighPriorityEv.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297f192` | 6 | `__ZNK22IOSkywalkNetworkPacket13getPacketTypeEv` | `asm/ZNK22IOSkywalkNetworkPacket13getPacketTypeEv.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297f19e` | 5 | `__ZN22IOSkywalkNetworkPacket11setWakeFlagEv` | `asm/ZN22IOSkywalkNetworkPacket11setWakeFlagEv.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297f1ac` | 5 | `__ZNK22IOSkywalkNetworkPacket9isPureAckEv` | `asm/ZNK22IOSkywalkNetworkPacket9isPureAckEv.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297f1b4` | 14 | `__ZNK22IOSkywalkNetworkPacket29getCompressionGenerationCountEPj` | `asm/ZNK22IOSkywalkNetworkPacket29getCompressionGenerationCountEPj.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297f1da` | 13 | `__ZN22IOSkywalkNetworkPacket18setDataContainsFCSEb` | `asm/ZN22IOSkywalkNetworkPacket18setDataContainsFCSEb.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297f1fe` | 8 | `__ZNK22IOSkywalkNetworkPacket18getDataContainsFCSEv` | `asm/ZNK22IOSkywalkNetworkPacket18getDataContainsFCSEv.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297f212` | 8 | `__ZNK22IOSkywalkNetworkPacket18isTransportNewFlowEv` | `asm/ZNK22IOSkywalkNetworkPacket18isTransportNewFlowEv.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297f226` | 8 | `__ZNK22IOSkywalkNetworkPacket21isTransportLastPacketEv` | `asm/ZNK22IOSkywalkNetworkPacket21isTransportLastPacketEv.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297f23a` | 8 | `__ZNK22IOSkywalkNetworkPacket28isTransportTrafficBackgroundEv` | `asm/ZNK22IOSkywalkNetworkPacket28isTransportTrafficBackgroundEv.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297f24e` | 8 | `__ZNK22IOSkywalkNetworkPacket26isTransportTrafficRealtimeEv` | `asm/ZNK22IOSkywalkNetworkPacket26isTransportTrafficRealtimeEv.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297f262` | 10 | `__ZN22IOSkywalkNetworkPacket18setIsLinkBroadcastEb` | `asm/ZN22IOSkywalkNetworkPacket18setIsLinkBroadcastEb.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297f27c` | 8 | `__ZNK22IOSkywalkNetworkPacket15isLinkBroadcastEv` | `asm/ZNK22IOSkywalkNetworkPacket15isLinkBroadcastEv.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297f290` | 10 | `__ZN22IOSkywalkNetworkPacket18setIsLinkMulticastEb` | `asm/ZN22IOSkywalkNetworkPacket18setIsLinkMulticastEb.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297f2aa` | 8 | `__ZNK22IOSkywalkNetworkPacket15isLinkMulticastEv` | `asm/ZNK22IOSkywalkNetworkPacket15isLinkMulticastEv.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297f2be` | 24 | `__ZNK22IOSkywalkNetworkPacket12getTimestampEPy` | `asm/ZNK22IOSkywalkNetworkPacket12getTimestampEPy.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297f302` | 10 | `__ZN22IOSkywalkNetworkPacket12setTimestampEy` | `asm/ZN22IOSkywalkNetworkPacket12setTimestampEy.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297f320` | 12 | `__ZN22IOSkywalkNetworkPacket14clearTimestampEv` | `asm/ZN22IOSkywalkNetworkPacket14clearTimestampEv.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297f33e` | 18 | `__ZNK22IOSkywalkNetworkPacket20isTimestampRequestedEv` | `asm/ZNK22IOSkywalkNetworkPacket20isTimestampRequestedEv.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297f36c` | 10 | `__ZN22IOSkywalkNetworkPacket19setCompletionStatusEi` | `asm/ZN22IOSkywalkNetworkPacket19setCompletionStatusEi.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297f386` | 17 | `__ZNK22IOSkywalkNetworkPacket13getExpiryTimeEPy` | `asm/ZNK22IOSkywalkNetworkPacket13getExpiryTimeEPy.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297f3b6` | 29 | `__ZNK22IOSkywalkNetworkPacket15getExpiryActionEPh` | `asm/ZNK22IOSkywalkNetworkPacket15getExpiryActionEPh.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297f404` | 8 | `__ZNK22IOSkywalkNetworkPacket18isPacketGroupStartEv` | `asm/ZNK22IOSkywalkNetworkPacket18isPacketGroupStartEv.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297f418` | 8 | `__ZNK22IOSkywalkNetworkPacket16isPacketGroupEndEv` | `asm/ZNK22IOSkywalkNetworkPacket16isPacketGroupEndEv.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297f42c` | 17 | `__ZNK22IOSkywalkNetworkPacket12getTokenDataEPvPt` | `asm/ZNK22IOSkywalkNetworkPacket12getTokenDataEPvPt.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297f45c` | 17 | `__ZNK22IOSkywalkNetworkPacket11getPacketIDEP9packet_id` | `asm/ZNK22IOSkywalkNetworkPacket11getPacketIDEP9packet_id.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297f48c` | 5 | `__ZNK22IOSkywalkNetworkPacket10getTraceIDEv` | `asm/ZNK22IOSkywalkNetworkPacket10getTraceIDEv.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297f49a` | 5 | `__ZN22IOSkywalkNetworkPacket10setTraceIDEj` | `asm/ZN22IOSkywalkNetworkPacket10setTraceIDEj.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297f4a8` | 5 | `__ZN22IOSkywalkNetworkPacket10traceEventEj` | `asm/ZN22IOSkywalkNetworkPacket10traceEventEj.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297f4b6` | 5 | `__ZN22IOSkywalkNetworkPacket20setFPDSequenceNumberEj` | `asm/ZN22IOSkywalkNetworkPacket20setFPDSequenceNumberEj.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297f4c4` | 5 | `__ZN22IOSkywalkNetworkPacket15setFPDContextIDEt` | `asm/ZN22IOSkywalkNetworkPacket15setFPDContextIDEt.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297f4d2` | 5 | `__ZN22IOSkywalkNetworkPacket13setFPDCommandEh` | `asm/ZN22IOSkywalkNetworkPacket13setFPDCommandEh.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297f4e0` | 17 | `__ZNK22IOSkywalkNetworkPacket9getFlowIDEPj` | `asm/ZNK22IOSkywalkNetworkPacket9getFlowIDEPj.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297f510` | 21 | `__ZN22IOSkywalkNetworkPacket17setRxChecksumInfoEjt` | `asm/ZN22IOSkywalkNetworkPacket17setRxChecksumInfoEjt.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297f548` | 28 | `__ZNK22IOSkywalkNetworkPacket10getTSOInfoEPtPj` | `asm/ZNK22IOSkywalkNetworkPacket10getTSOInfoEPtPj.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297f59a` | 37 | `__ZNK22IOSkywalkNetworkPacket17getTxChecksumInfoEPjPtS1_` | `asm/ZNK22IOSkywalkNetworkPacket17getTxChecksumInfoEPjPtS1_.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297f606` | 9 | `__ZN22IOSkywalkNetworkPacket10setLROInfoEjh` | `asm/ZN22IOSkywalkNetworkPacket10setLROInfoEjh.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297f61a` | 5 | `__ZN22IOSkywalkNetworkPacket15getTrafficClassEv` | `asm/ZN22IOSkywalkNetworkPacket15getTrafficClassEv.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297f628` | 17 | `__ZN22IOSkywalkNetworkPacket15setTrafficClassEj` | `asm/ZN22IOSkywalkNetworkPacket15setTrafficClassEj.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297f658` | 5 | `__ZNK22IOSkywalkNetworkPacket6getMSSEv` | `asm/ZNK22IOSkywalkNetworkPacket6getMSSEv.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297f666` | 16 | `__ZNK22IOSkywalkNetworkPacket14getTxCsumFlagsEv` | `asm/ZNK22IOSkywalkNetworkPacket14getTxCsumFlagsEv.asm.txt` |
| `IOSkywalkNetworkPacket` | `0xffffff800297f69a` | 4 | `__ZN22IOSkywalkNetworkPacket9MetaClassD0Ev` | `asm/ZN22IOSkywalkNetworkPacket9MetaClassD0Ev.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e086` | 15 | `__ZN15IOSkywalkPacket9MetaClassC1Ev` | `asm/ZN15IOSkywalkPacket9MetaClassC1Ev.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e0b8` | 4 | `__ZN15IOSkywalkPacket9MetaClassD1Ev` | `asm/ZN15IOSkywalkPacket9MetaClassD1Ev.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e0c2` | 13 | `__ZN15IOSkywalkPacketC2EPK11OSMetaClass` | `asm/ZN15IOSkywalkPacketC2EPK11OSMetaClass.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e0e2` | 13 | `__ZN15IOSkywalkPacketC1EPK11OSMetaClass` | `asm/ZN15IOSkywalkPacketC1EPK11OSMetaClass.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e102` | 4 | `__ZN15IOSkywalkPacketD2Ev` | `asm/ZN15IOSkywalkPacketD2Ev.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e10c` | 4 | `__ZN15IOSkywalkPacketD1Ev` | `asm/ZN15IOSkywalkPacketD1Ev.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e116` | 13 | `__ZN15IOSkywalkPacketD0Ev` | `asm/ZN15IOSkywalkPacketD0Ev.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e13e` | 8 | `__ZN15IOSkywalkPacketdlEPvm` | `asm/ZN15IOSkywalkPacketdlEPvm.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e156` | 6 | `__ZNK15IOSkywalkPacket12getMetaClassEv` | `asm/ZNK15IOSkywalkPacket12getMetaClassEv.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e164` | 15 | `__ZN15IOSkywalkPacket9MetaClassC2Ev` | `asm/ZN15IOSkywalkPacket9MetaClassC2Ev.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e196` | 22 | `__ZNK15IOSkywalkPacket9MetaClass5allocEv` | `asm/ZNK15IOSkywalkPacket9MetaClass5allocEv.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e1de` | 6 | `__ZN15IOSkywalkPacketnwEm` | `asm/ZN15IOSkywalkPacketnwEm.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e1f2` | 16 | `__ZN15IOSkywalkPacketC1Ev` | `asm/ZN15IOSkywalkPacketC1Ev.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e222` | 16 | `__ZN15IOSkywalkPacketC2Ev` | `asm/ZN15IOSkywalkPacketC2Ev.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e252` | 45 | `__ZN15IOSkywalkPacket8withPoolEP25IOSkywalkPacketBufferPoolP25IOSkywalkPacketDescriptorj` | `asm/ZN15IOSkywalkPacket8withPoolEP25IOSkywalkPacketBufferPoolP25IOSkywalkPacketDescriptorj.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e2d8` | 52 | `__ZN15IOSkywalkPacket12initWithPoolEP25IOSkywalkPacketBufferPoolP25IOSkywalkPacketDescriptorj` | `asm/ZN15IOSkywalkPacket12initWithPoolEP25IOSkywalkPacketBufferPoolP25IOSkywalkPacketDescriptorj.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e376` | 23 | `__ZN15IOSkywalkPacket4freeEv` | `asm/ZN15IOSkywalkPacket4freeEv.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e3c6` | 5 | `__ZNK15IOSkywalkPacket19getPacketBufferPoolEv` | `asm/ZNK15IOSkywalkPacket19getPacketBufferPoolEv.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e3d0` | 7 | `__ZNK15IOSkywalkPacket13getBufferSizeEv` | `asm/ZNK15IOSkywalkPacket13getBufferSizeEv.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e3de` | 6 | `__ZNK15IOSkywalkPacket20getPacketBufferCountEv` | `asm/ZNK15IOSkywalkPacket20getPacketBufferCountEv.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e3e8` | 29 | `__ZNK15IOSkywalkPacket13getDataLengthEv` | `asm/ZNK15IOSkywalkPacket13getDataLengthEv.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e430` | 19 | `__ZNK15IOSkywalkPacket21getDataVirtualAddressEv` | `asm/ZNK15IOSkywalkPacket21getDataVirtualAddressEv.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e462` | 20 | `__ZNK15IOSkywalkPacket23getDataIOVirtualAddressEv` | `asm/ZNK15IOSkywalkPacket23getDataIOVirtualAddressEv.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e498` | 5 | `__ZNK15IOSkywalkPacket14getSourceQueueEv` | `asm/ZNK15IOSkywalkPacket14getSourceQueueEv.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e4a2` | 31 | `__ZN15IOSkywalkPacket7prepareEP20IOSkywalkPacketQueueyj` | `asm/ZN15IOSkywalkPacket7prepareEP20IOSkywalkPacketQueueyj.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e4ee` | 67 | `__ZN15IOSkywalkPacket16prepareWithQueueEP20IOSkywalkPacketQueuejj` | `asm/ZN15IOSkywalkPacket16prepareWithQueueEP20IOSkywalkPacketQueuejj.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e5c6` | 31 | `__ZN15IOSkywalkPacket8completeEP20IOSkywalkPacketQueuej` | `asm/ZN15IOSkywalkPacket8completeEP20IOSkywalkPacketQueuej.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e612` | 53 | `__ZN15IOSkywalkPacket17completeWithQueueEP20IOSkywalkPacketQueuejj` | `asm/ZN15IOSkywalkPacket17completeWithQueueEP20IOSkywalkPacketQueuejj.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e6aa` | 23 | `__ZN15IOSkywalkPacket8finalizeEv` | `asm/ZN15IOSkywalkPacket8finalizeEv.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e6e6` | 16 | `__ZNK15IOSkywalkPacket16generateTraceTagEP20IOSkywalkPacketQueue` | `asm/ZNK15IOSkywalkPacket16generateTraceTagEP20IOSkywalkPacketQueue.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e70c` | 5 | `__ZNK15IOSkywalkPacket11getTraceTagEv` | `asm/ZNK15IOSkywalkPacket11getTraceTagEv.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e71a` | 5 | `__ZNK15IOSkywalkPacket11setTraceTagEt` | `asm/ZNK15IOSkywalkPacket11setTraceTagEt.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e728` | 17 | `__ZN15IOSkywalkPacket14getAppMetadataEP26packet_app_metadata_type_tPh` | `asm/ZN15IOSkywalkPacket14getAppMetadataEP26packet_app_metadata_type_tPh.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e758` | 8 | `__ZN15IOSkywalkPacket23acquireWithPacketHandleEyj` | `asm/ZN15IOSkywalkPacket23acquireWithPacketHandleEyj.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e76c` | 29 | `__ZN15IOSkywalkPacket13disposePacketEv` | `asm/ZN15IOSkywalkPacket13disposePacketEv.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e7c2` | 6 | `__ZN15IOSkywalkPacket20setTransferDirectionEj` | `asm/ZN15IOSkywalkPacket20setTransferDirectionEj.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e7cc` | 6 | `__ZNK15IOSkywalkPacket20getTransferDirectionEv` | `asm/ZNK15IOSkywalkPacket20getTransferDirectionEv.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e7d6` | 6 | `__ZN15IOSkywalkPacket22clearTransferDirectionEv` | `asm/ZN15IOSkywalkPacket22clearTransferDirectionEv.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e7e4` | 5 | `__ZNK15IOSkywalkPacket13getPacketTypeEv` | `asm/ZNK15IOSkywalkPacket13getPacketTypeEv.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e7ec` | 5 | `__ZN15IOSkywalkPacket24cancelCompletionCallbackEv` | `asm/ZN15IOSkywalkPacket24cancelCompletionCallbackEv.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e7fa` | 5 | `__ZN15IOSkywalkPacket13setNextPacketEPS_` | `asm/ZN15IOSkywalkPacket13setNextPacketEPS_.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e804` | 5 | `__ZN15IOSkywalkPacket13getNextPacketEv` | `asm/ZN15IOSkywalkPacket13getNextPacketEv.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e80e` | 4 | `__ZN15IOSkywalkPacket9MetaClassD0Ev` | `asm/ZN15IOSkywalkPacket9MetaClassD0Ev.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e818` | 4 | `__ZN15IOSkywalkPacket11setWakeFlagEv` | `asm/ZN15IOSkywalkPacket11setWakeFlagEv.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e81e` | 5 | `__ZNK15IOSkywalkPacket10getTraceIDEv` | `asm/ZNK15IOSkywalkPacket10getTraceIDEv.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e826` | 4 | `__ZN15IOSkywalkPacket10setTraceIDEj` | `asm/ZN15IOSkywalkPacket10setTraceIDEj.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e82c` | 4 | `__ZN15IOSkywalkPacket10traceEventEj` | `asm/ZN15IOSkywalkPacket10traceEventEj.asm.txt` |
| `IOSkywalkPacket` | `0xffffff80029a2398` | 25 | `__ZNK15IOSkywalkPacket16getPacketBuffersEPP21IOSkywalkPacketBufferj` | `asm/ZNK15IOSkywalkPacket16getPacketBuffersEPP21IOSkywalkPacketBufferj.asm.txt` |
| `IOSkywalkPacket` | `0xffffff80029a23d2` | 11 | `__ZNK15IOSkywalkPacket19getMemoryDescriptorEv` | `asm/ZNK15IOSkywalkPacket19getMemoryDescriptorEv.asm.txt` |
| `IOSkywalkPacket` | `0xffffff80029a23ec` | 11 | `__ZN15IOSkywalkPacket13setDataLengthEj` | `asm/ZN15IOSkywalkPacket13setDataLengthEj.asm.txt` |
| `IOSkywalkPacket` | `0xffffff80029a240a` | 11 | `__ZN15IOSkywalkPacket10setDataOffEx` | `asm/ZN15IOSkywalkPacket10setDataOffEx.asm.txt` |
| `IOSkywalkPacket` | `0xffffff80029a2428` | 12 | `__ZNK15IOSkywalkPacket10getDataOffEv` | `asm/ZNK15IOSkywalkPacket10getDataOffEv.asm.txt` |
| `IOSkywalkPacket` | `0xffffff80029a2444` | 53 | `__ZN15IOSkywalkPacket16setDataOffAndLenExm` | `asm/ZN15IOSkywalkPacket16setDataOffAndLenExm.asm.txt` |
| `IOSkywalkPacket` | `0xffffff80029a24d0` | 52 | `__ZN15IOSkywalkPacket22setDataOffsetAndLengthEtj` | `asm/ZN15IOSkywalkPacket22setDataOffsetAndLengthEtj.asm.txt` |
| `IOSkywalkPacket` | `0xffffff80029a2558` | 13 | `__ZN15IOSkywalkPacket13setDataOffsetEt` | `asm/ZN15IOSkywalkPacket13setDataOffsetEt.asm.txt` |
| `IOSkywalkPacket` | `0xffffff80029a257a` | 13 | `__ZNK15IOSkywalkPacket13getDataOffsetEv` | `asm/ZNK15IOSkywalkPacket13getDataOffsetEv.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297c9ec` | 15 | `__ZN25IOSkywalkPacketBufferPool9MetaClassC1Ev` | `asm/ZN25IOSkywalkPacketBufferPool9MetaClassC1Ev.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297ca1e` | 4 | `__ZN25IOSkywalkPacketBufferPool9MetaClassD1Ev` | `asm/ZN25IOSkywalkPacketBufferPool9MetaClassD1Ev.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297ca28` | 13 | `__ZN25IOSkywalkPacketBufferPoolC2EPK11OSMetaClass` | `asm/ZN25IOSkywalkPacketBufferPoolC2EPK11OSMetaClass.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297ca48` | 13 | `__ZN25IOSkywalkPacketBufferPoolC1EPK11OSMetaClass` | `asm/ZN25IOSkywalkPacketBufferPoolC1EPK11OSMetaClass.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297ca68` | 4 | `__ZN25IOSkywalkPacketBufferPoolD2Ev` | `asm/ZN25IOSkywalkPacketBufferPoolD2Ev.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297ca72` | 4 | `__ZN25IOSkywalkPacketBufferPoolD1Ev` | `asm/ZN25IOSkywalkPacketBufferPoolD1Ev.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297ca7c` | 13 | `__ZN25IOSkywalkPacketBufferPoolD0Ev` | `asm/ZN25IOSkywalkPacketBufferPoolD0Ev.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297caa4` | 8 | `__ZN25IOSkywalkPacketBufferPooldlEPvm` | `asm/ZN25IOSkywalkPacketBufferPooldlEPvm.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297cabc` | 6 | `__ZNK25IOSkywalkPacketBufferPool12getMetaClassEv` | `asm/ZNK25IOSkywalkPacketBufferPool12getMetaClassEv.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297caca` | 15 | `__ZN25IOSkywalkPacketBufferPool9MetaClassC2Ev` | `asm/ZN25IOSkywalkPacketBufferPool9MetaClassC2Ev.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297cafc` | 22 | `__ZNK25IOSkywalkPacketBufferPool9MetaClass5allocEv` | `asm/ZNK25IOSkywalkPacketBufferPool9MetaClass5allocEv.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297cb44` | 6 | `__ZN25IOSkywalkPacketBufferPoolnwEm` | `asm/ZN25IOSkywalkPacketBufferPoolnwEm.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297cb58` | 16 | `__ZN25IOSkywalkPacketBufferPoolC1Ev` | `asm/ZN25IOSkywalkPacketBufferPoolC1Ev.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297cb88` | 16 | `__ZN25IOSkywalkPacketBufferPoolC2Ev` | `asm/ZN25IOSkywalkPacketBufferPoolC2Ev.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297cbb8` | 47 | `__ZN25IOSkywalkPacketBufferPool8withNameEPKcP8OSObjectjPKNS_11PoolOptionsE` | `asm/ZN25IOSkywalkPacketBufferPool8withNameEPKcP8OSObjectjPKNS_11PoolOptionsE.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297cc46` | 7 | `__ZN25IOSkywalkPacketBufferPool12initWithNameEPKcPvjPKNS_11PoolOptionsE` | `asm/ZN25IOSkywalkPacketBufferPool12initWithNameEPKcPvjPKNS_11PoolOptionsE.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297cc58` | 263 | `__ZN25IOSkywalkPacketBufferPool12initWithNameEPKcP8OSObjectjPKNS_11PoolOptionsE` | `asm/ZN25IOSkywalkPacketBufferPool12initWithNameEPKcP8OSObjectjPKNS_11PoolOptionsE.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297d0c6` | 58 | `__ZN25IOSkywalkPacketBufferPool27reportingChangeNotificationEv` | `asm/ZN25IOSkywalkPacketBufferPool27reportingChangeNotificationEv.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297d17c` | 51 | `__ZN25IOSkywalkPacketBufferPool18segmentConstructorEP13kern_pbufpoolP9sksegmentP18IOMemoryDescriptor` | `asm/ZN25IOSkywalkPacketBufferPool18segmentConstructorEP13kern_pbufpoolP9sksegmentP18IOMemoryDescriptor.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297d20e` | 31 | `__ZN25IOSkywalkPacketBufferPool17segmentDestructorEP13kern_pbufpoolP9sksegmentP18IOMemoryDescriptor` | `asm/ZN25IOSkywalkPacketBufferPool17segmentDestructorEP13kern_pbufpoolP9sksegmentP18IOMemoryDescriptor.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297d276` | 26 | `__ZNK25IOSkywalkPacketBufferPool7releaseEv` | `asm/ZNK25IOSkywalkPacketBufferPool7releaseEv.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297d2ca` | 46 | `__ZN25IOSkywalkPacketBufferPool17disposeAllPacketsEv` | `asm/ZN25IOSkywalkPacketBufferPool17disposeAllPacketsEv.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297d366` | 22 | `__ZN25IOSkywalkPacketBufferPool17disposeAllBuffersEv` | `asm/ZN25IOSkywalkPacketBufferPool17disposeAllBuffersEv.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297d3bc` | 57 | `__ZN25IOSkywalkPacketBufferPool4freeEv` | `asm/ZN25IOSkywalkPacketBufferPool4freeEv.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297d4c0` | 27 | `__ZN25IOSkywalkPacketBufferPool17releaseAllPacketsEv` | `asm/ZN25IOSkywalkPacketBufferPool17releaseAllPacketsEv.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297d518` | 19 | `__ZN25IOSkywalkPacketBufferPool24releaseAllMemorySegmentsEv` | `asm/ZN25IOSkywalkPacketBufferPool24releaseAllMemorySegmentsEv.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297d556` | 18 | `__ZNK25IOSkywalkPacketBufferPool11getPoolNameEv` | `asm/ZNK25IOSkywalkPacketBufferPool11getPoolNameEv.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297d592` | 15 | `__ZN25IOSkywalkPacketBufferPool19acquireKernelPacketEy` | `asm/ZN25IOSkywalkPacketBufferPool19acquireKernelPacketEy.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297d5b6` | 44 | `__ZN25IOSkywalkPacketBufferPool21allocateKernelPacketsEjPyPjj` | `asm/ZN25IOSkywalkPacketBufferPool21allocateKernelPacketsEjPyPjj.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297d626` | 18 | `__ZN25IOSkywalkPacketBufferPool16freeKernelPacketEy` | `asm/ZN25IOSkywalkPacketBufferPool16freeKernelPacketEy.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297d65a` | 14 | `__ZN25IOSkywalkPacketBufferPool19disposeKernelPacketEy` | `asm/ZN25IOSkywalkPacketBufferPool19disposeKernelPacketEy.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297d680` | 35 | `__ZN25IOSkywalkPacketBufferPool17freeKernelPacketsEPyj` | `asm/ZN25IOSkywalkPacketBufferPool17freeKernelPacketsEPyj.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297d6dc` | 11 | `__ZNK25IOSkywalkPacketBufferPool24getKernelPacketWithIndexEj` | `asm/ZNK25IOSkywalkPacketBufferPool24getKernelPacketWithIndexEj.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297d6f4` | 7 | `__ZN25IOSkywalkPacketBufferPool28disposeKernelPacketWithIndexEyj` | `asm/ZN25IOSkywalkPacketBufferPool28disposeKernelPacketWithIndexEyj.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297d708` | 7 | `__ZN25IOSkywalkPacketBufferPool28acquireKernelPacketWithIndexEyj` | `asm/ZN25IOSkywalkPacketBufferPool28acquireKernelPacketWithIndexEyj.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297d718` | 16 | `__ZNK25IOSkywalkPacketBufferPool26getMemorySegmentWithHandleEP9sksegment` | `asm/ZNK25IOSkywalkPacketBufferPool26getMemorySegmentWithHandleEP9sksegment.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297d742` | 28 | `__ZN25IOSkywalkPacketBufferPool9newPacketEP25IOSkywalkPacketDescriptorPP15IOSkywalkPacket` | `asm/ZN25IOSkywalkPacketBufferPool9newPacketEP25IOSkywalkPacketDescriptorPP15IOSkywalkPacket.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297d78c` | 16 | `__ZN25IOSkywalkPacketBufferPool15newPacketBufferEP31IOSkywalkPacketBufferDescriptorPP21IOSkywalkPacketBuffer` | `asm/ZN25IOSkywalkPacketBufferPool15newPacketBufferEP31IOSkywalkPacketBufferDescriptorPP21IOSkywalkPacketBuffer.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297d7b4` | 16 | `__ZN25IOSkywalkPacketBufferPool16newMemorySegmentEP32IOSkywalkMemorySegmentDescriptorPP22IOSkywalkMemorySegment` | `asm/ZN25IOSkywalkPacketBufferPool16newMemorySegmentEP32IOSkywalkMemorySegmentDescriptorPP22IOSkywalkMemorySegment.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297d7dc` | 16 | `__ZNK25IOSkywalkPacketBufferPool19getPacketWithHandleEy` | `asm/ZNK25IOSkywalkPacketBufferPool19getPacketWithHandleEy.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297d806` | 17 | `__ZNK25IOSkywalkPacketBufferPool18getPacketWithIndexEj` | `asm/ZNK25IOSkywalkPacketBufferPool18getPacketWithIndexEj.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297d82e` | 10 | `__ZN25IOSkywalkPacketBufferPool14allocatePacketEPP15IOSkywalkPacketj` | `asm/ZN25IOSkywalkPacketBufferPool14allocatePacketEPP15IOSkywalkPacketj.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297d84a` | 38 | `__ZN25IOSkywalkPacketBufferPool22completePreparedPacketEP15IOSkywalkPacket` | `asm/ZN25IOSkywalkPacketBufferPool22completePreparedPacketEP15IOSkywalkPacket.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297d8ae` | 29 | `__ZN25IOSkywalkPacketBufferPool20deallocatePacketListEP15IOSkywalkPacket` | `asm/ZN25IOSkywalkPacketBufferPool20deallocatePacketListEP15IOSkywalkPacket.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297da3c` | 46 | `__ZN25IOSkywalkPacketBufferPool18checkInPacketQueueEPK20IOSkywalkPacketQueue` | `asm/ZN25IOSkywalkPacketBufferPool18checkInPacketQueueEPK20IOSkywalkPacketQueue.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297dad0` | 63 | `__ZN25IOSkywalkPacketBufferPool19checkOutPacketQueueEPK20IOSkywalkPacketQueue` | `asm/ZN25IOSkywalkPacketBufferPool19checkOutPacketQueueEPK20IOSkywalkPacketQueue.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297dbb6` | 36 | `__ZN25IOSkywalkPacketBufferPool23checkInReportingServiceEP9IOServicePK18IOSkywalkInterface` | `asm/ZN25IOSkywalkPacketBufferPool23checkInReportingServiceEP9IOServicePK18IOSkywalkInterface.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297dc2e` | 67 | `__ZN25IOSkywalkPacketBufferPool25createReportersForServiceEP9IOServicePK18IOSkywalkInterface` | `asm/ZN25IOSkywalkPacketBufferPool25createReportersForServiceEP9IOServicePK18IOSkywalkInterface.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297dd18` | 22 | `__ZN25IOSkywalkPacketBufferPool24checkOutReportingServiceEPK9IOService` | `asm/ZN25IOSkywalkPacketBufferPool24checkOutReportingServiceEPK9IOService.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297dd64` | 48 | `__ZN25IOSkywalkPacketBufferPool25removeReportersForServiceEPK9IOService` | `asm/ZN25IOSkywalkPacketBufferPool25removeReportersForServiceEPK9IOService.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297ddf2` | 69 | `__ZN25IOSkywalkPacketBufferPool15addPoolReporterEP9IOServiceP5OSSet` | `asm/ZN25IOSkywalkPacketBufferPool15addPoolReporterEP9IOServiceP5OSSet.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297ded4` | 56 | `__ZN25IOSkywalkPacketBufferPool23copyReportersForServiceEPK9IOService` | `asm/ZN25IOSkywalkPacketBufferPool23copyReportersForServiceEPK9IOService.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297df90` | 62 | `__ZN25IOSkywalkPacketBufferPool21getReportChannelValueEy` | `asm/ZN25IOSkywalkPacketBufferPool21getReportChannelValueEy.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297e038` | 4 | `__ZN25IOSkywalkPacketBufferPool9MetaClassD0Ev` | `asm/ZN25IOSkywalkPacketBufferPool9MetaClassD0Ev.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff80029a1aca` | 33 | `__ZN25IOSkywalkPacketBufferPool20allocateKernelPacketEjPyj` | `asm/ZN25IOSkywalkPacketBufferPool20allocateKernelPacketEjPyj.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff80029a1b1c` | 122 | `__ZN25IOSkywalkPacketBufferPool20createSegmentBuffersEP22IOSkywalkMemorySegmentjb` | `asm/ZN25IOSkywalkPacketBufferPool20createSegmentBuffersEP22IOSkywalkMemorySegmentjb.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff80029a1cb2` | 16 | `__ZN25IOSkywalkPacketBufferPool21destroySegmentBuffersEP22IOSkywalkMemorySegment` | `asm/ZN25IOSkywalkPacketBufferPool21destroySegmentBuffersEP22IOSkywalkMemorySegment.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff80029a1cda` | 73 | `__ZN25IOSkywalkPacketBufferPool20prepareMemorySegmentEP22IOSkywalkMemorySegmentP24IOBufferMemoryDescriptory` | `asm/ZN25IOSkywalkPacketBufferPool20prepareMemorySegmentEP22IOSkywalkMemorySegmentP24IOBufferMemoryDescriptory.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff80029a1dc8` | 31 | `__ZNK25IOSkywalkPacketBufferPool31getPacketBufferWithBufletHandleEP13__kern_buflet` | `asm/ZNK25IOSkywalkPacketBufferPool31getPacketBufferWithBufletHandleEP13__kern_buflet.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff80029a1e20` | 28 | `__ZNK25IOSkywalkPacketBufferPool30getPacketBufferWithSegmentInfoEP9sksegmentj` | `asm/ZNK25IOSkywalkPacketBufferPool30getPacketBufferWithSegmentInfoEP9sksegmentj.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff80029a1e66` | 55 | `__ZN25IOSkywalkPacketBufferPool14allocatePacketEjPP15IOSkywalkPacketj` | `asm/ZN25IOSkywalkPacketBufferPool14allocatePacketEjPP15IOSkywalkPacketj.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff80029a1f10` | 108 | `__ZN25IOSkywalkPacketBufferPool15allocatePacketsEjPjPP15IOSkywalkPacketj` | `asm/ZN25IOSkywalkPacketBufferPool15allocatePacketsEjPjPP15IOSkywalkPacketj.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff80029a2072` | 28 | `__ZN25IOSkywalkPacketBufferPool16deallocatePacketEP15IOSkywalkPacket` | `asm/ZN25IOSkywalkPacketBufferPool16deallocatePacketEP15IOSkywalkPacket.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff80029a20be` | 53 | `__ZN25IOSkywalkPacketBufferPool17deallocatePacketsEPP15IOSkywalkPacketj` | `asm/ZN25IOSkywalkPacketBufferPool17deallocatePacketsEPP15IOSkywalkPacketj.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff80029a214a` | 10 | `__ZN25IOSkywalkPacketBufferPool21deallocatePacketChainEy` | `asm/ZN25IOSkywalkPacketBufferPool21deallocatePacketChainEy.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff80029a2160` | 49 | `__ZN25IOSkywalkPacketBufferPool20allocatePacketBufferEPP21IOSkywalkPacketBufferj` | `asm/ZN25IOSkywalkPacketBufferPool20allocatePacketBufferEPP21IOSkywalkPacketBufferj.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff80029a21fe` | 48 | `__ZN25IOSkywalkPacketBufferPool21allocatePacketBuffersEPjPP21IOSkywalkPacketBufferj` | `asm/ZN25IOSkywalkPacketBufferPool21allocatePacketBuffersEPjPP21IOSkywalkPacketBufferj.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff80029a2278` | 32 | `__ZN25IOSkywalkPacketBufferPool22deallocatePacketBufferEP21IOSkywalkPacketBuffer` | `asm/ZN25IOSkywalkPacketBufferPool22deallocatePacketBufferEP21IOSkywalkPacketBuffer.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff80029a22d0` | 28 | `__ZN25IOSkywalkPacketBufferPool23deallocatePacketBuffersEPP21IOSkywalkPacketBufferj` | `asm/ZN25IOSkywalkPacketBufferPool23deallocatePacketBuffersEPP21IOSkywalkPacketBufferj.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff80029a2316` | 25 | `__ZN25IOSkywalkPacketBufferPool17segmentDestructorEP13kern_pbufpoolP9sksegmentP18IOMemoryDescriptor.cold.1` | `asm/ZN25IOSkywalkPacketBufferPool17segmentDestructorEP13kern_pbufpoolP9sksegmentP18IOMemoryDescriptor.cold.1.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff80029a235f` | 15 | `__ZN25IOSkywalkPacketBufferPool9newPacketEP25IOSkywalkPacketDescriptorPP15IOSkywalkPacket.cold.1` | `asm/ZN25IOSkywalkPacketBufferPool9newPacketEP25IOSkywalkPacketDescriptorPP15IOSkywalkPacket.cold.1.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297e876` | 15 | `__ZN21IOSkywalkPacketBuffer9MetaClassC1Ev` | `asm/ZN21IOSkywalkPacketBuffer9MetaClassC1Ev.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297e8a8` | 4 | `__ZN21IOSkywalkPacketBuffer9MetaClassD1Ev` | `asm/ZN21IOSkywalkPacketBuffer9MetaClassD1Ev.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297e8b2` | 13 | `__ZN21IOSkywalkPacketBufferC2EPK11OSMetaClass` | `asm/ZN21IOSkywalkPacketBufferC2EPK11OSMetaClass.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297e8d2` | 13 | `__ZN21IOSkywalkPacketBufferC1EPK11OSMetaClass` | `asm/ZN21IOSkywalkPacketBufferC1EPK11OSMetaClass.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297e8f2` | 4 | `__ZN21IOSkywalkPacketBufferD2Ev` | `asm/ZN21IOSkywalkPacketBufferD2Ev.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297e8fc` | 4 | `__ZN21IOSkywalkPacketBufferD1Ev` | `asm/ZN21IOSkywalkPacketBufferD1Ev.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297e906` | 13 | `__ZN21IOSkywalkPacketBufferD0Ev` | `asm/ZN21IOSkywalkPacketBufferD0Ev.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297e92e` | 8 | `__ZN21IOSkywalkPacketBufferdlEPvm` | `asm/ZN21IOSkywalkPacketBufferdlEPvm.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297e946` | 6 | `__ZNK21IOSkywalkPacketBuffer12getMetaClassEv` | `asm/ZNK21IOSkywalkPacketBuffer12getMetaClassEv.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297e954` | 15 | `__ZN21IOSkywalkPacketBuffer9MetaClassC2Ev` | `asm/ZN21IOSkywalkPacketBuffer9MetaClassC2Ev.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297e986` | 22 | `__ZNK21IOSkywalkPacketBuffer9MetaClass5allocEv` | `asm/ZNK21IOSkywalkPacketBuffer9MetaClass5allocEv.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297e9ce` | 6 | `__ZN21IOSkywalkPacketBuffernwEm` | `asm/ZN21IOSkywalkPacketBuffernwEm.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297e9e2` | 16 | `__ZN21IOSkywalkPacketBufferC1Ev` | `asm/ZN21IOSkywalkPacketBufferC1Ev.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297ea12` | 16 | `__ZN21IOSkywalkPacketBufferC2Ev` | `asm/ZN21IOSkywalkPacketBufferC2Ev.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297ea42` | 45 | `__ZN21IOSkywalkPacketBuffer8withPoolEP25IOSkywalkPacketBufferPoolP31IOSkywalkPacketBufferDescriptorj` | `asm/ZN21IOSkywalkPacketBuffer8withPoolEP25IOSkywalkPacketBufferPoolP31IOSkywalkPacketBufferDescriptorj.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297eac8` | 48 | `__ZN21IOSkywalkPacketBuffer12initWithPoolEP25IOSkywalkPacketBufferPoolP31IOSkywalkPacketBufferDescriptorj` | `asm/ZN21IOSkywalkPacketBuffer12initWithPoolEP25IOSkywalkPacketBufferPoolP31IOSkywalkPacketBufferDescriptorj.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297eb56` | 25 | `__ZN21IOSkywalkPacketBuffer4freeEv` | `asm/ZN21IOSkywalkPacketBuffer4freeEv.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297ebac` | 5 | `__ZNK21IOSkywalkPacketBuffer19getPacketBufferPoolEv` | `asm/ZNK21IOSkywalkPacketBuffer19getPacketBufferPoolEv.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297ebb6` | 5 | `__ZNK21IOSkywalkPacketBuffer9getPacketEv` | `asm/ZNK21IOSkywalkPacketBuffer9getPacketEv.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297ebc0` | 7 | `__ZNK21IOSkywalkPacketBuffer13getBufferSizeEv` | `asm/ZNK21IOSkywalkPacketBuffer13getBufferSizeEv.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297ebce` | 6 | `__ZNK21IOSkywalkPacketBuffer13getDataLengthEv` | `asm/ZNK21IOSkywalkPacketBuffer13getDataLengthEv.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297ebd8` | 6 | `__ZNK21IOSkywalkPacketBuffer13getDataOffsetEv` | `asm/ZNK21IOSkywalkPacketBuffer13getDataOffsetEv.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297ebe6` | 5 | `__ZNK21IOSkywalkPacketBuffer10getDataOffEv` | `asm/ZNK21IOSkywalkPacketBuffer10getDataOffEv.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297ebf2` | 5 | `__ZNK21IOSkywalkPacketBuffer16getMemorySegmentEv` | `asm/ZNK21IOSkywalkPacketBuffer16getMemorySegmentEv.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297ebfc` | 5 | `__ZNK21IOSkywalkPacketBuffer22getMemorySegmentOffsetEv` | `asm/ZNK21IOSkywalkPacketBuffer22getMemorySegmentOffsetEv.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297ec06` | 5 | `__ZNK21IOSkywalkPacketBuffer15getBufletHandleEv` | `asm/ZNK21IOSkywalkPacketBuffer15getBufletHandleEv.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297ec10` | 5 | `__ZN21IOSkywalkPacketBuffer15setBufletHandleEP13__kern_buflet` | `asm/ZN21IOSkywalkPacketBuffer15setBufletHandleEP13__kern_buflet.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297ec1a` | 5 | `__ZNK21IOSkywalkPacketBuffer15getBufferHandleEv` | `asm/ZNK21IOSkywalkPacketBuffer15getBufferHandleEv.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297ec24` | 5 | `__ZN21IOSkywalkPacketBuffer7prepareEj` | `asm/ZN21IOSkywalkPacketBuffer7prepareEj.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297ec2c` | 5 | `__ZN21IOSkywalkPacketBuffer8completeEj` | `asm/ZN21IOSkywalkPacketBuffer8completeEj.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297ec34` | 8 | `__ZN21IOSkywalkPacketBuffer24prepareWithMemorySegmentEP22IOSkywalkMemorySegmentyj` | `asm/ZN21IOSkywalkPacketBuffer24prepareWithMemorySegmentEP22IOSkywalkMemorySegmentyj.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297ec48` | 8 | `__ZN21IOSkywalkPacketBuffer25completeWithMemorySegmentEP22IOSkywalkMemorySegmentyj` | `asm/ZN21IOSkywalkPacketBuffer25completeWithMemorySegmentEP22IOSkywalkMemorySegmentyj.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297ec5c` | 5 | `__ZNK21IOSkywalkPacketBuffer14getSourceQueueEv` | `asm/ZNK21IOSkywalkPacketBuffer14getSourceQueueEv.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297ec66` | 51 | `__ZN21IOSkywalkPacketBuffer16prepareWithQueueEP20IOSkywalkPacketQueuejj` | `asm/ZN21IOSkywalkPacketBuffer16prepareWithQueueEP20IOSkywalkPacketQueuejj.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297ed00` | 27 | `__ZN21IOSkywalkPacketBuffer17completeWithQueueEP20IOSkywalkPacketQueuejj` | `asm/ZN21IOSkywalkPacketBuffer17completeWithQueueEP20IOSkywalkPacketQueuejj.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297ed48` | 18 | `__ZN21IOSkywalkPacketBuffer8finalizeEv` | `asm/ZN21IOSkywalkPacketBuffer8finalizeEv.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297ed7a` | 5 | `__ZN21IOSkywalkPacketBuffer9setPacketEP15IOSkywalkPacketj` | `asm/ZN21IOSkywalkPacketBuffer9setPacketEP15IOSkywalkPacketj.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297ed84` | 6 | `__ZN21IOSkywalkPacketBuffer23acquireWithBufletHandleEP13__kern_buflet` | `asm/ZN21IOSkywalkPacketBuffer23acquireWithBufletHandleEP13__kern_buflet.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297ed94` | 6 | `__ZN21IOSkywalkPacketBuffer23acquireWithBufferHandleEy` | `asm/ZN21IOSkywalkPacketBuffer23acquireWithBufferHandleEy.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297eda4` | 10 | `__ZN21IOSkywalkPacketBuffer19disposePacketBufferEv` | `asm/ZN21IOSkywalkPacketBuffer19disposePacketBufferEv.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297edc2` | 5 | `__ZN21IOSkywalkPacketBuffer24cancelCompletionCallbackEv` | `asm/ZN21IOSkywalkPacketBuffer24cancelCompletionCallbackEv.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297edd0` | 4 | `__ZN21IOSkywalkPacketBuffer9MetaClassD0Ev` | `asm/ZN21IOSkywalkPacketBuffer9MetaClassD0Ev.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff80029a259a` | 14 | `__ZN21IOSkywalkPacketBuffer13setDataLengthEj` | `asm/ZN21IOSkywalkPacketBuffer13setDataLengthEj.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff80029a25be` | 14 | `__ZN21IOSkywalkPacketBuffer13setDataOffsetEt` | `asm/ZN21IOSkywalkPacketBuffer13setDataOffsetEt.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff80029a25e2` | 19 | `__ZN21IOSkywalkPacketBuffer10setDataOffEx` | `asm/ZN21IOSkywalkPacketBuffer10setDataOffEx.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff80029a2616` | 14 | `__ZN21IOSkywalkPacketBuffer22setDataOffsetAndLengthEtj` | `asm/ZN21IOSkywalkPacketBuffer22setDataOffsetAndLengthEtj.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff80029a263c` | 27 | `__ZN21IOSkywalkPacketBuffer16setDataOffAndLenExm` | `asm/ZN21IOSkywalkPacketBuffer16setDataOffAndLenExm.asm.txt` |

### Source evidence snippets

**RTW88WCLSkywalkQueues.cpp:23-32**

```cpp
   23:     if (!super::init())
   24:         return false;
   25:     _txPool = nullptr;
   26:     _rxPool = nullptr;
   27:     _txSubmission = nullptr;
   28:     _txCompletion = nullptr;
   29:     _rxSubmission = nullptr;
   30:     _rxCompletion = nullptr;
   31:     _allocated = false;
   32:     return true;
```

**RTW88WCLSkywalkQueues.cpp:35-43**

```cpp
   35: IOReturn RTW88WCLSkywalkQueues::createQueues()
   36: {
   37:     if (_allocated)
   38:         return kIOReturnSuccess;
   39:     if (_txPool || _rxPool || _txSubmission || _txCompletion ||
   40:         _rxSubmission || _rxCompletion)
   41:         return kIOReturnBusy;
   42: 
   43:     RTW88WCLPoolOptionsAccess::PoolOptions txOptions = {};
```

**RTW88WCLSkywalkQueues.cpp:66-83**

```cpp
   66:     /* These queue objects are deliberately not added to an IOWorkLoop and
   67:      * are not passed to registerEthernetInterface() yet. Skywalk owns their
   68:      * scheduling and packet lifetime only after a complete RegistrationInfo
   69:      * + ring setup transaction, which is a later stage. */
   70:     _txSubmission = IOSkywalkTxSubmissionQueue::withPool(
   71:         _txPool, kQueueCapacity, 0, this,
   72:         &RTW88WCLSkywalkQueues::txSubmissionAction, this, 0);
   73:     if (!_txSubmission)
   74:         goto no_memory;
   75: 
   76:     _txCompletion = IOSkywalkTxCompletionQueue::withPool(
   77:         _txPool, kQueueCapacity, 0, this,
   78:         &RTW88WCLSkywalkQueues::txCompletionAction, this, 0);
   79:     if (!_txCompletion)
   80:         goto no_memory;
   81: 
   82:     _rxSubmission = IOSkywalkRxSubmissionQueue::withPool(
   83:         _rxPool, kQueueCapacity, 0, static_cast<kern_packet_svc_class_t>(0),
```

**RTW88WCLSkywalkQueues.cpp:104-150**

```cpp
  104: {
  105:     /* Release queues before their pools: queue implementations retain and
  106:      * reference their associated pool for packet and buffer accounting. */
  107:     if (_rxCompletion) {
  108:         _rxCompletion->release();
  109:         _rxCompletion = nullptr;
  110:     }
  111:     if (_rxSubmission) {
  112:         _rxSubmission->release();
  113:         _rxSubmission = nullptr;
  114:     }
  115:     if (_txCompletion) {
  116:         _txCompletion->release();
  117:         _txCompletion = nullptr;
  118:     }
  119:     if (_txSubmission) {
  120:         _txSubmission->release();
  121:         _txSubmission = nullptr;
  122:     }
  123:     if (_rxPool) {
  124:         _rxPool->release();
  125:         _rxPool = nullptr;
  126:     }
  127:     if (_txPool) {
  128:         _txPool->release();
  129:         _txPool = nullptr;
  130:     }
  131:     _allocated = false;
  132: }
  133: 
  134: bool RTW88WCLSkywalkQueues::queuesAllocated() const
  135: {
  136:     return _allocated && _txPool && _rxPool && _txSubmission &&
  137:            _txCompletion && _rxSubmission && _rxCompletion;
  138: }
  139: 
  140: IOReturn RTW88WCLSkywalkQueues::txSubmissionAction(
  141:     OSObject *owner, IOSkywalkTxSubmissionQueue *queue,
  142:     const IOSkywalkPacket **packets, UInt32 packetCount, void *refCon)
  143: {
  144:     (void)refCon;
  145:     auto *self = OSDynamicCast(RTW88WCLSkywalkQueues, owner);
  146:     if (!self || queue != self->_txSubmission || !packets || packetCount == 0)
  147:         return kIOReturnBadArgument;
  148: 
  149:     /* Validate every descriptor before a future TX path is allowed to copy
  150:      * bytes or hand ownership to RTW88. The callback remains fail-closed:
```

**RTW88WCLSkywalkQueues.cpp:161-170**

```cpp
  161: 
  162:     return kIOReturnNotReady;
  163: }
  164: 
  165: IOReturn RTW88WCLSkywalkQueues::txCompletionAction(
  166:     OSObject *owner, IOSkywalkTxCompletionQueue *queue,
  167:     IOSkywalkPacket **packets, UInt32 packetCount, void *refCon)
  168: {
  169:     (void)owner; (void)queue; (void)packets; (void)packetCount; (void)refCon;
  170:     return kIOReturnNotReady;
```

**RTW88WCLSkywalkTxAdapter.cpp:29-38**

```cpp
   29:         return kIOReturnBadArgument;
   30:     if (_radio || _txPool || _tickets.hasOutstanding())
   31:         return kIOReturnBusy;
   32: 
   33:     radio->retain();
   34:     txPool->retain();
   35:     _radio = radio;
   36:     _txPool = txPool;
   37:     return kIOReturnSuccess;
   38: }
```

**RTW88WCLSkywalkTxAdapter.cpp:46-56**

```cpp
   46:     IOSkywalkPacketBufferPool *pool = _txPool;
   47:     _radio = nullptr;
   48:     _txPool = nullptr;
   49:     if (pool)
   50:         pool->release();
   51:     if (radio)
   52:         radio->release();
   53:     return kIOReturnSuccess;
   54: }
   55: 
   56: mbuf_t RTW88WCLSkywalkTxAdapter::copyPacketToMbuf(
```

**RTW88WCLSkywalkTxAdapter.cpp:72-80**

```cpp
   72:     mbuf_pkthdr_setlen(mbuf, length);
   73:     return mbuf;
   74: }
   75: 
   76: IOReturn RTW88WCLSkywalkTxAdapter::submitPacket(IOSkywalkPacket *packet)
   77: {
   78:     if (!packet)
   79:         return kIOReturnBadArgument;
   80:     if (!_radio || !_txPool)
```

**RTW88WCLSkywalkTxAdapter.cpp:87-107**

```cpp
   87:     mbuf_t mbuf = copyPacketToMbuf(view.bytes, view.length);
   88:     if (!mbuf)
   89:         return kIOReturnNoMemory;
   90: 
   91:     packet->retain();
   92:     TicketPool::Ticket *ticket = _tickets.reserve(packet);
   93:     if (!ticket) {
   94:         packet->release();
   95:         mbuf_freem(mbuf);
   96:         return kIOReturnBusy;
   97:     }
   98: 
   99:     /* Keep the adapter alive until the workloop-side completion drain drops
  100:      * this ticket. backendCompletion() intentionally does not release it. */
  101:     retain();
  102:     const UInt32 backendResult = _radio->outputPacketWithCompletion(
  103:         mbuf, &RTW88WCLSkywalkTxAdapter::backendCompletion, this, ticket);
  104: 
  105:     /* outputPacketWithCompletion consumes the mbuf and reports exactly one
  106:      * terminal callback, including synchronous drops. Once the ticket has
  107:      * been reserved, adapter acceptance is successful; the actual transmitted
```

**RTW88WCLSkywalkTxAdapter.cpp:109-159**

```cpp
  109:     (void)backendResult;
  110:     return kIOReturnSuccess;
  111: }
  112: 
  113: void RTW88WCLSkywalkTxAdapter::backendCompletion(
  114:     void *context, void *cookie, bool transmitted)
  115: {
  116:     auto *self = static_cast<RTW88WCLSkywalkTxAdapter *>(context);
  117:     auto *ticket = static_cast<TicketPool::Ticket *>(cookie);
  118:     if (!self || !ticket)
  119:         return;
  120: 
  121:     /* No Skywalk API, OSObject release, allocation, or blocking operation is
  122:      * allowed here. A deferred consumer performs the completion handoff. */
  123:     (void)TicketPool::complete(ticket, transmitted);
  124: }
  125: 
  126: uint32_t RTW88WCLSkywalkTxAdapter::drainCompletions(
  127:     CompletionSink sink, void *context)
  128: {
  129:     if (!sink)
  130:         return 0;
  131: 
  132:     /* A sink may trigger owner teardown; keep this adapter alive until the
  133:      * drain loop has stopped touching its ticket pool. */
  134:     retain();
  135:     uint32_t drained = 0;
  136:     for (;;) {
  137:         TicketPool::Ticket *ticket = _tickets.claimCompleted();
  138:         if (!ticket)
  139:             break;
  140: 
  141:         auto *packet = static_cast<IOSkywalkPacket *>(TicketPool::packet(ticket));
  142:         const bool transmitted = TicketPool::transmitted(ticket);
  143: 
  144:         /* The sink runs in deferred context and borrows the retained packet.
  145:          * It must finish any Skywalk queue handoff before returning. */
  146:         if (packet)
  147:             sink(packet, transmitted, context);
  148: 
  149:         TicketPool::finish(ticket);
  150:         if (packet)
  151:             packet->release();
  152:         release();
  153:         ++drained;
  154:     }
  155:     release();
  156:     return drained;
  157: }
  158: 
  159: bool RTW88WCLSkywalkTxAdapter::hasOutstandingCompletions() const
```

**RTW88WCLTxCompletionSlots.hpp:1-18**

```cpp
    1: /* SPDX-License-Identifier: GPL-2.0-only
    2:  * Fixed-capacity completion tickets for the native WCL TX adapter.
    3:  *
    4:  * Multiple RTW88 completion contexts may publish concurrently. The Skywalk
    5:  * packet operations are deliberately kept out of complete(); a workloop-side
    6:  * consumer claims completed tickets and performs the deferred queue handoff.
    7:  */
    8: #pragma once
    9: 
   10: #include <stdint.h>
   11: 
   12: /* Freestanding so the state machine can be stress-tested outside the kernel. */
   13: template <uint32_t Capacity>
   14: class RTW88WCLTxCompletionSlots {
   15:     static_assert(Capacity > 0, "completion slot capacity must be non-zero");
   16: 
   17: public:
   18:     enum : uint32_t {
```

**RTW88WCLTxCompletionSlots.hpp:64-72**

```cpp
   64:     }
   65: 
   66:     /* Safe for the RTW88 completion callback: bounded atomics only, no
   67:      * allocation, locks, Skywalk calls, or packet release. */
   68:     static bool complete(Ticket *ticket, bool transmitted)
   69:     {
   70:         if (!ticket)
   71:             return false;
   72:         uint32_t expected = kSubmitted;
```

**RTW88WCLTxCompletionSlots.hpp:94-102**

```cpp
   94:         }
   95:         return nullptr;
   96:     }
   97: 
   98:     static void finish(Ticket *ticket)
   99:     {
  100:         if (!ticket)
  101:             return;
  102:         ticket->packet = nullptr;
```

**RTW88WCLController.cpp:76-84**

```cpp
   76:             IOLog("rtl88wifi-wcl: PCI backend allocation failed\n");
   77:             goto fail;
   78:         }
   79:         if (!_pciBackend->init()) {
   80:             _pciBackend->release();
   81:             _pciBackend = nullptr;
   82:             IOLog("rtl88wifi-wcl: PCI backend initialization failed\n");
   83:             goto fail;
   84:         }
```

**RTW88WCLController.cpp:104-112**

```cpp
  104:             goto fail;
  105:         }
  106:         radio->setEventDelegate(this);
  107:         const IOReturn bindStatus = bindRadioBackend(radio);
  108:         radio->release();
  109:         if (bindStatus != kIOReturnSuccess) {
  110:             IOLog("rtl88wifi-wcl: RTW88 state-machine bind failed: 0x%08x\n",
  111:                   bindStatus);
  112:             goto fail;
```

**RTW88WCLController.cpp:119-127**

```cpp
  119:      * conversion and hardware completion correlation are implemented. */
  120:     _skywalkQueues = new RTW88WCLSkywalkQueues;
  121:     if (!_skywalkQueues || !_skywalkQueues->init()) {
  122:         if (_skywalkQueues) {
  123:             _skywalkQueues->release();
  124:             _skywalkQueues = nullptr;
  125:         }
  126:         IOLog("rtl88wifi-wcl: Skywalk queue owner allocation failed\n");
  127:         goto fail;
```

**RTW88WCLController.cpp:142-150**

```cpp
  142:     if (!_rxAdapter || !_rxAdapter->init(
  143:             this, _workLoop, _skywalkQueues->rxPacketPool(),
  144:             &RTW88WCLController::stagedRxFrame, this)) {
  145:         if (_rxAdapter) {
  146:             _rxAdapter->release();
  147:             _rxAdapter = nullptr;
  148:         }
  149:         IOLog("rtl88wifi-wcl: RX packet adapter initialization failed\n");
  150:         goto fail;
```

**RTW88WCLController.cpp:198-206**

```cpp
  198:     /* Remove the RX workloop source only after the RTW88 producer is stopped.
  199:      * stop() waits out an active checkForWork() and releases all staged mbufs. */
  200:     if (_rxAdapter) {
  201:         _rxAdapter->stop();
  202:         _rxAdapter->release();
  203:         _rxAdapter = nullptr;
  204:     }
  205: 
  206:     /* The RX adapter transfers accepted native packets into the controller's
```

**RTW88WCLController.cpp:217-225**

```cpp
  217:     /* Skywalk packet pools/queues are released only after both the mbuf staging
  218:      * adapter and the prepared-packet ownership ring have been drained. */
  219:     if (_skywalkQueues) {
  220:         _skywalkQueues->destroyQueues();
  221:         _skywalkQueues->release();
  222:         _skywalkQueues = nullptr;
  223:     }
  224: 
  225:     if (_pciBackend && _pciBackend->isRadioRunning()) {
```

**RTW88WCLController.cpp:241-249**

```cpp
  241:             IOLog("rtl88wifi-wcl: PCI backend close deferred: 0x%08x\n",
  242:                   closeStatus);
  243:             return;
  244:         }
  245:         _pciBackend->release();
  246:         _pciBackend = nullptr;
  247:     }
  248: }
  249: 
```

**RTW88WCLController.cpp:252-260**

```cpp
  252:     releaseNativeResources();
  253:     if (_pciBackend)
  254:         IOLog("rtl88wifi-wcl: PCI backend retained because shutdown fence did not complete\n");
  255:     if (_workLoop) {
  256:         _workLoop->release();
  257:         _workLoop = nullptr;
  258:     }
  259:     super::free();
  260: }
```

**RTW88WCLController.cpp:396-404**

```cpp
  396:                                      kPacketPathBinding, false,
  397:                                      __ATOMIC_ACQ_REL, __ATOMIC_ACQUIRE))
  398:         return kIOReturnBusy;
  399: 
  400:     interface->retain();
  401:     _packetPathInterface = interface;
  402:     __atomic_store_n(&_packetPathState, kPacketPathActive, __ATOMIC_RELEASE);
  403:     IOLog("rtl88wifi-wcl: native mbuf packet handoff enabled\n");
  404:     return kIOReturnSuccess;
```

**RTW88WCLController.cpp:435-443**

```cpp
  435: 
  436:     IO80211SkywalkInterface *interface = _packetPathInterface;
  437:     _packetPathInterface = nullptr;
  438:     if (interface)
  439:         interface->release();
  440:     __atomic_store_n(&_packetPathState, kPacketPathDisabled, __ATOMIC_RELEASE);
  441:     return kIOReturnSuccess;
  442: }
  443: 
```

**RTW88WCLController.cpp:562-577**

```cpp
  562: IOReturn RTW88WCLController::bindRadioBackend(RTW88IEEE80211 *radio)
  563: {
  564:     if (!radio) return kIOReturnBadArgument;
  565:     if (_radio) return kIOReturnBusy;
  566:     radio->retain();
  567:     _radio = radio;
  568:     return kIOReturnSuccess;
  569: }
  570: 
  571: void RTW88WCLController::unbindRadioBackend()
  572: {
  573:     if (_radio) {
  574:         _radio->release();
  575:         _radio = nullptr;
  576:     }
  577: }
```

### Manual questions

- [ ] Does queue acceptance retain the packet or consume the caller's reference?
- [ ] When may the driver release its packet retain relative to completion callback return?
- [ ] Can completion run synchronously during submit, or only later?
- [ ] What are the error, cancellation and teardown ownership paths?

**Review outcome:** `UNRESOLVED — do not enable this contract`

## pool_buffer_segment_prepare_complete: Packet-buffer and memory-segment prepare/complete requirements

**Status:** MANUAL_REVIEW_REQUIRED
**Candidate method bodies:** 202

### Kernel method candidates

| Class | Address | Instructions | Exact symbol | Assembly file |
|---|---:|---:|---|---|
| `IOSkywalkPacketBufferPool` | `0xffffff800297c9ec` | 15 | `__ZN25IOSkywalkPacketBufferPool9MetaClassC1Ev` | `asm/ZN25IOSkywalkPacketBufferPool9MetaClassC1Ev.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297ca1e` | 4 | `__ZN25IOSkywalkPacketBufferPool9MetaClassD1Ev` | `asm/ZN25IOSkywalkPacketBufferPool9MetaClassD1Ev.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297ca28` | 13 | `__ZN25IOSkywalkPacketBufferPoolC2EPK11OSMetaClass` | `asm/ZN25IOSkywalkPacketBufferPoolC2EPK11OSMetaClass.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297ca48` | 13 | `__ZN25IOSkywalkPacketBufferPoolC1EPK11OSMetaClass` | `asm/ZN25IOSkywalkPacketBufferPoolC1EPK11OSMetaClass.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297ca68` | 4 | `__ZN25IOSkywalkPacketBufferPoolD2Ev` | `asm/ZN25IOSkywalkPacketBufferPoolD2Ev.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297ca72` | 4 | `__ZN25IOSkywalkPacketBufferPoolD1Ev` | `asm/ZN25IOSkywalkPacketBufferPoolD1Ev.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297ca7c` | 13 | `__ZN25IOSkywalkPacketBufferPoolD0Ev` | `asm/ZN25IOSkywalkPacketBufferPoolD0Ev.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297caa4` | 8 | `__ZN25IOSkywalkPacketBufferPooldlEPvm` | `asm/ZN25IOSkywalkPacketBufferPooldlEPvm.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297cabc` | 6 | `__ZNK25IOSkywalkPacketBufferPool12getMetaClassEv` | `asm/ZNK25IOSkywalkPacketBufferPool12getMetaClassEv.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297caca` | 15 | `__ZN25IOSkywalkPacketBufferPool9MetaClassC2Ev` | `asm/ZN25IOSkywalkPacketBufferPool9MetaClassC2Ev.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297cafc` | 22 | `__ZNK25IOSkywalkPacketBufferPool9MetaClass5allocEv` | `asm/ZNK25IOSkywalkPacketBufferPool9MetaClass5allocEv.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297cb44` | 6 | `__ZN25IOSkywalkPacketBufferPoolnwEm` | `asm/ZN25IOSkywalkPacketBufferPoolnwEm.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297cb58` | 16 | `__ZN25IOSkywalkPacketBufferPoolC1Ev` | `asm/ZN25IOSkywalkPacketBufferPoolC1Ev.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297cb88` | 16 | `__ZN25IOSkywalkPacketBufferPoolC2Ev` | `asm/ZN25IOSkywalkPacketBufferPoolC2Ev.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297cbb8` | 47 | `__ZN25IOSkywalkPacketBufferPool8withNameEPKcP8OSObjectjPKNS_11PoolOptionsE` | `asm/ZN25IOSkywalkPacketBufferPool8withNameEPKcP8OSObjectjPKNS_11PoolOptionsE.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297cc46` | 7 | `__ZN25IOSkywalkPacketBufferPool12initWithNameEPKcPvjPKNS_11PoolOptionsE` | `asm/ZN25IOSkywalkPacketBufferPool12initWithNameEPKcPvjPKNS_11PoolOptionsE.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297cc58` | 263 | `__ZN25IOSkywalkPacketBufferPool12initWithNameEPKcP8OSObjectjPKNS_11PoolOptionsE` | `asm/ZN25IOSkywalkPacketBufferPool12initWithNameEPKcP8OSObjectjPKNS_11PoolOptionsE.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297d0c6` | 58 | `__ZN25IOSkywalkPacketBufferPool27reportingChangeNotificationEv` | `asm/ZN25IOSkywalkPacketBufferPool27reportingChangeNotificationEv.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297d17c` | 51 | `__ZN25IOSkywalkPacketBufferPool18segmentConstructorEP13kern_pbufpoolP9sksegmentP18IOMemoryDescriptor` | `asm/ZN25IOSkywalkPacketBufferPool18segmentConstructorEP13kern_pbufpoolP9sksegmentP18IOMemoryDescriptor.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297d20e` | 31 | `__ZN25IOSkywalkPacketBufferPool17segmentDestructorEP13kern_pbufpoolP9sksegmentP18IOMemoryDescriptor` | `asm/ZN25IOSkywalkPacketBufferPool17segmentDestructorEP13kern_pbufpoolP9sksegmentP18IOMemoryDescriptor.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297d276` | 26 | `__ZNK25IOSkywalkPacketBufferPool7releaseEv` | `asm/ZNK25IOSkywalkPacketBufferPool7releaseEv.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297d2ca` | 46 | `__ZN25IOSkywalkPacketBufferPool17disposeAllPacketsEv` | `asm/ZN25IOSkywalkPacketBufferPool17disposeAllPacketsEv.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297d366` | 22 | `__ZN25IOSkywalkPacketBufferPool17disposeAllBuffersEv` | `asm/ZN25IOSkywalkPacketBufferPool17disposeAllBuffersEv.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297d3bc` | 57 | `__ZN25IOSkywalkPacketBufferPool4freeEv` | `asm/ZN25IOSkywalkPacketBufferPool4freeEv.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297d4c0` | 27 | `__ZN25IOSkywalkPacketBufferPool17releaseAllPacketsEv` | `asm/ZN25IOSkywalkPacketBufferPool17releaseAllPacketsEv.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297d518` | 19 | `__ZN25IOSkywalkPacketBufferPool24releaseAllMemorySegmentsEv` | `asm/ZN25IOSkywalkPacketBufferPool24releaseAllMemorySegmentsEv.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297d556` | 18 | `__ZNK25IOSkywalkPacketBufferPool11getPoolNameEv` | `asm/ZNK25IOSkywalkPacketBufferPool11getPoolNameEv.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297d592` | 15 | `__ZN25IOSkywalkPacketBufferPool19acquireKernelPacketEy` | `asm/ZN25IOSkywalkPacketBufferPool19acquireKernelPacketEy.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297d5b6` | 44 | `__ZN25IOSkywalkPacketBufferPool21allocateKernelPacketsEjPyPjj` | `asm/ZN25IOSkywalkPacketBufferPool21allocateKernelPacketsEjPyPjj.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297d626` | 18 | `__ZN25IOSkywalkPacketBufferPool16freeKernelPacketEy` | `asm/ZN25IOSkywalkPacketBufferPool16freeKernelPacketEy.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297d65a` | 14 | `__ZN25IOSkywalkPacketBufferPool19disposeKernelPacketEy` | `asm/ZN25IOSkywalkPacketBufferPool19disposeKernelPacketEy.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297d680` | 35 | `__ZN25IOSkywalkPacketBufferPool17freeKernelPacketsEPyj` | `asm/ZN25IOSkywalkPacketBufferPool17freeKernelPacketsEPyj.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297d6dc` | 11 | `__ZNK25IOSkywalkPacketBufferPool24getKernelPacketWithIndexEj` | `asm/ZNK25IOSkywalkPacketBufferPool24getKernelPacketWithIndexEj.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297d6f4` | 7 | `__ZN25IOSkywalkPacketBufferPool28disposeKernelPacketWithIndexEyj` | `asm/ZN25IOSkywalkPacketBufferPool28disposeKernelPacketWithIndexEyj.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297d708` | 7 | `__ZN25IOSkywalkPacketBufferPool28acquireKernelPacketWithIndexEyj` | `asm/ZN25IOSkywalkPacketBufferPool28acquireKernelPacketWithIndexEyj.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297d718` | 16 | `__ZNK25IOSkywalkPacketBufferPool26getMemorySegmentWithHandleEP9sksegment` | `asm/ZNK25IOSkywalkPacketBufferPool26getMemorySegmentWithHandleEP9sksegment.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297d742` | 28 | `__ZN25IOSkywalkPacketBufferPool9newPacketEP25IOSkywalkPacketDescriptorPP15IOSkywalkPacket` | `asm/ZN25IOSkywalkPacketBufferPool9newPacketEP25IOSkywalkPacketDescriptorPP15IOSkywalkPacket.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297d78c` | 16 | `__ZN25IOSkywalkPacketBufferPool15newPacketBufferEP31IOSkywalkPacketBufferDescriptorPP21IOSkywalkPacketBuffer` | `asm/ZN25IOSkywalkPacketBufferPool15newPacketBufferEP31IOSkywalkPacketBufferDescriptorPP21IOSkywalkPacketBuffer.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297d7b4` | 16 | `__ZN25IOSkywalkPacketBufferPool16newMemorySegmentEP32IOSkywalkMemorySegmentDescriptorPP22IOSkywalkMemorySegment` | `asm/ZN25IOSkywalkPacketBufferPool16newMemorySegmentEP32IOSkywalkMemorySegmentDescriptorPP22IOSkywalkMemorySegment.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297d7dc` | 16 | `__ZNK25IOSkywalkPacketBufferPool19getPacketWithHandleEy` | `asm/ZNK25IOSkywalkPacketBufferPool19getPacketWithHandleEy.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297d806` | 17 | `__ZNK25IOSkywalkPacketBufferPool18getPacketWithIndexEj` | `asm/ZNK25IOSkywalkPacketBufferPool18getPacketWithIndexEj.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297d82e` | 10 | `__ZN25IOSkywalkPacketBufferPool14allocatePacketEPP15IOSkywalkPacketj` | `asm/ZN25IOSkywalkPacketBufferPool14allocatePacketEPP15IOSkywalkPacketj.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297d84a` | 38 | `__ZN25IOSkywalkPacketBufferPool22completePreparedPacketEP15IOSkywalkPacket` | `asm/ZN25IOSkywalkPacketBufferPool22completePreparedPacketEP15IOSkywalkPacket.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297d8ae` | 29 | `__ZN25IOSkywalkPacketBufferPool20deallocatePacketListEP15IOSkywalkPacket` | `asm/ZN25IOSkywalkPacketBufferPool20deallocatePacketListEP15IOSkywalkPacket.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297da3c` | 46 | `__ZN25IOSkywalkPacketBufferPool18checkInPacketQueueEPK20IOSkywalkPacketQueue` | `asm/ZN25IOSkywalkPacketBufferPool18checkInPacketQueueEPK20IOSkywalkPacketQueue.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297dad0` | 63 | `__ZN25IOSkywalkPacketBufferPool19checkOutPacketQueueEPK20IOSkywalkPacketQueue` | `asm/ZN25IOSkywalkPacketBufferPool19checkOutPacketQueueEPK20IOSkywalkPacketQueue.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297dbb6` | 36 | `__ZN25IOSkywalkPacketBufferPool23checkInReportingServiceEP9IOServicePK18IOSkywalkInterface` | `asm/ZN25IOSkywalkPacketBufferPool23checkInReportingServiceEP9IOServicePK18IOSkywalkInterface.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297dc2e` | 67 | `__ZN25IOSkywalkPacketBufferPool25createReportersForServiceEP9IOServicePK18IOSkywalkInterface` | `asm/ZN25IOSkywalkPacketBufferPool25createReportersForServiceEP9IOServicePK18IOSkywalkInterface.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297dd18` | 22 | `__ZN25IOSkywalkPacketBufferPool24checkOutReportingServiceEPK9IOService` | `asm/ZN25IOSkywalkPacketBufferPool24checkOutReportingServiceEPK9IOService.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297dd64` | 48 | `__ZN25IOSkywalkPacketBufferPool25removeReportersForServiceEPK9IOService` | `asm/ZN25IOSkywalkPacketBufferPool25removeReportersForServiceEPK9IOService.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297ddf2` | 69 | `__ZN25IOSkywalkPacketBufferPool15addPoolReporterEP9IOServiceP5OSSet` | `asm/ZN25IOSkywalkPacketBufferPool15addPoolReporterEP9IOServiceP5OSSet.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297ded4` | 56 | `__ZN25IOSkywalkPacketBufferPool23copyReportersForServiceEPK9IOService` | `asm/ZN25IOSkywalkPacketBufferPool23copyReportersForServiceEPK9IOService.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297df90` | 62 | `__ZN25IOSkywalkPacketBufferPool21getReportChannelValueEy` | `asm/ZN25IOSkywalkPacketBufferPool21getReportChannelValueEy.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff800297e038` | 4 | `__ZN25IOSkywalkPacketBufferPool9MetaClassD0Ev` | `asm/ZN25IOSkywalkPacketBufferPool9MetaClassD0Ev.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff80029a1aca` | 33 | `__ZN25IOSkywalkPacketBufferPool20allocateKernelPacketEjPyj` | `asm/ZN25IOSkywalkPacketBufferPool20allocateKernelPacketEjPyj.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff80029a1b1c` | 122 | `__ZN25IOSkywalkPacketBufferPool20createSegmentBuffersEP22IOSkywalkMemorySegmentjb` | `asm/ZN25IOSkywalkPacketBufferPool20createSegmentBuffersEP22IOSkywalkMemorySegmentjb.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff80029a1cb2` | 16 | `__ZN25IOSkywalkPacketBufferPool21destroySegmentBuffersEP22IOSkywalkMemorySegment` | `asm/ZN25IOSkywalkPacketBufferPool21destroySegmentBuffersEP22IOSkywalkMemorySegment.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff80029a1cda` | 73 | `__ZN25IOSkywalkPacketBufferPool20prepareMemorySegmentEP22IOSkywalkMemorySegmentP24IOBufferMemoryDescriptory` | `asm/ZN25IOSkywalkPacketBufferPool20prepareMemorySegmentEP22IOSkywalkMemorySegmentP24IOBufferMemoryDescriptory.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff80029a1dc8` | 31 | `__ZNK25IOSkywalkPacketBufferPool31getPacketBufferWithBufletHandleEP13__kern_buflet` | `asm/ZNK25IOSkywalkPacketBufferPool31getPacketBufferWithBufletHandleEP13__kern_buflet.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff80029a1e20` | 28 | `__ZNK25IOSkywalkPacketBufferPool30getPacketBufferWithSegmentInfoEP9sksegmentj` | `asm/ZNK25IOSkywalkPacketBufferPool30getPacketBufferWithSegmentInfoEP9sksegmentj.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff80029a1e66` | 55 | `__ZN25IOSkywalkPacketBufferPool14allocatePacketEjPP15IOSkywalkPacketj` | `asm/ZN25IOSkywalkPacketBufferPool14allocatePacketEjPP15IOSkywalkPacketj.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff80029a1f10` | 108 | `__ZN25IOSkywalkPacketBufferPool15allocatePacketsEjPjPP15IOSkywalkPacketj` | `asm/ZN25IOSkywalkPacketBufferPool15allocatePacketsEjPjPP15IOSkywalkPacketj.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff80029a2072` | 28 | `__ZN25IOSkywalkPacketBufferPool16deallocatePacketEP15IOSkywalkPacket` | `asm/ZN25IOSkywalkPacketBufferPool16deallocatePacketEP15IOSkywalkPacket.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff80029a20be` | 53 | `__ZN25IOSkywalkPacketBufferPool17deallocatePacketsEPP15IOSkywalkPacketj` | `asm/ZN25IOSkywalkPacketBufferPool17deallocatePacketsEPP15IOSkywalkPacketj.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff80029a214a` | 10 | `__ZN25IOSkywalkPacketBufferPool21deallocatePacketChainEy` | `asm/ZN25IOSkywalkPacketBufferPool21deallocatePacketChainEy.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff80029a2160` | 49 | `__ZN25IOSkywalkPacketBufferPool20allocatePacketBufferEPP21IOSkywalkPacketBufferj` | `asm/ZN25IOSkywalkPacketBufferPool20allocatePacketBufferEPP21IOSkywalkPacketBufferj.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff80029a21fe` | 48 | `__ZN25IOSkywalkPacketBufferPool21allocatePacketBuffersEPjPP21IOSkywalkPacketBufferj` | `asm/ZN25IOSkywalkPacketBufferPool21allocatePacketBuffersEPjPP21IOSkywalkPacketBufferj.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff80029a2278` | 32 | `__ZN25IOSkywalkPacketBufferPool22deallocatePacketBufferEP21IOSkywalkPacketBuffer` | `asm/ZN25IOSkywalkPacketBufferPool22deallocatePacketBufferEP21IOSkywalkPacketBuffer.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff80029a22d0` | 28 | `__ZN25IOSkywalkPacketBufferPool23deallocatePacketBuffersEPP21IOSkywalkPacketBufferj` | `asm/ZN25IOSkywalkPacketBufferPool23deallocatePacketBuffersEPP21IOSkywalkPacketBufferj.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff80029a2316` | 25 | `__ZN25IOSkywalkPacketBufferPool17segmentDestructorEP13kern_pbufpoolP9sksegmentP18IOMemoryDescriptor.cold.1` | `asm/ZN25IOSkywalkPacketBufferPool17segmentDestructorEP13kern_pbufpoolP9sksegmentP18IOMemoryDescriptor.cold.1.asm.txt` |
| `IOSkywalkPacketBufferPool` | `0xffffff80029a235f` | 15 | `__ZN25IOSkywalkPacketBufferPool9newPacketEP25IOSkywalkPacketDescriptorPP15IOSkywalkPacket.cold.1` | `asm/ZN25IOSkywalkPacketBufferPool9newPacketEP25IOSkywalkPacketDescriptorPP15IOSkywalkPacket.cold.1.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297e876` | 15 | `__ZN21IOSkywalkPacketBuffer9MetaClassC1Ev` | `asm/ZN21IOSkywalkPacketBuffer9MetaClassC1Ev.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297e8a8` | 4 | `__ZN21IOSkywalkPacketBuffer9MetaClassD1Ev` | `asm/ZN21IOSkywalkPacketBuffer9MetaClassD1Ev.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297e8b2` | 13 | `__ZN21IOSkywalkPacketBufferC2EPK11OSMetaClass` | `asm/ZN21IOSkywalkPacketBufferC2EPK11OSMetaClass.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297e8d2` | 13 | `__ZN21IOSkywalkPacketBufferC1EPK11OSMetaClass` | `asm/ZN21IOSkywalkPacketBufferC1EPK11OSMetaClass.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297e8f2` | 4 | `__ZN21IOSkywalkPacketBufferD2Ev` | `asm/ZN21IOSkywalkPacketBufferD2Ev.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297e8fc` | 4 | `__ZN21IOSkywalkPacketBufferD1Ev` | `asm/ZN21IOSkywalkPacketBufferD1Ev.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297e906` | 13 | `__ZN21IOSkywalkPacketBufferD0Ev` | `asm/ZN21IOSkywalkPacketBufferD0Ev.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297e92e` | 8 | `__ZN21IOSkywalkPacketBufferdlEPvm` | `asm/ZN21IOSkywalkPacketBufferdlEPvm.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297e946` | 6 | `__ZNK21IOSkywalkPacketBuffer12getMetaClassEv` | `asm/ZNK21IOSkywalkPacketBuffer12getMetaClassEv.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297e954` | 15 | `__ZN21IOSkywalkPacketBuffer9MetaClassC2Ev` | `asm/ZN21IOSkywalkPacketBuffer9MetaClassC2Ev.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297e986` | 22 | `__ZNK21IOSkywalkPacketBuffer9MetaClass5allocEv` | `asm/ZNK21IOSkywalkPacketBuffer9MetaClass5allocEv.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297e9ce` | 6 | `__ZN21IOSkywalkPacketBuffernwEm` | `asm/ZN21IOSkywalkPacketBuffernwEm.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297e9e2` | 16 | `__ZN21IOSkywalkPacketBufferC1Ev` | `asm/ZN21IOSkywalkPacketBufferC1Ev.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297ea12` | 16 | `__ZN21IOSkywalkPacketBufferC2Ev` | `asm/ZN21IOSkywalkPacketBufferC2Ev.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297ea42` | 45 | `__ZN21IOSkywalkPacketBuffer8withPoolEP25IOSkywalkPacketBufferPoolP31IOSkywalkPacketBufferDescriptorj` | `asm/ZN21IOSkywalkPacketBuffer8withPoolEP25IOSkywalkPacketBufferPoolP31IOSkywalkPacketBufferDescriptorj.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297eac8` | 48 | `__ZN21IOSkywalkPacketBuffer12initWithPoolEP25IOSkywalkPacketBufferPoolP31IOSkywalkPacketBufferDescriptorj` | `asm/ZN21IOSkywalkPacketBuffer12initWithPoolEP25IOSkywalkPacketBufferPoolP31IOSkywalkPacketBufferDescriptorj.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297eb56` | 25 | `__ZN21IOSkywalkPacketBuffer4freeEv` | `asm/ZN21IOSkywalkPacketBuffer4freeEv.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297ebac` | 5 | `__ZNK21IOSkywalkPacketBuffer19getPacketBufferPoolEv` | `asm/ZNK21IOSkywalkPacketBuffer19getPacketBufferPoolEv.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297ebb6` | 5 | `__ZNK21IOSkywalkPacketBuffer9getPacketEv` | `asm/ZNK21IOSkywalkPacketBuffer9getPacketEv.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297ebc0` | 7 | `__ZNK21IOSkywalkPacketBuffer13getBufferSizeEv` | `asm/ZNK21IOSkywalkPacketBuffer13getBufferSizeEv.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297ebce` | 6 | `__ZNK21IOSkywalkPacketBuffer13getDataLengthEv` | `asm/ZNK21IOSkywalkPacketBuffer13getDataLengthEv.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297ebd8` | 6 | `__ZNK21IOSkywalkPacketBuffer13getDataOffsetEv` | `asm/ZNK21IOSkywalkPacketBuffer13getDataOffsetEv.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297ebe6` | 5 | `__ZNK21IOSkywalkPacketBuffer10getDataOffEv` | `asm/ZNK21IOSkywalkPacketBuffer10getDataOffEv.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297ebf2` | 5 | `__ZNK21IOSkywalkPacketBuffer16getMemorySegmentEv` | `asm/ZNK21IOSkywalkPacketBuffer16getMemorySegmentEv.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297ebfc` | 5 | `__ZNK21IOSkywalkPacketBuffer22getMemorySegmentOffsetEv` | `asm/ZNK21IOSkywalkPacketBuffer22getMemorySegmentOffsetEv.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297ec06` | 5 | `__ZNK21IOSkywalkPacketBuffer15getBufletHandleEv` | `asm/ZNK21IOSkywalkPacketBuffer15getBufletHandleEv.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297ec10` | 5 | `__ZN21IOSkywalkPacketBuffer15setBufletHandleEP13__kern_buflet` | `asm/ZN21IOSkywalkPacketBuffer15setBufletHandleEP13__kern_buflet.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297ec1a` | 5 | `__ZNK21IOSkywalkPacketBuffer15getBufferHandleEv` | `asm/ZNK21IOSkywalkPacketBuffer15getBufferHandleEv.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297ec24` | 5 | `__ZN21IOSkywalkPacketBuffer7prepareEj` | `asm/ZN21IOSkywalkPacketBuffer7prepareEj.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297ec2c` | 5 | `__ZN21IOSkywalkPacketBuffer8completeEj` | `asm/ZN21IOSkywalkPacketBuffer8completeEj.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297ec34` | 8 | `__ZN21IOSkywalkPacketBuffer24prepareWithMemorySegmentEP22IOSkywalkMemorySegmentyj` | `asm/ZN21IOSkywalkPacketBuffer24prepareWithMemorySegmentEP22IOSkywalkMemorySegmentyj.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297ec48` | 8 | `__ZN21IOSkywalkPacketBuffer25completeWithMemorySegmentEP22IOSkywalkMemorySegmentyj` | `asm/ZN21IOSkywalkPacketBuffer25completeWithMemorySegmentEP22IOSkywalkMemorySegmentyj.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297ec5c` | 5 | `__ZNK21IOSkywalkPacketBuffer14getSourceQueueEv` | `asm/ZNK21IOSkywalkPacketBuffer14getSourceQueueEv.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297ec66` | 51 | `__ZN21IOSkywalkPacketBuffer16prepareWithQueueEP20IOSkywalkPacketQueuejj` | `asm/ZN21IOSkywalkPacketBuffer16prepareWithQueueEP20IOSkywalkPacketQueuejj.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297ed00` | 27 | `__ZN21IOSkywalkPacketBuffer17completeWithQueueEP20IOSkywalkPacketQueuejj` | `asm/ZN21IOSkywalkPacketBuffer17completeWithQueueEP20IOSkywalkPacketQueuejj.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297ed48` | 18 | `__ZN21IOSkywalkPacketBuffer8finalizeEv` | `asm/ZN21IOSkywalkPacketBuffer8finalizeEv.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297ed7a` | 5 | `__ZN21IOSkywalkPacketBuffer9setPacketEP15IOSkywalkPacketj` | `asm/ZN21IOSkywalkPacketBuffer9setPacketEP15IOSkywalkPacketj.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297ed84` | 6 | `__ZN21IOSkywalkPacketBuffer23acquireWithBufletHandleEP13__kern_buflet` | `asm/ZN21IOSkywalkPacketBuffer23acquireWithBufletHandleEP13__kern_buflet.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297ed94` | 6 | `__ZN21IOSkywalkPacketBuffer23acquireWithBufferHandleEy` | `asm/ZN21IOSkywalkPacketBuffer23acquireWithBufferHandleEy.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297eda4` | 10 | `__ZN21IOSkywalkPacketBuffer19disposePacketBufferEv` | `asm/ZN21IOSkywalkPacketBuffer19disposePacketBufferEv.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297edc2` | 5 | `__ZN21IOSkywalkPacketBuffer24cancelCompletionCallbackEv` | `asm/ZN21IOSkywalkPacketBuffer24cancelCompletionCallbackEv.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff800297edd0` | 4 | `__ZN21IOSkywalkPacketBuffer9MetaClassD0Ev` | `asm/ZN21IOSkywalkPacketBuffer9MetaClassD0Ev.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff80029a259a` | 14 | `__ZN21IOSkywalkPacketBuffer13setDataLengthEj` | `asm/ZN21IOSkywalkPacketBuffer13setDataLengthEj.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff80029a25be` | 14 | `__ZN21IOSkywalkPacketBuffer13setDataOffsetEt` | `asm/ZN21IOSkywalkPacketBuffer13setDataOffsetEt.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff80029a25e2` | 19 | `__ZN21IOSkywalkPacketBuffer10setDataOffEx` | `asm/ZN21IOSkywalkPacketBuffer10setDataOffEx.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff80029a2616` | 14 | `__ZN21IOSkywalkPacketBuffer22setDataOffsetAndLengthEtj` | `asm/ZN21IOSkywalkPacketBuffer22setDataOffsetAndLengthEtj.asm.txt` |
| `IOSkywalkPacketBuffer` | `0xffffff80029a263c` | 27 | `__ZN21IOSkywalkPacketBuffer16setDataOffAndLenExm` | `asm/ZN21IOSkywalkPacketBuffer16setDataOffAndLenExm.asm.txt` |
| `IOSkywalkMemorySegment` | `0xffffff8002986f2e` | 15 | `__ZN22IOSkywalkMemorySegment9MetaClassC1Ev` | `asm/ZN22IOSkywalkMemorySegment9MetaClassC1Ev.asm.txt` |
| `IOSkywalkMemorySegment` | `0xffffff8002986f60` | 4 | `__ZN22IOSkywalkMemorySegment9MetaClassD1Ev` | `asm/ZN22IOSkywalkMemorySegment9MetaClassD1Ev.asm.txt` |
| `IOSkywalkMemorySegment` | `0xffffff8002986f6a` | 13 | `__ZN22IOSkywalkMemorySegmentC2EPK11OSMetaClass` | `asm/ZN22IOSkywalkMemorySegmentC2EPK11OSMetaClass.asm.txt` |
| `IOSkywalkMemorySegment` | `0xffffff8002986f8a` | 13 | `__ZN22IOSkywalkMemorySegmentC1EPK11OSMetaClass` | `asm/ZN22IOSkywalkMemorySegmentC1EPK11OSMetaClass.asm.txt` |
| `IOSkywalkMemorySegment` | `0xffffff8002986faa` | 4 | `__ZN22IOSkywalkMemorySegmentD2Ev` | `asm/ZN22IOSkywalkMemorySegmentD2Ev.asm.txt` |
| `IOSkywalkMemorySegment` | `0xffffff8002986fb4` | 4 | `__ZN22IOSkywalkMemorySegmentD1Ev` | `asm/ZN22IOSkywalkMemorySegmentD1Ev.asm.txt` |
| `IOSkywalkMemorySegment` | `0xffffff8002986fbe` | 13 | `__ZN22IOSkywalkMemorySegmentD0Ev` | `asm/ZN22IOSkywalkMemorySegmentD0Ev.asm.txt` |
| `IOSkywalkMemorySegment` | `0xffffff8002986fe6` | 8 | `__ZN22IOSkywalkMemorySegmentdlEPvm` | `asm/ZN22IOSkywalkMemorySegmentdlEPvm.asm.txt` |
| `IOSkywalkMemorySegment` | `0xffffff8002986ffe` | 6 | `__ZNK22IOSkywalkMemorySegment12getMetaClassEv` | `asm/ZNK22IOSkywalkMemorySegment12getMetaClassEv.asm.txt` |
| `IOSkywalkMemorySegment` | `0xffffff800298700c` | 15 | `__ZN22IOSkywalkMemorySegment9MetaClassC2Ev` | `asm/ZN22IOSkywalkMemorySegment9MetaClassC2Ev.asm.txt` |
| `IOSkywalkMemorySegment` | `0xffffff800298703e` | 22 | `__ZNK22IOSkywalkMemorySegment9MetaClass5allocEv` | `asm/ZNK22IOSkywalkMemorySegment9MetaClass5allocEv.asm.txt` |
| `IOSkywalkMemorySegment` | `0xffffff8002987086` | 6 | `__ZN22IOSkywalkMemorySegmentnwEm` | `asm/ZN22IOSkywalkMemorySegmentnwEm.asm.txt` |
| `IOSkywalkMemorySegment` | `0xffffff800298709a` | 16 | `__ZN22IOSkywalkMemorySegmentC1Ev` | `asm/ZN22IOSkywalkMemorySegmentC1Ev.asm.txt` |
| `IOSkywalkMemorySegment` | `0xffffff80029870ca` | 16 | `__ZN22IOSkywalkMemorySegmentC2Ev` | `asm/ZN22IOSkywalkMemorySegmentC2Ev.asm.txt` |
| `IOSkywalkMemorySegment` | `0xffffff80029870fa` | 45 | `__ZN22IOSkywalkMemorySegment8withPoolEP25IOSkywalkPacketBufferPoolP32IOSkywalkMemorySegmentDescriptorj` | `asm/ZN22IOSkywalkMemorySegment8withPoolEP25IOSkywalkPacketBufferPoolP32IOSkywalkMemorySegmentDescriptorj.asm.txt` |
| `IOSkywalkMemorySegment` | `0xffffff8002987180` | 57 | `__ZN22IOSkywalkMemorySegment12initWithPoolEP25IOSkywalkPacketBufferPoolP32IOSkywalkMemorySegmentDescriptorj` | `asm/ZN22IOSkywalkMemorySegment12initWithPoolEP25IOSkywalkPacketBufferPoolP32IOSkywalkMemorySegmentDescriptorj.asm.txt` |
| `IOSkywalkMemorySegment` | `0xffffff800298722a` | 39 | `__ZN22IOSkywalkMemorySegment4freeEv` | `asm/ZN22IOSkywalkMemorySegment4freeEv.asm.txt` |
| `IOSkywalkMemorySegment` | `0xffffff80029872b0` | 5 | `__ZNK22IOSkywalkMemorySegment19getPacketBufferPoolEv` | `asm/ZNK22IOSkywalkMemorySegment19getPacketBufferPoolEv.asm.txt` |
| `IOSkywalkMemorySegment` | `0xffffff80029872ba` | 5 | `__ZNK22IOSkywalkMemorySegment19getMemoryDescriptorEv` | `asm/ZNK22IOSkywalkMemorySegment19getMemoryDescriptorEv.asm.txt` |
| `IOSkywalkMemorySegment` | `0xffffff80029872c4` | 38 | `__ZN22IOSkywalkMemorySegment19setMemoryDescriptorEP18IOMemoryDescriptory` | `asm/ZN22IOSkywalkMemorySegment19setMemoryDescriptorEP18IOMemoryDescriptory.asm.txt` |
| `IOSkywalkMemorySegment` | `0xffffff800298732e` | 5 | `__ZNK22IOSkywalkMemorySegment17getVirtualAddressEv` | `asm/ZNK22IOSkywalkMemorySegment17getVirtualAddressEv.asm.txt` |
| `IOSkywalkMemorySegment` | `0xffffff8002987338` | 5 | `__ZN22IOSkywalkMemorySegment19getIOVirtualAddressEv` | `asm/ZN22IOSkywalkMemorySegment19getIOVirtualAddressEv.asm.txt` |
| `IOSkywalkMemorySegment` | `0xffffff8002987342` | 5 | `__ZN22IOSkywalkMemorySegment25setBufferMemoryDescriptorEP24IOBufferMemoryDescriptor` | `asm/ZN22IOSkywalkMemorySegment25setBufferMemoryDescriptorEP24IOBufferMemoryDescriptor.asm.txt` |
| `IOSkywalkMemorySegment` | `0xffffff800298734a` | 18 | `__ZN22IOSkywalkMemorySegment13setDMACommandEP12IODMACommandj` | `asm/ZN22IOSkywalkMemorySegment13setDMACommandEP12IODMACommandj.asm.txt` |
| `IOSkywalkMemorySegment` | `0xffffff8002987378` | 5 | `__ZNK22IOSkywalkMemorySegment13getDMACommandEv` | `asm/ZNK22IOSkywalkMemorySegment13getDMACommandEv.asm.txt` |
| `IOSkywalkMemorySegment` | `0xffffff8002987382` | 138 | `__ZN22IOSkywalkMemorySegment7prepareEj` | `asm/ZN22IOSkywalkMemorySegment7prepareEj.asm.txt` |
| `IOSkywalkMemorySegment` | `0xffffff8002987574` | 52 | `__ZN22IOSkywalkMemorySegment8completeEj` | `asm/ZN22IOSkywalkMemorySegment8completeEj.asm.txt` |
| `IOSkywalkMemorySegment` | `0xffffff8002987622` | 4 | `__ZN22IOSkywalkMemorySegment9MetaClassD0Ev` | `asm/ZN22IOSkywalkMemorySegment9MetaClassD0Ev.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e086` | 15 | `__ZN15IOSkywalkPacket9MetaClassC1Ev` | `asm/ZN15IOSkywalkPacket9MetaClassC1Ev.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e0b8` | 4 | `__ZN15IOSkywalkPacket9MetaClassD1Ev` | `asm/ZN15IOSkywalkPacket9MetaClassD1Ev.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e0c2` | 13 | `__ZN15IOSkywalkPacketC2EPK11OSMetaClass` | `asm/ZN15IOSkywalkPacketC2EPK11OSMetaClass.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e0e2` | 13 | `__ZN15IOSkywalkPacketC1EPK11OSMetaClass` | `asm/ZN15IOSkywalkPacketC1EPK11OSMetaClass.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e102` | 4 | `__ZN15IOSkywalkPacketD2Ev` | `asm/ZN15IOSkywalkPacketD2Ev.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e10c` | 4 | `__ZN15IOSkywalkPacketD1Ev` | `asm/ZN15IOSkywalkPacketD1Ev.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e116` | 13 | `__ZN15IOSkywalkPacketD0Ev` | `asm/ZN15IOSkywalkPacketD0Ev.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e13e` | 8 | `__ZN15IOSkywalkPacketdlEPvm` | `asm/ZN15IOSkywalkPacketdlEPvm.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e156` | 6 | `__ZNK15IOSkywalkPacket12getMetaClassEv` | `asm/ZNK15IOSkywalkPacket12getMetaClassEv.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e164` | 15 | `__ZN15IOSkywalkPacket9MetaClassC2Ev` | `asm/ZN15IOSkywalkPacket9MetaClassC2Ev.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e196` | 22 | `__ZNK15IOSkywalkPacket9MetaClass5allocEv` | `asm/ZNK15IOSkywalkPacket9MetaClass5allocEv.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e1de` | 6 | `__ZN15IOSkywalkPacketnwEm` | `asm/ZN15IOSkywalkPacketnwEm.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e1f2` | 16 | `__ZN15IOSkywalkPacketC1Ev` | `asm/ZN15IOSkywalkPacketC1Ev.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e222` | 16 | `__ZN15IOSkywalkPacketC2Ev` | `asm/ZN15IOSkywalkPacketC2Ev.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e252` | 45 | `__ZN15IOSkywalkPacket8withPoolEP25IOSkywalkPacketBufferPoolP25IOSkywalkPacketDescriptorj` | `asm/ZN15IOSkywalkPacket8withPoolEP25IOSkywalkPacketBufferPoolP25IOSkywalkPacketDescriptorj.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e2d8` | 52 | `__ZN15IOSkywalkPacket12initWithPoolEP25IOSkywalkPacketBufferPoolP25IOSkywalkPacketDescriptorj` | `asm/ZN15IOSkywalkPacket12initWithPoolEP25IOSkywalkPacketBufferPoolP25IOSkywalkPacketDescriptorj.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e376` | 23 | `__ZN15IOSkywalkPacket4freeEv` | `asm/ZN15IOSkywalkPacket4freeEv.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e3c6` | 5 | `__ZNK15IOSkywalkPacket19getPacketBufferPoolEv` | `asm/ZNK15IOSkywalkPacket19getPacketBufferPoolEv.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e3d0` | 7 | `__ZNK15IOSkywalkPacket13getBufferSizeEv` | `asm/ZNK15IOSkywalkPacket13getBufferSizeEv.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e3de` | 6 | `__ZNK15IOSkywalkPacket20getPacketBufferCountEv` | `asm/ZNK15IOSkywalkPacket20getPacketBufferCountEv.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e3e8` | 29 | `__ZNK15IOSkywalkPacket13getDataLengthEv` | `asm/ZNK15IOSkywalkPacket13getDataLengthEv.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e430` | 19 | `__ZNK15IOSkywalkPacket21getDataVirtualAddressEv` | `asm/ZNK15IOSkywalkPacket21getDataVirtualAddressEv.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e462` | 20 | `__ZNK15IOSkywalkPacket23getDataIOVirtualAddressEv` | `asm/ZNK15IOSkywalkPacket23getDataIOVirtualAddressEv.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e498` | 5 | `__ZNK15IOSkywalkPacket14getSourceQueueEv` | `asm/ZNK15IOSkywalkPacket14getSourceQueueEv.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e4a2` | 31 | `__ZN15IOSkywalkPacket7prepareEP20IOSkywalkPacketQueueyj` | `asm/ZN15IOSkywalkPacket7prepareEP20IOSkywalkPacketQueueyj.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e4ee` | 67 | `__ZN15IOSkywalkPacket16prepareWithQueueEP20IOSkywalkPacketQueuejj` | `asm/ZN15IOSkywalkPacket16prepareWithQueueEP20IOSkywalkPacketQueuejj.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e5c6` | 31 | `__ZN15IOSkywalkPacket8completeEP20IOSkywalkPacketQueuej` | `asm/ZN15IOSkywalkPacket8completeEP20IOSkywalkPacketQueuej.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e612` | 53 | `__ZN15IOSkywalkPacket17completeWithQueueEP20IOSkywalkPacketQueuejj` | `asm/ZN15IOSkywalkPacket17completeWithQueueEP20IOSkywalkPacketQueuejj.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e6aa` | 23 | `__ZN15IOSkywalkPacket8finalizeEv` | `asm/ZN15IOSkywalkPacket8finalizeEv.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e6e6` | 16 | `__ZNK15IOSkywalkPacket16generateTraceTagEP20IOSkywalkPacketQueue` | `asm/ZNK15IOSkywalkPacket16generateTraceTagEP20IOSkywalkPacketQueue.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e70c` | 5 | `__ZNK15IOSkywalkPacket11getTraceTagEv` | `asm/ZNK15IOSkywalkPacket11getTraceTagEv.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e71a` | 5 | `__ZNK15IOSkywalkPacket11setTraceTagEt` | `asm/ZNK15IOSkywalkPacket11setTraceTagEt.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e728` | 17 | `__ZN15IOSkywalkPacket14getAppMetadataEP26packet_app_metadata_type_tPh` | `asm/ZN15IOSkywalkPacket14getAppMetadataEP26packet_app_metadata_type_tPh.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e758` | 8 | `__ZN15IOSkywalkPacket23acquireWithPacketHandleEyj` | `asm/ZN15IOSkywalkPacket23acquireWithPacketHandleEyj.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e76c` | 29 | `__ZN15IOSkywalkPacket13disposePacketEv` | `asm/ZN15IOSkywalkPacket13disposePacketEv.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e7c2` | 6 | `__ZN15IOSkywalkPacket20setTransferDirectionEj` | `asm/ZN15IOSkywalkPacket20setTransferDirectionEj.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e7cc` | 6 | `__ZNK15IOSkywalkPacket20getTransferDirectionEv` | `asm/ZNK15IOSkywalkPacket20getTransferDirectionEv.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e7d6` | 6 | `__ZN15IOSkywalkPacket22clearTransferDirectionEv` | `asm/ZN15IOSkywalkPacket22clearTransferDirectionEv.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e7e4` | 5 | `__ZNK15IOSkywalkPacket13getPacketTypeEv` | `asm/ZNK15IOSkywalkPacket13getPacketTypeEv.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e7ec` | 5 | `__ZN15IOSkywalkPacket24cancelCompletionCallbackEv` | `asm/ZN15IOSkywalkPacket24cancelCompletionCallbackEv.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e7fa` | 5 | `__ZN15IOSkywalkPacket13setNextPacketEPS_` | `asm/ZN15IOSkywalkPacket13setNextPacketEPS_.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e804` | 5 | `__ZN15IOSkywalkPacket13getNextPacketEv` | `asm/ZN15IOSkywalkPacket13getNextPacketEv.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e80e` | 4 | `__ZN15IOSkywalkPacket9MetaClassD0Ev` | `asm/ZN15IOSkywalkPacket9MetaClassD0Ev.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e818` | 4 | `__ZN15IOSkywalkPacket11setWakeFlagEv` | `asm/ZN15IOSkywalkPacket11setWakeFlagEv.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e81e` | 5 | `__ZNK15IOSkywalkPacket10getTraceIDEv` | `asm/ZNK15IOSkywalkPacket10getTraceIDEv.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e826` | 4 | `__ZN15IOSkywalkPacket10setTraceIDEj` | `asm/ZN15IOSkywalkPacket10setTraceIDEj.asm.txt` |
| `IOSkywalkPacket` | `0xffffff800297e82c` | 4 | `__ZN15IOSkywalkPacket10traceEventEj` | `asm/ZN15IOSkywalkPacket10traceEventEj.asm.txt` |
| `IOSkywalkPacket` | `0xffffff80029a2398` | 25 | `__ZNK15IOSkywalkPacket16getPacketBuffersEPP21IOSkywalkPacketBufferj` | `asm/ZNK15IOSkywalkPacket16getPacketBuffersEPP21IOSkywalkPacketBufferj.asm.txt` |
| `IOSkywalkPacket` | `0xffffff80029a23d2` | 11 | `__ZNK15IOSkywalkPacket19getMemoryDescriptorEv` | `asm/ZNK15IOSkywalkPacket19getMemoryDescriptorEv.asm.txt` |
| `IOSkywalkPacket` | `0xffffff80029a23ec` | 11 | `__ZN15IOSkywalkPacket13setDataLengthEj` | `asm/ZN15IOSkywalkPacket13setDataLengthEj.asm.txt` |
| `IOSkywalkPacket` | `0xffffff80029a240a` | 11 | `__ZN15IOSkywalkPacket10setDataOffEx` | `asm/ZN15IOSkywalkPacket10setDataOffEx.asm.txt` |
| `IOSkywalkPacket` | `0xffffff80029a2428` | 12 | `__ZNK15IOSkywalkPacket10getDataOffEv` | `asm/ZNK15IOSkywalkPacket10getDataOffEv.asm.txt` |
| `IOSkywalkPacket` | `0xffffff80029a2444` | 53 | `__ZN15IOSkywalkPacket16setDataOffAndLenExm` | `asm/ZN15IOSkywalkPacket16setDataOffAndLenExm.asm.txt` |
| `IOSkywalkPacket` | `0xffffff80029a24d0` | 52 | `__ZN15IOSkywalkPacket22setDataOffsetAndLengthEtj` | `asm/ZN15IOSkywalkPacket22setDataOffsetAndLengthEtj.asm.txt` |
| `IOSkywalkPacket` | `0xffffff80029a2558` | 13 | `__ZN15IOSkywalkPacket13setDataOffsetEt` | `asm/ZN15IOSkywalkPacket13setDataOffsetEt.asm.txt` |
| `IOSkywalkPacket` | `0xffffff80029a257a` | 13 | `__ZNK15IOSkywalkPacket13getDataOffsetEv` | `asm/ZNK15IOSkywalkPacket13getDataOffsetEv.asm.txt` |

### Source evidence snippets

**RTW88WCLSkywalkQueues.cpp:1-19**

```cpp
    1: /* SPDX-License-Identifier: GPL-2.0-only
    2:  * Sequoia 24H32 Skywalk queue and packet-pool resource owner.
    3:  */
    4: #include "RTW88WCLSkywalkQueues.hpp"
    5: #include "RTW88WCLPacketView.hpp"
    6: 
    7: #include <IOKit/IOLib.h>
    8: #include <libkern/c++/OSMetaClass.h>
    9: 
   10: /* The bundled SDK declares PoolOptions before its public: label. Expose the
   11:  * exact protected nested ABI type through a derived access shim; its layout is
   12:  * unchanged and no shim object is instantiated. */
   13: class RTW88WCLPoolOptionsAccess : public IOSkywalkPacketBufferPool {
   14: public:
   15:     using PoolOptions = IOSkywalkPacketBufferPool::PoolOptions;
   16: };
   17: 
   18: #define super OSObject
   19: OSDefineMetaClassAndStructors(RTW88WCLSkywalkQueues, OSObject)
```

**RTW88WCLSkywalkQueues.cpp:21-30**

```cpp
   21: bool RTW88WCLSkywalkQueues::init()
   22: {
   23:     if (!super::init())
   24:         return false;
   25:     _txPool = nullptr;
   26:     _rxPool = nullptr;
   27:     _txSubmission = nullptr;
   28:     _txCompletion = nullptr;
   29:     _rxSubmission = nullptr;
   30:     _rxCompletion = nullptr;
```

**RTW88WCLSkywalkQueues.cpp:35-99**

```cpp
   35: IOReturn RTW88WCLSkywalkQueues::createQueues()
   36: {
   37:     if (_allocated)
   38:         return kIOReturnSuccess;
   39:     if (_txPool || _rxPool || _txSubmission || _txCompletion ||
   40:         _rxSubmission || _rxCompletion)
   41:         return kIOReturnBusy;
   42: 
   43:     RTW88WCLPoolOptionsAccess::PoolOptions txOptions = {};
   44:     txOptions.packetCount = kQueueCapacity;
   45:     txOptions.bufferCount = kQueueCapacity;
   46:     txOptions.bufferSize = kTxBufferSize;
   47:     txOptions.maxBuffersPerPacket = 1;
   48:     txOptions.memorySegmentSize = kQueueCapacity * kTxBufferSize;
   49:     txOptions.poolFlags = 0;
   50:     txOptions._reserved = 0;
   51: 
   52:     RTW88WCLPoolOptionsAccess::PoolOptions rxOptions = txOptions;
   53:     rxOptions.bufferSize = kRxBufferSize;
   54:     rxOptions.memorySegmentSize = kQueueCapacity * kRxBufferSize;
   55: 
   56:     _txPool = IOSkywalkPacketBufferPool::withName(
   57:         "RTL88WiFi-WCL-TX", this, kIOSkywalkPacketTypeNetwork, &txOptions);
   58:     if (!_txPool)
   59:         goto no_memory;
   60: 
   61:     _rxPool = IOSkywalkPacketBufferPool::withName(
   62:         "RTL88WiFi-WCL-RX", this, kIOSkywalkPacketTypeNetwork, &rxOptions);
   63:     if (!_rxPool)
   64:         goto no_memory;
   65: 
   66:     /* These queue objects are deliberately not added to an IOWorkLoop and
   67:      * are not passed to registerEthernetInterface() yet. Skywalk owns their
   68:      * scheduling and packet lifetime only after a complete RegistrationInfo
   69:      * + ring setup transaction, which is a later stage. */
   70:     _txSubmission = IOSkywalkTxSubmissionQueue::withPool(
   71:         _txPool, kQueueCapacity, 0, this,
   72:         &RTW88WCLSkywalkQueues::txSubmissionAction, this, 0);
   73:     if (!_txSubmission)
   74:         goto no_memory;
   75: 
   76:     _txCompletion = IOSkywalkTxCompletionQueue::withPool(
   77:         _txPool, kQueueCapacity, 0, this,
   78:         &RTW88WCLSkywalkQueues::txCompletionAction, this, 0);
   79:     if (!_txCompletion)
   80:         goto no_memory;
   81: 
   82:     _rxSubmission = IOSkywalkRxSubmissionQueue::withPool(
   83:         _rxPool, kQueueCapacity, 0, static_cast<kern_packet_svc_class_t>(0),
   84:         this, &RTW88WCLSkywalkQueues::rxSubmissionAction, this, 0);
   85:     if (!_rxSubmission)
   86:         goto no_memory;
   87: 
   88:     _rxCompletion = IOSkywalkRxCompletionQueue::withPool(
   89:         _rxPool, kQueueCapacity, 0, this,
   90:         &RTW88WCLSkywalkQueues::rxCompletionAction, this, 0);
   91:     if (!_rxCompletion)
   92:         goto no_memory;
   93: 
   94:     _allocated = true;
   95:     IOLog("rtl88wifi-wcl: allocated Skywalk pools and four queue objects (not registered)\n");
   96:     return kIOReturnSuccess;
   97: 
   98: no_memory:
   99:     destroyQueues();
```

**RTW88WCLSkywalkQueues.cpp:101-110**

```cpp
  101: }
  102: 
  103: void RTW88WCLSkywalkQueues::destroyQueues()
  104: {
  105:     /* Release queues before their pools: queue implementations retain and
  106:      * reference their associated pool for packet and buffer accounting. */
  107:     if (_rxCompletion) {
  108:         _rxCompletion->release();
  109:         _rxCompletion = nullptr;
  110:     }
```

**RTW88WCLSkywalkQueues.cpp:119-140**

```cpp
  119:     if (_txSubmission) {
  120:         _txSubmission->release();
  121:         _txSubmission = nullptr;
  122:     }
  123:     if (_rxPool) {
  124:         _rxPool->release();
  125:         _rxPool = nullptr;
  126:     }
  127:     if (_txPool) {
  128:         _txPool->release();
  129:         _txPool = nullptr;
  130:     }
  131:     _allocated = false;
  132: }
  133: 
  134: bool RTW88WCLSkywalkQueues::queuesAllocated() const
  135: {
  136:     return _allocated && _txPool && _rxPool && _txSubmission &&
  137:            _txCompletion && _rxSubmission && _rxCompletion;
  138: }
  139: 
  140: IOReturn RTW88WCLSkywalkQueues::txSubmissionAction(
```

**RTW88WCLSkywalkQueues.cpp:154-162**

```cpp
  154:         if (!packets[i])
  155:             return kIOReturnBadArgument;
  156:         RTW88WCLPacketView view = {};
  157:         if (!RTW88WCLResolveEthernetTxPacket(
  158:                 const_cast<IOSkywalkPacket *>(packets[i]), self->_txPool, &view))
  159:             return kIOReturnBadArgument;
  160:     }
  161: 
  162:     return kIOReturnNotReady;
```

**RTW88WCLSkywalkRxAdapter.cpp:5-44**

```cpp
    5: #include "RTW88WCLSkywalkRxAdapter.hpp"
    6: #include "RTW88WCLPacketSpanValidation.hpp"
    7: 
    8: #include <IOKit/IOLib.h>
    9: #include <IOKit/skywalk/IOSkywalkMemorySegment.h>
   10: #include <IOKit/skywalk/IOSkywalkNetworkPacket.h>
   11: #include <IOKit/skywalk/IOSkywalkPacketBuffer.h>
   12: #include <sys/kpi_mbuf.h>
   13: 
   14: #define super IOEventSource
   15: OSDefineMetaClassAndStructors(RTW88WCLSkywalkRxAdapter, IOEventSource)
   16: 
   17: bool RTW88WCLSkywalkRxAdapter::init(OSObject *owner, IOWorkLoop *workLoop,
   18:                                     IOSkywalkPacketBufferPool *rxPool,
   19:                                     FrameSink sink, void *context)
   20: {
   21:     if (!owner || !workLoop || !rxPool || _workLoop || _rxPool || _registered)
   22:         return false;
   23:     if (!super::init(owner, nullptr))
   24:         return false;
   25: 
   26:     _frames.reset();
   27:     _workLoop = workLoop;
   28:     _rxPool = rxPool;
   29:     _rxPool->retain();
   30:     _sink = sink;
   31:     _sinkContext = context;
   32:     __atomic_store_n(&_pendingSignal, 0U, __ATOMIC_RELAXED);
   33:     __atomic_store_n(&_stopping, 0U, __ATOMIC_RELAXED);
   34:     __atomic_store_n(&_dropped, 0U, __ATOMIC_RELAXED);
   35:     __atomic_store_n(&_prepared, 0U, __ATOMIC_RELAXED);
   36: 
   37:     const IOReturn status = workLoop->addEventSource(this);
   38:     if (status != kIOReturnSuccess) {
   39:         _rxPool->release();
   40:         _rxPool = nullptr;
   41:         _workLoop = nullptr;
   42:         _sink = nullptr;
   43:         _sinkContext = nullptr;
   44:         return false;
```

**RTW88WCLSkywalkRxAdapter.cpp:59-72**

```cpp
   59:            packetLength <= kMaximumFrameLength;
   60: }
   61: 
   62: bool RTW88WCLSkywalkRxAdapter::copyMbufToSkywalkPacket(
   63:     IOSkywalkPacketBufferPool *pool, mbuf_t source,
   64:     IOSkywalkPacket **outPacket)
   65: {
   66:     if (outPacket)
   67:         *outPacket = nullptr;
   68:     if (!pool || !source || !outPacket)
   69:         return false;
   70: 
   71:     const size_t packetLength = mbuf_pkthdr_len(source);
   72:     if (packetLength < kMinimumFrameLength ||
```

**RTW88WCLSkywalkRxAdapter.cpp:74-103**

```cpp
   74:         return false;
   75: 
   76:     IOSkywalkPacket *packet = nullptr;
   77:     /* Option bit 0 requests non-blocking allocation in a packet callback. */
   78:     if (pool->allocatePacket(1, &packet, 1) != kIOReturnSuccess || !packet)
   79:         return false;
   80: 
   81:     bool valid = false;
   82:     do {
   83:         if (packet->getPacketType() != kIOSkywalkPacketTypeNetwork ||
   84:             packet->getPacketBufferPool() != pool ||
   85:             packet->getPacketBufferCount() != 1)
   86:             break;
   87: 
   88:         auto *networkPacket = OSDynamicCast(IOSkywalkNetworkPacket, packet);
   89:         if (!networkPacket)
   90:             break;
   91: 
   92:         IOSkywalkPacketBuffer *buffers[1] = { nullptr };
   93:         if (packet->getPacketBuffers(buffers, 1) != 1 || !buffers[0])
   94:             break;
   95:         IOSkywalkPacketBuffer *buffer = buffers[0];
   96:         if (buffer->getPacketBufferPool() != pool)
   97:             break;
   98: 
   99:         IOSkywalkMemorySegment *segment = buffer->getMemorySegment();
  100:         if (!segment)
  101:             break;
  102:         IOMemoryDescriptor *memory = segment->getMemoryDescriptor();
  103:         if (!memory)
```

**RTW88WCLSkywalkRxAdapter.cpp:105-119**

```cpp
  105: 
  106:         const uint64_t segmentBase = segment->getVirtualAddress();
  107:         const RTW88WCLPacketSpan span = {
  108:             memory->getLength(),
  109:             buffer->getMemorySegmentOffset(),
  110:             buffer->getBufferSize(),
  111:             0,
  112:             static_cast<uint32_t>(packetLength)
  113:         };
  114:         uintptr_t destinationAddress = 0;
  115:         if (!RTW88WCLResolvePacketBufferAddress(
  116:                 segmentBase, span, &destinationAddress))
  117:             break;
  118: 
  119:         if (packet->setDataOffsetAndLength(
```

**RTW88WCLSkywalkRxAdapter.cpp:136-144**

```cpp
  136:         valid = true;
  137:     } while (false);
  138: 
  139:     if (!valid)
  140:         (void)pool->deallocatePacket(packet);
  141:     return valid;
  142: }
  143: 
  144: IOReturn RTW88WCLSkywalkRxAdapter::enqueueFrame(mbuf_t packet)
```

**RTW88WCLSkywalkRxAdapter.cpp:175-190**

```cpp
  175:     mbuf_t source = nullptr;
  176:     while (drained < kDrainBudget && _frames.pop(&source)) {
  177:         if (source) {
  178:             IOSkywalkPacket *packet = nullptr;
  179:             if (copyMbufToSkywalkPacket(_rxPool, source, &packet)) {
  180:                 __atomic_add_fetch(&_prepared, 1U, __ATOMIC_RELAXED);
  181:                 /* A true return means the sink has accepted ownership. The
  182:                  * current controller sink returns false because the RX
  183:                  * completion queue is still unregistered. */
  184:                 const bool accepted = _sink && _sink(packet, _sinkContext);
  185:                 if (!accepted) {
  186:                     (void)_rxPool->deallocatePacket(packet);
  187:                     __atomic_add_fetch(&_dropped, 1U, __ATOMIC_RELAXED);
  188:                 }
  189:             } else {
  190:                 __atomic_add_fetch(&_dropped, 1U, __ATOMIC_RELAXED);
```

**RTW88WCLSkywalkRxAdapter.cpp:227-237**

```cpp
  227:     }
  228:     _sink = nullptr;
  229:     _sinkContext = nullptr;
  230:     _workLoop = nullptr;
  231:     if (_rxPool) {
  232:         _rxPool->release();
  233:         _rxPool = nullptr;
  234:     }
  235: }
  236: 
  237: void RTW88WCLSkywalkRxAdapter::free()
```

**RTW88WCLSkywalkRxAdapter.cpp:244-254**

```cpp
  244: {
  245:     return __atomic_load_n(&_dropped, __ATOMIC_ACQUIRE);
  246: }
  247: 
  248: uint32_t RTW88WCLSkywalkRxAdapter::preparedFrames() const
  249: {
  250:     return __atomic_load_n(&_prepared, __ATOMIC_ACQUIRE);
  251: }
  252: 
  253: uint32_t RTW88WCLSkywalkRxAdapter::queuedFrames() const
  254: {
```

**RTW88WCLSkywalkTxAdapter.cpp:16-40**

```cpp
   16: {
   17:     if (!super::init())
   18:         return false;
   19:     _radio = nullptr;
   20:     _txPool = nullptr;
   21:     _tickets.reset();
   22:     return true;
   23: }
   24: 
   25: IOReturn RTW88WCLSkywalkTxAdapter::bind(
   26:     RTW88IEEE80211 *radio, IOSkywalkPacketBufferPool *txPool)
   27: {
   28:     if (!radio || !txPool)
   29:         return kIOReturnBadArgument;
   30:     if (_radio || _txPool || _tickets.hasOutstanding())
   31:         return kIOReturnBusy;
   32: 
   33:     radio->retain();
   34:     txPool->retain();
   35:     _radio = radio;
   36:     _txPool = txPool;
   37:     return kIOReturnSuccess;
   38: }
   39: 
   40: IOReturn RTW88WCLSkywalkTxAdapter::unbind()
```

**RTW88WCLSkywalkTxAdapter.cpp:42-54**

```cpp
   42:     if (_tickets.hasOutstanding())
   43:         return kIOReturnBusy;
   44: 
   45:     RTW88IEEE80211 *radio = _radio;
   46:     IOSkywalkPacketBufferPool *pool = _txPool;
   47:     _radio = nullptr;
   48:     _txPool = nullptr;
   49:     if (pool)
   50:         pool->release();
   51:     if (radio)
   52:         radio->release();
   53:     return kIOReturnSuccess;
   54: }
```

**RTW88WCLSkywalkTxAdapter.cpp:76-96**

```cpp
   76: IOReturn RTW88WCLSkywalkTxAdapter::submitPacket(IOSkywalkPacket *packet)
   77: {
   78:     if (!packet)
   79:         return kIOReturnBadArgument;
   80:     if (!_radio || !_txPool)
   81:         return kIOReturnNotReady;
   82: 
   83:     RTW88WCLPacketView view = {};
   84:     if (!RTW88WCLResolveEthernetTxPacket(packet, _txPool, &view))
   85:         return kIOReturnBadArgument;
   86: 
   87:     mbuf_t mbuf = copyPacketToMbuf(view.bytes, view.length);
   88:     if (!mbuf)
   89:         return kIOReturnNoMemory;
   90: 
   91:     packet->retain();
   92:     TicketPool::Ticket *ticket = _tickets.reserve(packet);
   93:     if (!ticket) {
   94:         packet->release();
   95:         mbuf_freem(mbuf);
   96:         return kIOReturnBusy;
```

**RTW88WCLSkywalkTxAdapter.cpp:113-127**

```cpp
  113: void RTW88WCLSkywalkTxAdapter::backendCompletion(
  114:     void *context, void *cookie, bool transmitted)
  115: {
  116:     auto *self = static_cast<RTW88WCLSkywalkTxAdapter *>(context);
  117:     auto *ticket = static_cast<TicketPool::Ticket *>(cookie);
  118:     if (!self || !ticket)
  119:         return;
  120: 
  121:     /* No Skywalk API, OSObject release, allocation, or blocking operation is
  122:      * allowed here. A deferred consumer performs the completion handoff. */
  123:     (void)TicketPool::complete(ticket, transmitted);
  124: }
  125: 
  126: uint32_t RTW88WCLSkywalkTxAdapter::drainCompletions(
  127:     CompletionSink sink, void *context)
```

**RTW88WCLSkywalkTxAdapter.cpp:129-153**

```cpp
  129:     if (!sink)
  130:         return 0;
  131: 
  132:     /* A sink may trigger owner teardown; keep this adapter alive until the
  133:      * drain loop has stopped touching its ticket pool. */
  134:     retain();
  135:     uint32_t drained = 0;
  136:     for (;;) {
  137:         TicketPool::Ticket *ticket = _tickets.claimCompleted();
  138:         if (!ticket)
  139:             break;
  140: 
  141:         auto *packet = static_cast<IOSkywalkPacket *>(TicketPool::packet(ticket));
  142:         const bool transmitted = TicketPool::transmitted(ticket);
  143: 
  144:         /* The sink runs in deferred context and borrows the retained packet.
  145:          * It must finish any Skywalk queue handoff before returning. */
  146:         if (packet)
  147:             sink(packet, transmitted, context);
  148: 
  149:         TicketPool::finish(ticket);
  150:         if (packet)
  151:             packet->release();
  152:         release();
  153:         ++drained;
```

**RTW88WCLController.cpp:62-70**

```cpp
   62:         goto fail;
   63:     }
   64: 
   65:     /* Stage B: this native personality must be matched directly to a PCI
   66:      * provider. The backend retains it and owns BAR2/MMIO/DMA resources. */
   67:     {
   68:         IOPCIDevice *pci = OSDynamicCast(IOPCIDevice, provider);
   69:         if (!pci) {
   70:             IOLog("rtl88wifi-wcl: provider is not an IOPCIDevice\n");
```

**RTW88WCLController.cpp:112-120**

```cpp
  112:             goto fail;
  113:         }
  114:     }
  115: 
  116:     /* Stage D: reserve native Skywalk queue/pool objects while the PCI and
  117:      * RTW88 owners are still available for orderly unwind. These objects are
  118:      * intentionally not registered or scheduled until packet descriptor
  119:      * conversion and hardware completion correlation are implemented. */
  120:     _skywalkQueues = new RTW88WCLSkywalkQueues;
```

**RTW88WCLController.cpp:128-147**

```cpp
  128:     }
  129:     {
  130:         const IOReturn queueStatus = _skywalkQueues->createQueues();
  131:         if (queueStatus != kIOReturnSuccess) {
  132:             IOLog("rtl88wifi-wcl: Skywalk queue/pool allocation failed: 0x%08x\n",
  133:                   queueStatus);
  134:             goto fail;
  135:         }
  136:     }
  137: 
  138:     /* Stage E: bind the RX workloop consumer to the now-owned 4 KiB RX pool.
  139:      * It copies frames into native packet buffers, but its sink remains
  140:      * rejecting until the registration/completion ABI is closed. */
  141:     _rxAdapter = new RTW88WCLSkywalkRxAdapter;
  142:     if (!_rxAdapter || !_rxAdapter->init(
  143:             this, _workLoop, _skywalkQueues->rxPacketPool(),
  144:             &RTW88WCLController::stagedRxFrame, this)) {
  145:         if (_rxAdapter) {
  146:             _rxAdapter->release();
  147:             _rxAdapter = nullptr;
```

**RTW88WCLController.cpp:150-158**

```cpp
  150:         goto fail;
  151:     }
  152: 
  153:     provider->setProperty("RTW88WCLControllerStage",
  154:                            "PCI, RTW88 and pool-backed RX packet conversion staged; datapath pending");
  155: 
  156:     /* Publication fence: do not probe or power the radio until Skywalk packet
  157:      * registration, RX/TX rings, packet metadata and teardown are implemented.
  158:      * Starting it sooner would produce frames without a safe delivery path. */
```

**RTW88WCLController.cpp:203-222**

```cpp
  203:         _rxAdapter = nullptr;
  204:     }
  205: 
  206:     /* The RX adapter transfers accepted native packets into the controller's
  207:      * bounded ready ring. Recycle those packets while their pool still exists;
  208:      * on a pool error, retain the queue owner and PCI/backend context so a later
  209:      * stop/free attempt can retry rather than releasing live packet memory. */
  210:     const IOReturn recycleStatus = recycleStagedRxPackets();
  211:     if (recycleStatus != kIOReturnSuccess) {
  212:         IOLog("rtl88wifi-wcl: staged RX packet recycle deferred: 0x%08x\n",
  213:               recycleStatus);
  214:         return;
  215:     }
  216: 
  217:     /* Skywalk packet pools/queues are released only after both the mbuf staging
  218:      * adapter and the prepared-packet ownership ring have been drained. */
  219:     if (_skywalkQueues) {
  220:         _skywalkQueues->destroyQueues();
  221:         _skywalkQueues->release();
  222:         _skywalkQueues = nullptr;
```

**RTW88WCLController.cpp:226-234**

```cpp
  226:         const IOReturn fenceStatus = _pciBackend->setRadioRunning(false);
  227:         if (fenceStatus != kIOReturnSuccess) {
  228:             IOLog("rtl88wifi-wcl: PCI interrupt/bus-master fence failed: 0x%08x\n",
  229:                   fenceStatus);
  230:             return; // Keep callbacks, mappings and DMA owner alive on failure.
  231:         }
  232:     }
  233: 
  234:     /* RTW88IEEE80211 owns the compat callback context; destroy it before
```

**RTW88WCLController.cpp:250-258**

```cpp
  250: void RTW88WCLController::free()
  251: {
  252:     releaseNativeResources();
  253:     if (_pciBackend)
  254:         IOLog("rtl88wifi-wcl: PCI backend retained because shutdown fence did not complete\n");
  255:     if (_workLoop) {
  256:         _workLoop->release();
  257:         _workLoop = nullptr;
  258:     }
```

**RTW88WCLController.cpp:479-487**

```cpp
  479:         return nullptr;
  480: 
  481:     /* IO80211Controller inherits the IONetworkController packet allocator.
  482:      * Keep its mbuf metadata initialization rather than hand-rolling m_len. */
  483:     mbuf_t packet = allocatePacket(length);
  484:     leavePacketPath();
  485:     return packet;
  486: }
  487: 
```

**RTW88WCLController.cpp:505-552**

```cpp
  505: IOReturn RTW88WCLController::recycleStagedRxPackets()
  506: {
  507:     if (_stagedRxPackets.empty())
  508:         return kIOReturnSuccess;
  509:     if (!_skywalkQueues || !_skywalkQueues->rxPacketPool())
  510:         return kIOReturnNotReady;
  511: 
  512:     IOSkywalkPacketBufferPool *pool = _skywalkQueues->rxPacketPool();
  513:     IOSkywalkPacket *packet = nullptr;
  514:     bool disposalRequired = false;
  515:     while (_stagedRxPackets.pop(&packet)) {
  516:         if (!packet)
  517:             continue;
  518: 
  519:         const IOReturn status = pool->deallocatePacket(packet);
  520:         if (status != kIOReturnSuccess) {
  521:             /* The radio and RX event source are already quiesced, and these
  522:              * queues were never registered. If a packet cannot be returned
  523:              * individually, dispose the pool's packet set as one teardown
  524:              * operation before its memory segments are released. */
  525:             IOLog("rtl88wifi-wcl: RX packet recycle returned 0x%08x; pool disposal required\n",
  526:                   status);
  527:             disposalRequired = true;
  528:         }
  529:         packet = nullptr;
  530:     }
  531: 
  532:     if (disposalRequired)
  533:         pool->disposeAllPackets();
  534:     return kIOReturnSuccess;
  535: }
  536: 
  537: bool RTW88WCLController::stagedRxFrame(
  538:     IOSkywalkPacket *preparedPacket, void *context)
  539: {
  540:     auto *self = static_cast<RTW88WCLController *>(context);
  541:     if (!self || !preparedPacket)
  542:         return false;
  543: 
  544:     /* Preserve the pool-backed packet in a fixed-capacity owner ring. The
  545:      * ring is bounded to the RX pool's 128 packets; overflow returns false,
  546:      * causing the RX adapter to recycle the packet immediately. No queue API
  547:      * is called here: completion-queue registration/ownership is still fenced. */
  548:     return self->_stagedRxPackets.push(preparedPacket);
  549: }
  550: 
  551: IOWorkLoop *RTW88WCLController::getRxWorkLoop()
  552: {
```

### Manual questions

- [ ] Which object owns the DMA descriptor and mapped address?
- [ ] What prepare/complete pair is required for each allocation option?
- [ ] Are offsets and lengths bounded by both segment and buffer sizes?
- [ ] What cleanup order applies after partial prepare failure?

**Review outcome:** `UNRESOLVED — do not enable this contract`

## ethernet_registration_lifecycle: Ethernet interface registration, failure ownership and deregistration

**Status:** MANUAL_REVIEW_REQUIRED
**Candidate method bodies:** 206

### Kernel method candidates

| Class | Address | Instructions | Exact symbol | Assembly file |
|---|---:|---:|---|---|
| `IOSkywalkInterface` | `0xffffff8002973b8c` | 15 | `__ZN18IOSkywalkInterface9MetaClassC1Ev` | `asm/ZN18IOSkywalkInterface9MetaClassC1Ev.asm.txt` |
| `IOSkywalkInterface` | `0xffffff8002973bbe` | 4 | `__ZN18IOSkywalkInterface9MetaClassD1Ev` | `asm/ZN18IOSkywalkInterface9MetaClassD1Ev.asm.txt` |
| `IOSkywalkInterface` | `0xffffff8002973bc8` | 13 | `__ZN18IOSkywalkInterfaceC2EPK11OSMetaClass` | `asm/ZN18IOSkywalkInterfaceC2EPK11OSMetaClass.asm.txt` |
| `IOSkywalkInterface` | `0xffffff8002973be8` | 4 | `__ZN18IOSkywalkInterfaceD2Ev` | `asm/ZN18IOSkywalkInterfaceD2Ev.asm.txt` |
| `IOSkywalkInterface` | `0xffffff8002973bf2` | 3 | `__ZN18IOSkywalkInterfaceD1Ev` | `asm/ZN18IOSkywalkInterfaceD1Ev.asm.txt` |
| `IOSkywalkInterface` | `0xffffff8002973bf8` | 3 | `__ZN18IOSkywalkInterfaceD0Ev` | `asm/ZN18IOSkywalkInterfaceD0Ev.asm.txt` |
| `IOSkywalkInterface` | `0xffffff8002973bfe` | 6 | `__ZNK18IOSkywalkInterface12getMetaClassEv` | `asm/ZNK18IOSkywalkInterface12getMetaClassEv.asm.txt` |
| `IOSkywalkInterface` | `0xffffff8002973c0c` | 15 | `__ZN18IOSkywalkInterface9MetaClassC2Ev` | `asm/ZN18IOSkywalkInterface9MetaClassC2Ev.asm.txt` |
| `IOSkywalkInterface` | `0xffffff8002973c3e` | 5 | `__ZNK18IOSkywalkInterface9MetaClass5allocEv` | `asm/ZNK18IOSkywalkInterface9MetaClass5allocEv.asm.txt` |
| `IOSkywalkInterface` | `0xffffff8002973c46` | 6 | `__ZN18IOSkywalkInterfacenwEm` | `asm/ZN18IOSkywalkInterfacenwEm.asm.txt` |
| `IOSkywalkInterface` | `0xffffff8002973c5a` | 8 | `__ZN18IOSkywalkInterfacedlEPvm` | `asm/ZN18IOSkywalkInterfacedlEPvm.asm.txt` |
| `IOSkywalkInterface` | `0xffffff8002973c72` | 44 | `__ZN18IOSkywalkInterface4initEP12OSDictionary` | `asm/ZN18IOSkywalkInterface4initEP12OSDictionary.asm.txt` |
| `IOSkywalkInterface` | `0xffffff8002973d28` | 33 | `__ZN18IOSkywalkInterface4freeEv` | `asm/ZN18IOSkywalkInterface4freeEv.asm.txt` |
| `IOSkywalkInterface` | `0xffffff8002973db0` | 32 | `__ZN18IOSkywalkInterface29deregisterInterfaceWithQueuesEv` | `asm/ZN18IOSkywalkInterface29deregisterInterfaceWithQueuesEv.asm.txt` |
| `IOSkywalkInterface` | `0xffffff8002973e1c` | 23 | `__ZN18IOSkywalkInterface10handleOpenEP9IOServicejPv` | `asm/ZN18IOSkywalkInterface10handleOpenEP9IOServicejPv.asm.txt` |
| `IOSkywalkInterface` | `0xffffff8002973e68` | 21 | `__ZN18IOSkywalkInterface11handleCloseEP9IOServicej` | `asm/ZN18IOSkywalkInterface11handleCloseEP9IOServicej.asm.txt` |
| `IOSkywalkInterface` | `0xffffff8002973eb0` | 30 | `__ZNK18IOSkywalkInterface12handleIsOpenEPK9IOService` | `asm/ZNK18IOSkywalkInterface12handleIsOpenEPK9IOService.asm.txt` |
| `IOSkywalkInterface` | `0xffffff8002973f12` | 5 | `__ZN18IOSkywalkInterface21clientConnectWithTaskEP4taskP9IOServicej` | `asm/ZN18IOSkywalkInterface21clientConnectWithTaskEP4taskP9IOServicej.asm.txt` |
| `IOSkywalkInterface` | `0xffffff8002973f1a` | 4 | `__ZN18IOSkywalkInterface16clientDisconnectEP9IOServicej` | `asm/ZN18IOSkywalkInterface16clientDisconnectEP9IOServicej.asm.txt` |
| `IOSkywalkInterface` | `0xffffff8002973f20` | 76 | `__ZN18IOSkywalkInterface27registerInterfaceWithQueuesEPP20IOSkywalkPacketQueuejP25IOSkywalkPacketBufferPoolS4_j` | `asm/ZN18IOSkywalkInterface27registerInterfaceWithQueuesEPP20IOSkywalkPacketQueuejP25IOSkywalkPacketBufferPoolS4_j.asm.txt` |
| `IOSkywalkInterface` | `0xffffff8002974012` | 8 | `__ZN18IOSkywalkInterface13willTerminateEP9IOServicej` | `asm/ZN18IOSkywalkInterface13willTerminateEP9IOServicej.asm.txt` |
| `IOSkywalkInterface` | `0xffffff8002974026` | 39 | `__ZN18IOSkywalkInterface12didTerminateEP9IOServicejPb` | `asm/ZN18IOSkywalkInterface12didTerminateEP9IOServicejPb.asm.txt` |
| `IOSkywalkInterface` | `0xffffff8002974088` | 6 | `__ZN18IOSkywalkInterface13isTerminatingEv` | `asm/ZN18IOSkywalkInterface13isTerminatingEv.asm.txt` |
| `IOSkywalkInterface` | `0xffffff8002974098` | 7 | `__ZN18IOSkywalkInterface28_RESERVEDIOSkywalkInterface0Ev` | `asm/ZN18IOSkywalkInterface28_RESERVEDIOSkywalkInterface0Ev.asm.txt` |
| `IOSkywalkInterface` | `0xffffff80029740ac` | 6 | `__ZN18IOSkywalkInterface28_RESERVEDIOSkywalkInterface1Ev` | `asm/ZN18IOSkywalkInterface28_RESERVEDIOSkywalkInterface1Ev.asm.txt` |
| `IOSkywalkInterface` | `0xffffff80029740c2` | 6 | `__ZN18IOSkywalkInterface28_RESERVEDIOSkywalkInterface2Ev` | `asm/ZN18IOSkywalkInterface28_RESERVEDIOSkywalkInterface2Ev.asm.txt` |
| `IOSkywalkInterface` | `0xffffff80029740d8` | 6 | `__ZN18IOSkywalkInterface28_RESERVEDIOSkywalkInterface3Ev` | `asm/ZN18IOSkywalkInterface28_RESERVEDIOSkywalkInterface3Ev.asm.txt` |
| `IOSkywalkInterface` | `0xffffff80029740ee` | 6 | `__ZN18IOSkywalkInterface28_RESERVEDIOSkywalkInterface4Ev` | `asm/ZN18IOSkywalkInterface28_RESERVEDIOSkywalkInterface4Ev.asm.txt` |
| `IOSkywalkInterface` | `0xffffff8002974104` | 6 | `__ZN18IOSkywalkInterface28_RESERVEDIOSkywalkInterface5Ev` | `asm/ZN18IOSkywalkInterface28_RESERVEDIOSkywalkInterface5Ev.asm.txt` |
| `IOSkywalkInterface` | `0xffffff800297411a` | 6 | `__ZN18IOSkywalkInterface28_RESERVEDIOSkywalkInterface6Ev` | `asm/ZN18IOSkywalkInterface28_RESERVEDIOSkywalkInterface6Ev.asm.txt` |
| `IOSkywalkInterface` | `0xffffff8002974130` | 6 | `__ZN18IOSkywalkInterface28_RESERVEDIOSkywalkInterface7Ev` | `asm/ZN18IOSkywalkInterface28_RESERVEDIOSkywalkInterface7Ev.asm.txt` |
| `IOSkywalkInterface` | `0xffffff8002974146` | 6 | `__ZN18IOSkywalkInterface28_RESERVEDIOSkywalkInterface8Ev` | `asm/ZN18IOSkywalkInterface28_RESERVEDIOSkywalkInterface8Ev.asm.txt` |
| `IOSkywalkInterface` | `0xffffff800297415c` | 6 | `__ZN18IOSkywalkInterface28_RESERVEDIOSkywalkInterface9Ev` | `asm/ZN18IOSkywalkInterface28_RESERVEDIOSkywalkInterface9Ev.asm.txt` |
| `IOSkywalkInterface` | `0xffffff8002974172` | 6 | `__ZN18IOSkywalkInterface29_RESERVEDIOSkywalkInterface10Ev` | `asm/ZN18IOSkywalkInterface29_RESERVEDIOSkywalkInterface10Ev.asm.txt` |
| `IOSkywalkInterface` | `0xffffff8002974188` | 4 | `__ZN18IOSkywalkInterface9MetaClassD0Ev` | `asm/ZN18IOSkywalkInterface9MetaClassD0Ev.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff800298197e` | 15 | `__ZN25IOSkywalkNetworkInterface9MetaClassC1Ev` | `asm/ZN25IOSkywalkNetworkInterface9MetaClassC1Ev.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff80029819b0` | 4 | `__ZN25IOSkywalkNetworkInterface9MetaClassD1Ev` | `asm/ZN25IOSkywalkNetworkInterface9MetaClassD1Ev.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff80029819ba` | 13 | `__ZN25IOSkywalkNetworkInterfaceC2EPK11OSMetaClass` | `asm/ZN25IOSkywalkNetworkInterfaceC2EPK11OSMetaClass.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff80029819da` | 4 | `__ZN25IOSkywalkNetworkInterfaceD2Ev` | `asm/ZN25IOSkywalkNetworkInterfaceD2Ev.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff80029819e4` | 3 | `__ZN25IOSkywalkNetworkInterfaceD1Ev` | `asm/ZN25IOSkywalkNetworkInterfaceD1Ev.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff80029819ea` | 3 | `__ZN25IOSkywalkNetworkInterfaceD0Ev` | `asm/ZN25IOSkywalkNetworkInterfaceD0Ev.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff80029819f0` | 6 | `__ZNK25IOSkywalkNetworkInterface12getMetaClassEv` | `asm/ZNK25IOSkywalkNetworkInterface12getMetaClassEv.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff80029819fe` | 15 | `__ZN25IOSkywalkNetworkInterface9MetaClassC2Ev` | `asm/ZN25IOSkywalkNetworkInterface9MetaClassC2Ev.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff8002981a30` | 5 | `__ZNK25IOSkywalkNetworkInterface9MetaClass5allocEv` | `asm/ZNK25IOSkywalkNetworkInterface9MetaClass5allocEv.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff8002981a38` | 6 | `__ZN25IOSkywalkNetworkInterfacenwEm` | `asm/ZN25IOSkywalkNetworkInterfacenwEm.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff8002981a4c` | 8 | `__ZN25IOSkywalkNetworkInterfacedlEPvm` | `asm/ZN25IOSkywalkNetworkInterfacedlEPvm.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff8002981a64` | 40 | `__ZN25IOSkywalkNetworkInterface4initEP12OSDictionary` | `asm/ZN25IOSkywalkNetworkInterface4initEP12OSDictionary.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff8002981af8` | 16 | `__ZN25IOSkywalkNetworkInterface21handleLinkStatusEventEPv` | `asm/ZN25IOSkywalkNetworkInterface21handleLinkStatusEventEPv.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff8002981b1e` | 17 | `__ZN25IOSkywalkNetworkInterface4stopEP9IOService` | `asm/ZN25IOSkywalkNetworkInterface4stopEP9IOService.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff8002981b54` | 85 | `__ZN25IOSkywalkNetworkInterface26deregisterNetworkInterfaceEj` | `asm/ZN25IOSkywalkNetworkInterface26deregisterNetworkInterfaceEj.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff8002981ca6` | 48 | `__ZN25IOSkywalkNetworkInterface4freeEv` | `asm/ZN25IOSkywalkNetworkInterface4freeEv.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff8002981d7e` | 81 | `__ZN25IOSkywalkNetworkInterface24registerNetworkInterfaceEPKNS_16RegistrationInfoEPP20IOSkywalkPacketQueuejP25IOSkywalkPacketBufferPoolS7_j` | `asm/ZN25IOSkywalkNetworkInterface24registerNetworkInterfaceEPKNS_16RegistrationInfoEPP20IOSkywalkPacketQueuejP25IOSkywalkPacketBufferPoolS7_j.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff8002981eac` | 143 | `__ZN25IOSkywalkNetworkInterface24registerNetworkInterfaceEPKNS_16RegistrationInfoEP20IOSkywalkLogicalLinkP25IOSkywalkPacketBufferPoolS6_j` | `asm/ZN25IOSkywalkNetworkInterface24registerNetworkInterfaceEPKNS_16RegistrationInfoEP20IOSkywalkLogicalLinkP25IOSkywalkPacketBufferPoolS6_j.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff80029820d8` | 4 | `__ZN25IOSkywalkNetworkInterface39registerNetworkInterfaceWithLogicalLinkEPKNS_16RegistrationInfoEP20IOSkywalkLogicalLinkP25IOSkywalkPacketBufferPoolS6_j` | `asm/ZN25IOSkywalkNetworkInterface39registerNetworkInterfaceWithLogicalLinkEPKNS_16RegistrationInfoEP20IOSkywalkLogicalLinkP25IOSkywalkPacketBufferPoolS6_j.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff80029820e2` | 36 | `__ZN25IOSkywalkNetworkInterface17deleteLogicalLinkEP20IOSkywalkLogicalLink` | `asm/ZN25IOSkywalkNetworkInterface17deleteLogicalLinkEP20IOSkywalkLogicalLink.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff800298214e` | 4 | `__ZN25IOSkywalkNetworkInterface21deregisterLogicalLinkEv` | `asm/ZN25IOSkywalkNetworkInterface21deregisterLogicalLinkEv.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff8002982158` | 69 | `__ZN25IOSkywalkNetworkInterface14addLogicalLinkEP20IOSkywalkLogicalLink` | `asm/ZN25IOSkywalkNetworkInterface14addLogicalLinkEP20IOSkywalkLogicalLink.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff800298223e` | 30 | `__ZN25IOSkywalkNetworkInterface15reportEventTypeEjPvm` | `asm/ZN25IOSkywalkNetworkInterface15reportEventTypeEjPvm.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff8002982290` | 6 | `__ZN25IOSkywalkNetworkInterface15getLogicalLinksEv` | `asm/ZN25IOSkywalkNetworkInterface15getLogicalLinksEv.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff800298229e` | 29 | `__ZN25IOSkywalkNetworkInterface19prepareBSDInterfaceEP7__ifnetj` | `asm/ZN25IOSkywalkNetworkInterface19prepareBSDInterfaceEP7__ifnetj.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff80029822fc` | 23 | `__ZN25IOSkywalkNetworkInterface20finalizeBSDInterfaceEP7__ifnetj` | `asm/ZN25IOSkywalkNetworkInterface20finalizeBSDInterfaceEP7__ifnetj.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff800298234e` | 7 | `__ZNK25IOSkywalkNetworkInterface15getBSDInterfaceEv` | `asm/ZNK25IOSkywalkNetworkInterface15getBSDInterfaceEv.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff8002982360` | 12 | `__ZN25IOSkywalkNetworkInterface10setBSDNameEPKc` | `asm/ZN25IOSkywalkNetworkInterface10setBSDNameEPKc.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff8002982382` | 7 | `__ZNK25IOSkywalkNetworkInterface10getBSDNameEv` | `asm/ZNK25IOSkywalkNetworkInterface10getBSDNameEv.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff8002982394` | 6 | `__ZN25IOSkywalkNetworkInterface16getPacketTapInfoEPjS0_` | `asm/ZN25IOSkywalkNetworkInterface16getPacketTapInfoEPjS0_.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff80029823a0` | 41 | `__ZNK25IOSkywalkNetworkInterface25calculateRingSizeForQueueEPK20IOSkywalkPacketQueuePj` | `asm/ZNK25IOSkywalkNetworkInterface25calculateRingSizeForQueueEPK20IOSkywalkPacketQueuePj.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff8002982414` | 13 | `__ZN25IOSkywalkNetworkInterface20getServiceClassIndexEjPj` | `asm/ZN25IOSkywalkNetworkInterface20getServiceClassIndexEjPj.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff8002982436` | 38 | `__ZN25IOSkywalkNetworkInterface20reportDataBandwidthsEyyyy` | `asm/ZN25IOSkywalkNetworkInterface20reportDataBandwidthsEyyyy.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff80029824a2` | 94 | `__ZN25IOSkywalkNetworkInterface17processBSDCommandEP7__ifnetjPv` | `asm/ZN25IOSkywalkNetworkInterface17processBSDCommandEP7__ifnetjPv.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff80029825d6` | 112 | `__ZN25IOSkywalkNetworkInterface14ioctl_gifmediaEP7__ifnetjPv` | `asm/ZN25IOSkywalkNetworkInterface14ioctl_gifmediaEP7__ifnetjPv.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff8002982758` | 130 | `__ZN25IOSkywalkNetworkInterface14ioctl_sifmediaEP7__ifnetPv` | `asm/ZN25IOSkywalkNetworkInterface14ioctl_sifmediaEP7__ifnetPv.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff8002982904` | 40 | `__ZN25IOSkywalkNetworkInterface15ioctl_gifdevmtuEP7__ifnetPv` | `asm/ZN25IOSkywalkNetworkInterface15ioctl_gifdevmtuEP7__ifnetPv.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff8002982972` | 91 | `__ZN25IOSkywalkNetworkInterface12ioctl_sifmtuEP7__ifnetPvb` | `asm/ZN25IOSkywalkNetworkInterface12ioctl_sifmtuEP7__ifnetPvb.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff8002982a7c` | 22 | `__ZN25IOSkywalkNetworkInterface12ioctl_gifcapEP7__ifnetPv` | `asm/ZN25IOSkywalkNetworkInterface12ioctl_gifcapEP7__ifnetPv.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff8002982aba` | 65 | `__ZN25IOSkywalkNetworkInterface12ioctl_sifcapEP7__ifnetPv` | `asm/ZN25IOSkywalkNetworkInterface12ioctl_sifcapEP7__ifnetPv.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff8002982b7a` | 6 | `__ZN25IOSkywalkNetworkInterface23processInterfaceCommandEP5ifdrv` | `asm/ZN25IOSkywalkNetworkInterface23processInterfaceCommandEP5ifdrv.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff8002982b86` | 15 | `__ZN25IOSkywalkNetworkInterface6enableEj` | `asm/ZN25IOSkywalkNetworkInterface6enableEj.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff8002982bae` | 26 | `__ZN25IOSkywalkNetworkInterface7disableEj` | `asm/ZN25IOSkywalkNetworkInterface7disableEj.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff8002982c04` | 56 | `__ZN25IOSkywalkNetworkInterface16reportLinkStatusEjj` | `asm/ZN25IOSkywalkNetworkInterface16reportLinkStatusEjj.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff8002982cb0` | 5 | `__ZN25IOSkywalkNetworkInterface9isEnabledEv` | `asm/ZN25IOSkywalkNetworkInterface9isEnabledEv.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff8002982cbc` | 5 | `__ZN25IOSkywalkNetworkInterface18setInterfaceEnableEb` | `asm/ZN25IOSkywalkNetworkInterface18setInterfaceEnableEb.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff8002982cc4` | 5 | `__ZN25IOSkywalkNetworkInterface15setRunningStateEb` | `asm/ZN25IOSkywalkNetworkInterface15setRunningStateEb.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff8002982ccc` | 42 | `__ZNK25IOSkywalkNetworkInterface22getUnsentDataByteCountEPjS0_j` | `asm/ZNK25IOSkywalkNetworkInterface22getUnsentDataByteCountEPjS0_j.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff8002982d4a` | 6 | `__ZN25IOSkywalkNetworkInterface17handleChosenMediaEj` | `asm/ZN25IOSkywalkNetworkInterface17handleChosenMediaEj.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff8002982d56` | 6 | `__ZN25IOSkywalkNetworkInterface22getSupportedMediaArrayEPjS0_` | `asm/ZN25IOSkywalkNetworkInterface22getSupportedMediaArrayEPjS0_.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff8002982d62` | 27 | `__ZN25IOSkywalkNetworkInterface16hwAssistsToIfcapEjPj` | `asm/ZN25IOSkywalkNetworkInterface16hwAssistsToIfcapEjPj.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff8002982daa` | 27 | `__ZN25IOSkywalkNetworkInterface16ifcapToHwAssistsEjPj` | `asm/ZN25IOSkywalkNetworkInterface16ifcapToHwAssistsEjPj.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff8002982df0` | 34 | `__ZN25IOSkywalkNetworkInterface22hwAssistsToIfHwAssistsEjPj` | `asm/ZN25IOSkywalkNetworkInterface22hwAssistsToIfHwAssistsEjPj.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff8002982e4a` | 7 | `__ZN25IOSkywalkNetworkInterface8getIfnetEv` | `asm/ZN25IOSkywalkNetworkInterface8getIfnetEv.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff8002982e5c` | 15 | `__ZN25IOSkywalkNetworkInterface26setInterfaceAdvisoryNoticeEPvPFiS0_PK24ifnet_interface_advisoryE` | `asm/ZN25IOSkywalkNetworkInterface26setInterfaceAdvisoryNoticeEPvPFiS0_PK24ifnet_interface_advisoryE.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff8002982e8a` | 22 | `__ZN25IOSkywalkNetworkInterface17reportLinkQualityEj` | `asm/ZN25IOSkywalkNetworkInterface17reportLinkQualityEj.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff8002982ec4` | 31 | `__ZN25IOSkywalkNetworkInterface23reportInterfaceAdvisoryEPK24ifnet_interface_advisory` | `asm/ZN25IOSkywalkNetworkInterface23reportInterfaceAdvisoryEPK24ifnet_interface_advisory.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff8002982f16` | 6 | `__ZN25IOSkywalkNetworkInterface23interfaceAdvisoryEnableEb` | `asm/ZN25IOSkywalkNetworkInterface23interfaceAdvisoryEnableEb.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff8002982f22` | 29 | `__ZN25IOSkywalkNetworkInterface21getSupportedWakeFlagsEPj` | `asm/ZN25IOSkywalkNetworkInterface21getSupportedWakeFlagsEPj.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff8002982f7a` | 7 | `__ZN25IOSkywalkNetworkInterface17enableNetworkWakeEj` | `asm/ZN25IOSkywalkNetworkInterface17enableNetworkWakeEj.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff8002982f8c` | 5 | `__ZN25IOSkywalkNetworkInterface21captureInterfaceStateEj` | `asm/ZN25IOSkywalkNetworkInterface21captureInterfaceStateEj.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff8002982f94` | 5 | `__ZN25IOSkywalkNetworkInterface21restoreInterfaceStateEj` | `asm/ZN25IOSkywalkNetworkInterface21restoreInterfaceStateEj.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff8002982f9c` | 26 | `__ZN25IOSkywalkNetworkInterface10joinPMtreeEP9IOService` | `asm/ZN25IOSkywalkNetworkInterface10joinPMtreeEP9IOService.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff8002982fe2` | 42 | `__ZN25IOSkywalkNetworkInterface17setAggressivenessEmm` | `asm/ZN25IOSkywalkNetworkInterface17setAggressivenessEmm.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff800298306c` | 13 | `__ZN25IOSkywalkNetworkInterface18getMaxTransferUnitEv` | `asm/ZN25IOSkywalkNetworkInterface18getMaxTransferUnitEv.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff800298308c` | 7 | `__ZN25IOSkywalkNetworkInterface18setMaxTransferUnitEj` | `asm/ZN25IOSkywalkNetworkInterface18setMaxTransferUnitEj.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff800298309e` | 13 | `__ZN25IOSkywalkNetworkInterface16getMinPacketSizeEv` | `asm/ZN25IOSkywalkNetworkInterface16getMinPacketSizeEv.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff80029830be` | 5 | `__ZN25IOSkywalkNetworkInterface6setMTUEj` | `asm/ZN25IOSkywalkNetworkInterface6setMTUEj.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff80029830c6` | 8 | `__ZN25IOSkywalkNetworkInterface18getHardwareAssistsEv` | `asm/ZN25IOSkywalkNetworkInterface18getHardwareAssistsEv.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff80029830da` | 11 | `__ZN25IOSkywalkNetworkInterface18setHardwareAssistsEjj` | `asm/ZN25IOSkywalkNetworkInterface18setHardwareAssistsEjj.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff80029830f6` | 13 | `__ZN25IOSkywalkNetworkInterface18getInterfaceFamilyEv` | `asm/ZN25IOSkywalkNetworkInterface18getInterfaceFamilyEv.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff8002983116` | 13 | `__ZN25IOSkywalkNetworkInterface21getInterfaceSubFamilyEv` | `asm/ZN25IOSkywalkNetworkInterface21getInterfaceSubFamilyEv.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff8002983136` | 16 | `__ZN25IOSkywalkNetworkInterface16getBSDNamePrefixEv` | `asm/ZN25IOSkywalkNetworkInterface16getBSDNamePrefixEv.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff800298315c` | 12 | `__ZN25IOSkywalkNetworkInterface16getBSDUnitNumberEv` | `asm/ZN25IOSkywalkNetworkInterface16getBSDUnitNumberEv.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff800298317e` | 13 | `__ZN25IOSkywalkNetworkInterface15getInitialMediaEv` | `asm/ZN25IOSkywalkNetworkInterface15getInitialMediaEv.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff800298319e` | 5 | `__ZN25IOSkywalkNetworkInterface15getFeatureFlagsEv` | `asm/ZN25IOSkywalkNetworkInterface15getFeatureFlagsEv.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff80029831a6` | 17 | `__ZN25IOSkywalkNetworkInterface15getTxDataOffsetEv` | `asm/ZN25IOSkywalkNetworkInterface15getTxDataOffsetEv.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff80029831d0` | 51 | `__ZN25IOSkywalkNetworkInterface12setKDPPollerEP25IOSkywalkNetworkKDPPoller` | `asm/ZN25IOSkywalkNetworkInterface12setKDPPollerEP25IOSkywalkNetworkKDPPoller.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff8002983276` | 8 | `__ZN25IOSkywalkNetworkInterface9bpfAttachEjj` | `asm/ZN25IOSkywalkNetworkInterface9bpfAttachEjj.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff8002983294` | 22 | `__ZN25IOSkywalkNetworkInterface7_bpfTapEP7__ifnetjj` | `asm/ZN25IOSkywalkNetworkInterface7_bpfTapEP7__ifnetjj.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff80029832d8` | 5 | `__ZN25IOSkywalkNetworkInterface6bpfTapEjj` | `asm/ZN25IOSkywalkNetworkInterface6bpfTapEjj.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff80029832e0` | 29 | `__ZN25IOSkywalkNetworkInterface17bpfTapInputPacketEjP15IOSkywalkPacketPvm` | `asm/ZN25IOSkywalkNetworkInterface17bpfTapInputPacketEjP15IOSkywalkPacketPvm.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff8002983330` | 29 | `__ZN25IOSkywalkNetworkInterface18bpfTapOutputPacketEjP15IOSkywalkPacketPvm` | `asm/ZN25IOSkywalkNetworkInterface18bpfTapOutputPacketEjP15IOSkywalkPacketPvm.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff8002983380` | 6 | `__ZN25IOSkywalkNetworkInterface17classNameOverrideEv` | `asm/ZN25IOSkywalkNetworkInterface17classNameOverrideEv.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff800298338e` | 21 | `__ZN25IOSkywalkNetworkInterface13getLocalPortsEjjPh` | `asm/ZN25IOSkywalkNetworkInterface13getLocalPortsEjjPh.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff80029833d2` | 11 | `__ZN25IOSkywalkNetworkInterface18setFastlaneCapableEb` | `asm/ZN25IOSkywalkNetworkInterface18setFastlaneCapableEb.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff80029833f2` | 12 | `__ZN25IOSkywalkNetworkInterface45getIPv4DefaultRouterLinkLayerReachabilityInfoEP18ifnet_llreach_info` | `asm/ZN25IOSkywalkNetworkInterface45getIPv4DefaultRouterLinkLayerReachabilityInfoEP18ifnet_llreach_info.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff8002983414` | 12 | `__ZN25IOSkywalkNetworkInterface45getIPv6DefaultRouterLinkLayerReachabilityInfoEP18ifnet_llreach_info` | `asm/ZN25IOSkywalkNetworkInterface45getIPv6DefaultRouterLinkLayerReachabilityInfoEP18ifnet_llreach_info.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff8002983436` | 12 | `__ZN25IOSkywalkNetworkInterface25getKeepAliveOffloadFramesEP29ifnet_keepalive_offload_framejmPj` | `asm/ZN25IOSkywalkNetworkInterface25getKeepAliveOffloadFramesEP29ifnet_keepalive_offload_framejmPj.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff8002983458` | 31 | `__ZN25IOSkywalkNetworkInterface14deferBSDAttachEb` | `asm/ZN25IOSkywalkNetworkInterface14deferBSDAttachEb.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff80029834b8` | 16 | `__ZN25IOSkywalkNetworkInterface22getInterfaceStatisticsEP17ifnet_stats_param` | `asm/ZN25IOSkywalkNetworkInterface22getInterfaceStatisticsEP17ifnet_stats_param.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff80029834e6` | 52 | `__ZN25IOSkywalkNetworkInterface40addHardwareCountsWithInterfaceStatisticsEPK27IOUserNetworkHardwareCounts` | `asm/ZN25IOSkywalkNetworkInterface40addHardwareCountsWithInterfaceStatisticsEPK27IOUserNetworkHardwareCounts.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff80029835aa` | 62 | `__ZN25IOSkywalkNetworkInterface28isLinkLocalAddressConfiguredEv` | `asm/ZN25IOSkywalkNetworkInterface28isLinkLocalAddressConfiguredEv.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff800298366e` | 31 | `__ZN25IOSkywalkNetworkInterface24reportDetailedLinkStatusEPK14if_link_status` | `asm/ZN25IOSkywalkNetworkInterface24reportDetailedLinkStatusEPK14if_link_status.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff80029836c6` | 6 | `__ZN25IOSkywalkNetworkInterface13getTSOOptionsEPNS_19IOSkywalkTSOOptionsE` | `asm/ZN25IOSkywalkNetworkInterface13getTSOOptionsEPNS_19IOSkywalkTSOOptionsE.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff80029836d2` | 7 | `__ZN25IOSkywalkNetworkInterface35_RESERVEDIOSkywalkNetworkInterface0Ev` | `asm/ZN25IOSkywalkNetworkInterface35_RESERVEDIOSkywalkNetworkInterface0Ev.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff80029836e6` | 6 | `__ZN25IOSkywalkNetworkInterface35_RESERVEDIOSkywalkNetworkInterface1Ev` | `asm/ZN25IOSkywalkNetworkInterface35_RESERVEDIOSkywalkNetworkInterface1Ev.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff80029836fc` | 6 | `__ZN25IOSkywalkNetworkInterface35_RESERVEDIOSkywalkNetworkInterface2Ev` | `asm/ZN25IOSkywalkNetworkInterface35_RESERVEDIOSkywalkNetworkInterface2Ev.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff8002983712` | 6 | `__ZN25IOSkywalkNetworkInterface35_RESERVEDIOSkywalkNetworkInterface3Ev` | `asm/ZN25IOSkywalkNetworkInterface35_RESERVEDIOSkywalkNetworkInterface3Ev.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff8002983728` | 6 | `__ZN25IOSkywalkNetworkInterface35_RESERVEDIOSkywalkNetworkInterface4Ev` | `asm/ZN25IOSkywalkNetworkInterface35_RESERVEDIOSkywalkNetworkInterface4Ev.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff800298373e` | 6 | `__ZN25IOSkywalkNetworkInterface35_RESERVEDIOSkywalkNetworkInterface5Ev` | `asm/ZN25IOSkywalkNetworkInterface35_RESERVEDIOSkywalkNetworkInterface5Ev.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff8002983754` | 6 | `__ZN25IOSkywalkNetworkInterface35_RESERVEDIOSkywalkNetworkInterface6Ev` | `asm/ZN25IOSkywalkNetworkInterface35_RESERVEDIOSkywalkNetworkInterface6Ev.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff800298376a` | 6 | `__ZN25IOSkywalkNetworkInterface35_RESERVEDIOSkywalkNetworkInterface7Ev` | `asm/ZN25IOSkywalkNetworkInterface35_RESERVEDIOSkywalkNetworkInterface7Ev.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff8002983780` | 6 | `__ZN25IOSkywalkNetworkInterface35_RESERVEDIOSkywalkNetworkInterface8Ev` | `asm/ZN25IOSkywalkNetworkInterface35_RESERVEDIOSkywalkNetworkInterface8Ev.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff8002983796` | 6 | `__ZN25IOSkywalkNetworkInterface35_RESERVEDIOSkywalkNetworkInterface9Ev` | `asm/ZN25IOSkywalkNetworkInterface35_RESERVEDIOSkywalkNetworkInterface9Ev.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff80029837ac` | 4 | `__ZN25IOSkywalkNetworkInterface9MetaClassD0Ev` | `asm/ZN25IOSkywalkNetworkInterface9MetaClassD0Ev.asm.txt` |
| `IOSkywalkEthernetInterface` | `0xffffff8002987c24` | 15 | `__ZN26IOSkywalkEthernetInterface9MetaClassC1Ev` | `asm/ZN26IOSkywalkEthernetInterface9MetaClassC1Ev.asm.txt` |
| `IOSkywalkEthernetInterface` | `0xffffff8002987c56` | 4 | `__ZN26IOSkywalkEthernetInterface9MetaClassD1Ev` | `asm/ZN26IOSkywalkEthernetInterface9MetaClassD1Ev.asm.txt` |
| `IOSkywalkEthernetInterface` | `0xffffff8002987c60` | 16 | `__ZN26IOSkywalkEthernetInterfaceC2EPK11OSMetaClass` | `asm/ZN26IOSkywalkEthernetInterfaceC2EPK11OSMetaClass.asm.txt` |
| `IOSkywalkEthernetInterface` | `0xffffff8002987c90` | 16 | `__ZN26IOSkywalkEthernetInterfaceC1EPK11OSMetaClass` | `asm/ZN26IOSkywalkEthernetInterfaceC1EPK11OSMetaClass.asm.txt` |
| `IOSkywalkEthernetInterface` | `0xffffff8002987cc0` | 25 | `__ZN26IOSkywalkEthernetInterfaceD2Ev` | `asm/ZN26IOSkywalkEthernetInterfaceD2Ev.asm.txt` |
| `IOSkywalkEthernetInterface` | `0xffffff8002987d1c` | 25 | `__ZN26IOSkywalkEthernetInterfaceD1Ev` | `asm/ZN26IOSkywalkEthernetInterfaceD1Ev.asm.txt` |
| `IOSkywalkEthernetInterface` | `0xffffff8002987d78` | 13 | `__ZN26IOSkywalkEthernetInterfaceD0Ev` | `asm/ZN26IOSkywalkEthernetInterfaceD0Ev.asm.txt` |
| `IOSkywalkEthernetInterface` | `0xffffff8002987da0` | 8 | `__ZN26IOSkywalkEthernetInterfacedlEPvm` | `asm/ZN26IOSkywalkEthernetInterfacedlEPvm.asm.txt` |
| `IOSkywalkEthernetInterface` | `0xffffff8002987db8` | 6 | `__ZNK26IOSkywalkEthernetInterface12getMetaClassEv` | `asm/ZNK26IOSkywalkEthernetInterface12getMetaClassEv.asm.txt` |
| `IOSkywalkEthernetInterface` | `0xffffff8002987dc6` | 15 | `__ZN26IOSkywalkEthernetInterface9MetaClassC2Ev` | `asm/ZN26IOSkywalkEthernetInterface9MetaClassC2Ev.asm.txt` |
| `IOSkywalkEthernetInterface` | `0xffffff8002987df8` | 5 | `__ZNK26IOSkywalkEthernetInterface9MetaClass5allocEv` | `asm/ZNK26IOSkywalkEthernetInterface9MetaClass5allocEv.asm.txt` |
| `IOSkywalkEthernetInterface` | `0xffffff8002987e00` | 6 | `__ZN26IOSkywalkEthernetInterfacenwEm` | `asm/ZN26IOSkywalkEthernetInterfacenwEm.asm.txt` |
| `IOSkywalkEthernetInterface` | `0xffffff8002987e14` | 20 | `__ZN26IOSkywalkEthernetInterface4initEP12OSDictionary` | `asm/ZN26IOSkywalkEthernetInterface4initEP12OSDictionary.asm.txt` |
| `IOSkywalkEthernetInterface` | `0xffffff8002987e52` | 32 | `__ZN26IOSkywalkEthernetInterface4freeEv` | `asm/ZN26IOSkywalkEthernetInterface4freeEv.asm.txt` |
| `IOSkywalkEthernetInterface` | `0xffffff8002987ed6` | 71 | `__ZN26IOSkywalkEthernetInterface20initRegistrationInfoEPNS_16RegistrationInfoEjm` | `asm/ZN26IOSkywalkEthernetInterface20initRegistrationInfoEPNS_16RegistrationInfoEjm.asm.txt` |
| `IOSkywalkEthernetInterface` | `0xffffff8002987fe4` | 41 | `__ZN26IOSkywalkEthernetInterface20copyRegistrationInfoEPKNS_16RegistrationInfoE` | `asm/ZN26IOSkywalkEthernetInterface20copyRegistrationInfoEPKNS_16RegistrationInfoE.asm.txt` |
| `IOSkywalkEthernetInterface` | `0xffffff8002988078` | 40 | `__ZN26IOSkywalkEthernetInterface25registerEthernetInterfaceEPKNS_16RegistrationInfoEPP20IOSkywalkPacketQueuejP25IOSkywalkPacketBufferPoolS7_j` | `asm/ZN26IOSkywalkEthernetInterface25registerEthernetInterfaceEPKNS_16RegistrationInfoEPP20IOSkywalkPacketQueuejP25IOSkywalkPacketBufferPoolS7_j.asm.txt` |
| `IOSkywalkEthernetInterface` | `0xffffff80029880e8` | 28 | `__ZN26IOSkywalkEthernetInterface27deregisterEthernetInterfaceEj` | `asm/ZN26IOSkywalkEthernetInterface27deregisterEthernetInterfaceEj.asm.txt` |
| `IOSkywalkEthernetInterface` | `0xffffff800298813a` | 44 | `__ZN26IOSkywalkEthernetInterface25registerEthernetInterfaceEPKNS_16RegistrationInfoEP20IOSkywalkLogicalLinkP25IOSkywalkPacketBufferPoolS6_j` | `asm/ZN26IOSkywalkEthernetInterface25registerEthernetInterfaceEPKNS_16RegistrationInfoEP20IOSkywalkLogicalLinkP25IOSkywalkPacketBufferPoolS6_j.asm.txt` |
| `IOSkywalkEthernetInterface` | `0xffffff80029881aa` | 7 | `__ZN26IOSkywalkEthernetInterface16getPacketTapInfoEPjS0_` | `asm/ZN26IOSkywalkEthernetInterface16getPacketTapInfoEPjS0_.asm.txt` |
| `IOSkywalkEthernetInterface` | `0xffffff80029881be` | 84 | `__ZN26IOSkywalkEthernetInterface26initBSDInterfaceParametersEP18ifnet_init_eparamsPP11sockaddr_dl` | `asm/ZN26IOSkywalkEthernetInterface26initBSDInterfaceParametersEP18ifnet_init_eparamsPP11sockaddr_dl.asm.txt` |
| `IOSkywalkEthernetInterface` | `0xffffff8002988334` | 21 | `__ZN26IOSkywalkEthernetInterface18getHardwareAddressEP10ether_addr` | `asm/ZN26IOSkywalkEthernetInterface18getHardwareAddressEP10ether_addr.asm.txt` |
| `IOSkywalkEthernetInterface` | `0xffffff800298837e` | 6 | `__ZN26IOSkywalkEthernetInterface18setHardwareAddressEP10ether_addr` | `asm/ZN26IOSkywalkEthernetInterface18setHardwareAddressEP10ether_addr.asm.txt` |
| `IOSkywalkEthernetInterface` | `0xffffff800298838a` | 10 | `__ZN26IOSkywalkEthernetInterface18getInterfaceFamilyEv` | `asm/ZN26IOSkywalkEthernetInterface18getInterfaceFamilyEv.asm.txt` |
| `IOSkywalkEthernetInterface` | `0xffffff80029883a8` | 5 | `__ZN26IOSkywalkEthernetInterface21getInterfaceSubFamilyEv` | `asm/ZN26IOSkywalkEthernetInterface21getInterfaceSubFamilyEv.asm.txt` |
| `IOSkywalkEthernetInterface` | `0xffffff80029883ba` | 10 | `__ZN26IOSkywalkEthernetInterface15getInitialMediaEv` | `asm/ZN26IOSkywalkEthernetInterface15getInitialMediaEv.asm.txt` |
| `IOSkywalkEthernetInterface` | `0xffffff80029883d8` | 42 | `__ZN26IOSkywalkEthernetInterface19setLinkLayerAddressEP10ether_addr` | `asm/ZN26IOSkywalkEthernetInterface19setLinkLayerAddressEP10ether_addr.asm.txt` |
| `IOSkywalkEthernetInterface` | `0xffffff8002988454` | 123 | `__ZN26IOSkywalkEthernetInterface19prepareBSDInterfaceEP7__ifnetj` | `asm/ZN26IOSkywalkEthernetInterface19prepareBSDInterfaceEP7__ifnetj.asm.txt` |
| `IOSkywalkEthernetInterface` | `0xffffff8002988628` | 31 | `__ZN26IOSkywalkEthernetInterface17processBSDCommandEP7__ifnetjPv` | `asm/ZN26IOSkywalkEthernetInterface17processBSDCommandEP7__ifnetjPv.asm.txt` |
| `IOSkywalkEthernetInterface` | `0xffffff800298868c` | 69 | `__ZN26IOSkywalkEthernetInterface14ioctl_sifflagsEP7__ifnet` | `asm/ZN26IOSkywalkEthernetInterface14ioctl_sifflagsEP7__ifnet.asm.txt` |
| `IOSkywalkEthernetInterface` | `0xffffff8002988766` | 168 | `__ZN26IOSkywalkEthernetInterface15ioctl_multicastEP7__ifnetb` | `asm/ZN26IOSkywalkEthernetInterface15ioctl_multicastEP7__ifnetb.asm.txt` |
| `IOSkywalkEthernetInterface` | `0xffffff80029889ea` | 78 | `__ZN26IOSkywalkEthernetInterface12ioctl_lladdrEP7__ifnetPv` | `asm/ZN26IOSkywalkEthernetInterface12ioctl_lladdrEP7__ifnetPv.asm.txt` |
| `IOSkywalkEthernetInterface` | `0xffffff8002988af8` | 42 | `__ZN26IOSkywalkEthernetInterface6enableEj` | `asm/ZN26IOSkywalkEthernetInterface6enableEj.asm.txt` |
| `IOSkywalkEthernetInterface` | `0xffffff8002988b7e` | 6 | `__ZN26IOSkywalkEthernetInterface24setPromiscuousModeEnableEbj` | `asm/ZN26IOSkywalkEthernetInterface24setPromiscuousModeEnableEbj.asm.txt` |
| `IOSkywalkEthernetInterface` | `0xffffff8002988b8a` | 64 | `__ZN26IOSkywalkEthernetInterface24configureMulticastFilterEjPK10ether_addrj` | `asm/ZN26IOSkywalkEthernetInterface24configureMulticastFilterEjPK10ether_addrj.asm.txt` |
| `IOSkywalkEthernetInterface` | `0xffffff8002988c5c` | 6 | `__ZN26IOSkywalkEthernetInterface21setMulticastAddressesEPK10ether_addrj` | `asm/ZN26IOSkywalkEthernetInterface21setMulticastAddressesEPK10ether_addrj.asm.txt` |
| `IOSkywalkEthernetInterface` | `0xffffff8002988c68` | 6 | `__ZN26IOSkywalkEthernetInterface25setAllMulticastModeEnableEb` | `asm/ZN26IOSkywalkEthernetInterface25setAllMulticastModeEnableEb.asm.txt` |
| `IOSkywalkEthernetInterface` | `0xffffff8002988c74` | 79 | `__ZN26IOSkywalkEthernetInterface13newUserClientEP4taskPvjP12OSDictionaryPP12IOUserClient` | `asm/ZN26IOSkywalkEthernetInterface13newUserClientEP4taskPvjP12OSDictionaryPP12IOUserClient.asm.txt` |
| `IOSkywalkEthernetInterface` | `0xffffff8002988d6a` | 15 | `__ZN26IOSkywalkEthernetInterface16nicProxyCallbackEP21mDNSOffloadUserClientP11mDNSHandoffPv` | `asm/ZN26IOSkywalkEthernetInterface16nicProxyCallbackEP21mDNSOffloadUserClientP11mDNSHandoffPv.asm.txt` |
| `IOSkywalkEthernetInterface` | `0xffffff8002988d8e` | 57 | `__ZN26IOSkywalkEthernetInterface12initNicProxyEm` | `asm/ZN26IOSkywalkEthernetInterface12initNicProxyEm.asm.txt` |
| `IOSkywalkEthernetInterface` | `0xffffff8002988e5e` | 28 | `__ZN26IOSkywalkEthernetInterface12freeNicProxyEv` | `asm/ZN26IOSkywalkEthernetInterface12freeNicProxyEv.asm.txt` |
| `IOSkywalkEthernetInterface` | `0xffffff8002988ec2` | 116 | `__ZN26IOSkywalkEthernetInterface15updateKeepAliveEv` | `asm/ZN26IOSkywalkEthernetInterface15updateKeepAliveEv.asm.txt` |
| `IOSkywalkEthernetInterface` | `0xffffff8002989078` | 389 | `__ZN26IOSkywalkEthernetInterface25mdns_handoff_to_nic_proxyEP11mDNSHandoff` | `asm/ZN26IOSkywalkEthernetInterface25mdns_handoff_to_nic_proxyEP11mDNSHandoff.asm.txt` |
| `IOSkywalkEthernetInterface` | `0xffffff800298961c` | 33 | `__ZN26IOSkywalkEthernetInterface16inet_mask_to_lenEPhm` | `asm/ZN26IOSkywalkEthernetInterface16inet_mask_to_lenEPhm.asm.txt` |
| `IOSkywalkEthernetInterface` | `0xffffff8002989668` | 28 | `__ZN26IOSkywalkEthernetInterface8print_rrEmP18nicproxy_rr_info_s` | `asm/ZN26IOSkywalkEthernetInterface8print_rrEmP18nicproxy_rr_info_s.asm.txt` |
| `IOSkywalkEthernetInterface` | `0xffffff80029896ae` | 31 | `__ZN26IOSkywalkEthernetInterface20reportNicProxyLimitsE22nicproxy_limits_info_s` | `asm/ZN26IOSkywalkEthernetInterface20reportNicProxyLimitsE22nicproxy_limits_info_s.asm.txt` |
| `IOSkywalkEthernetInterface` | `0xffffff8002989726` | 49 | `__ZN26IOSkywalkEthernetInterface17enableNetworkWakeEj` | `asm/ZN26IOSkywalkEthernetInterface17enableNetworkWakeEj.asm.txt` |
| `IOSkywalkEthernetInterface` | `0xffffff80029897c4` | 47 | `__ZN26IOSkywalkEthernetInterface13setPowerStateEmP9IOService` | `asm/ZN26IOSkywalkEthernetInterface13setPowerStateEmP9IOService.asm.txt` |
| `IOSkywalkEthernetInterface` | `0xffffff8002989864` | 4 | `__ZN26IOSkywalkEthernetInterface20hwConfigNicProxyDataEP15nicproxy_info_s` | `asm/ZN26IOSkywalkEthernetInterface20hwConfigNicProxyDataEP15nicproxy_info_s.asm.txt` |
| `IOSkywalkEthernetInterface` | `0xffffff800298986a` | 10 | `__ZN26IOSkywalkEthernetInterface18getMaxTransferUnitEv` | `asm/ZN26IOSkywalkEthernetInterface18getMaxTransferUnitEv.asm.txt` |
| `IOSkywalkEthernetInterface` | `0xffffff8002989888` | 10 | `__ZN26IOSkywalkEthernetInterface16getMinPacketSizeEv` | `asm/ZN26IOSkywalkEthernetInterface16getMinPacketSizeEv.asm.txt` |
| `IOSkywalkEthernetInterface` | `0xffffff80029898a6` | 10 | `__ZN26IOSkywalkEthernetInterface16getBSDNamePrefixEv` | `asm/ZN26IOSkywalkEthernetInterface16getBSDNamePrefixEv.asm.txt` |
| `IOSkywalkEthernetInterface` | `0xffffff80029898c8` | 7 | `__ZN26IOSkywalkEthernetInterface36_RESERVEDIOSkywalkEthernetInterface0Ev` | `asm/ZN26IOSkywalkEthernetInterface36_RESERVEDIOSkywalkEthernetInterface0Ev.asm.txt` |
| `IOSkywalkEthernetInterface` | `0xffffff80029898dc` | 6 | `__ZN26IOSkywalkEthernetInterface36_RESERVEDIOSkywalkEthernetInterface1Ev` | `asm/ZN26IOSkywalkEthernetInterface36_RESERVEDIOSkywalkEthernetInterface1Ev.asm.txt` |
| `IOSkywalkEthernetInterface` | `0xffffff80029898f2` | 6 | `__ZN26IOSkywalkEthernetInterface36_RESERVEDIOSkywalkEthernetInterface2Ev` | `asm/ZN26IOSkywalkEthernetInterface36_RESERVEDIOSkywalkEthernetInterface2Ev.asm.txt` |
| `IOSkywalkEthernetInterface` | `0xffffff8002989908` | 6 | `__ZN26IOSkywalkEthernetInterface36_RESERVEDIOSkywalkEthernetInterface3Ev` | `asm/ZN26IOSkywalkEthernetInterface36_RESERVEDIOSkywalkEthernetInterface3Ev.asm.txt` |
| `IOSkywalkEthernetInterface` | `0xffffff800298991e` | 6 | `__ZN26IOSkywalkEthernetInterface36_RESERVEDIOSkywalkEthernetInterface4Ev` | `asm/ZN26IOSkywalkEthernetInterface36_RESERVEDIOSkywalkEthernetInterface4Ev.asm.txt` |
| `IOSkywalkEthernetInterface` | `0xffffff8002989934` | 6 | `__ZN26IOSkywalkEthernetInterface36_RESERVEDIOSkywalkEthernetInterface5Ev` | `asm/ZN26IOSkywalkEthernetInterface36_RESERVEDIOSkywalkEthernetInterface5Ev.asm.txt` |
| `IOSkywalkEthernetInterface` | `0xffffff800298994a` | 6 | `__ZN26IOSkywalkEthernetInterface36_RESERVEDIOSkywalkEthernetInterface6Ev` | `asm/ZN26IOSkywalkEthernetInterface36_RESERVEDIOSkywalkEthernetInterface6Ev.asm.txt` |
| `IOSkywalkEthernetInterface` | `0xffffff8002989960` | 6 | `__ZN26IOSkywalkEthernetInterface36_RESERVEDIOSkywalkEthernetInterface7Ev` | `asm/ZN26IOSkywalkEthernetInterface36_RESERVEDIOSkywalkEthernetInterface7Ev.asm.txt` |
| `IOSkywalkEthernetInterface` | `0xffffff8002989976` | 6 | `__ZN26IOSkywalkEthernetInterface36_RESERVEDIOSkywalkEthernetInterface8Ev` | `asm/ZN26IOSkywalkEthernetInterface36_RESERVEDIOSkywalkEthernetInterface8Ev.asm.txt` |
| `IOSkywalkEthernetInterface` | `0xffffff800298998c` | 6 | `__ZN26IOSkywalkEthernetInterface36_RESERVEDIOSkywalkEthernetInterface9Ev` | `asm/ZN26IOSkywalkEthernetInterface36_RESERVEDIOSkywalkEthernetInterface9Ev.asm.txt` |
| `IOSkywalkEthernetInterface` | `0xffffff80029899a2` | 6 | `__ZN26IOSkywalkEthernetInterface37_RESERVEDIOSkywalkEthernetInterface10Ev` | `asm/ZN26IOSkywalkEthernetInterface37_RESERVEDIOSkywalkEthernetInterface10Ev.asm.txt` |
| `IOSkywalkEthernetInterface` | `0xffffff80029899b8` | 4 | `__ZN26IOSkywalkEthernetInterface9MetaClassD0Ev` | `asm/ZN26IOSkywalkEthernetInterface9MetaClassD0Ev.asm.txt` |
| `IOSkywalkEthernetInterface` | `0xffffff80029a39ae` | 6 | `__ZN26IOSkywalkEthernetInterface8print_rrEmP18nicproxy_rr_info_s.cold.1` | `asm/ZN26IOSkywalkEthernetInterface8print_rrEmP18nicproxy_rr_info_s.cold.1.asm.txt` |

### Source evidence snippets

**RTW88WCLSkywalkQueues.cpp:1-8**

```cpp
    1: /* SPDX-License-Identifier: GPL-2.0-only
    2:  * Sequoia 24H32 Skywalk queue and packet-pool resource owner.
    3:  */
    4: #include "RTW88WCLSkywalkQueues.hpp"
    5: #include "RTW88WCLPacketView.hpp"
    6: 
    7: #include <IOKit/IOLib.h>
    8: #include <libkern/c++/OSMetaClass.h>
```

**RTW88WCLSkywalkQueues.cpp:15-25**

```cpp
   15:     using PoolOptions = IOSkywalkPacketBufferPool::PoolOptions;
   16: };
   17: 
   18: #define super OSObject
   19: OSDefineMetaClassAndStructors(RTW88WCLSkywalkQueues, OSObject)
   20: 
   21: bool RTW88WCLSkywalkQueues::init()
   22: {
   23:     if (!super::init())
   24:         return false;
   25:     _txPool = nullptr;
```

**RTW88WCLSkywalkQueues.cpp:31-58**

```cpp
   31:     _allocated = false;
   32:     return true;
   33: }
   34: 
   35: IOReturn RTW88WCLSkywalkQueues::createQueues()
   36: {
   37:     if (_allocated)
   38:         return kIOReturnSuccess;
   39:     if (_txPool || _rxPool || _txSubmission || _txCompletion ||
   40:         _rxSubmission || _rxCompletion)
   41:         return kIOReturnBusy;
   42: 
   43:     RTW88WCLPoolOptionsAccess::PoolOptions txOptions = {};
   44:     txOptions.packetCount = kQueueCapacity;
   45:     txOptions.bufferCount = kQueueCapacity;
   46:     txOptions.bufferSize = kTxBufferSize;
   47:     txOptions.maxBuffersPerPacket = 1;
   48:     txOptions.memorySegmentSize = kQueueCapacity * kTxBufferSize;
   49:     txOptions.poolFlags = 0;
   50:     txOptions._reserved = 0;
   51: 
   52:     RTW88WCLPoolOptionsAccess::PoolOptions rxOptions = txOptions;
   53:     rxOptions.bufferSize = kRxBufferSize;
   54:     rxOptions.memorySegmentSize = kQueueCapacity * kRxBufferSize;
   55: 
   56:     _txPool = IOSkywalkPacketBufferPool::withName(
   57:         "RTL88WiFi-WCL-TX", this, kIOSkywalkPacketTypeNetwork, &txOptions);
   58:     if (!_txPool)
```

**RTW88WCLSkywalkQueues.cpp:62-156**

```cpp
   62:         "RTL88WiFi-WCL-RX", this, kIOSkywalkPacketTypeNetwork, &rxOptions);
   63:     if (!_rxPool)
   64:         goto no_memory;
   65: 
   66:     /* These queue objects are deliberately not added to an IOWorkLoop and
   67:      * are not passed to registerEthernetInterface() yet. Skywalk owns their
   68:      * scheduling and packet lifetime only after a complete RegistrationInfo
   69:      * + ring setup transaction, which is a later stage. */
   70:     _txSubmission = IOSkywalkTxSubmissionQueue::withPool(
   71:         _txPool, kQueueCapacity, 0, this,
   72:         &RTW88WCLSkywalkQueues::txSubmissionAction, this, 0);
   73:     if (!_txSubmission)
   74:         goto no_memory;
   75: 
   76:     _txCompletion = IOSkywalkTxCompletionQueue::withPool(
   77:         _txPool, kQueueCapacity, 0, this,
   78:         &RTW88WCLSkywalkQueues::txCompletionAction, this, 0);
   79:     if (!_txCompletion)
   80:         goto no_memory;
   81: 
   82:     _rxSubmission = IOSkywalkRxSubmissionQueue::withPool(
   83:         _rxPool, kQueueCapacity, 0, static_cast<kern_packet_svc_class_t>(0),
   84:         this, &RTW88WCLSkywalkQueues::rxSubmissionAction, this, 0);
   85:     if (!_rxSubmission)
   86:         goto no_memory;
   87: 
   88:     _rxCompletion = IOSkywalkRxCompletionQueue::withPool(
   89:         _rxPool, kQueueCapacity, 0, this,
   90:         &RTW88WCLSkywalkQueues::rxCompletionAction, this, 0);
   91:     if (!_rxCompletion)
   92:         goto no_memory;
   93: 
   94:     _allocated = true;
   95:     IOLog("rtl88wifi-wcl: allocated Skywalk pools and four queue objects (not registered)\n");
   96:     return kIOReturnSuccess;
   97: 
   98: no_memory:
   99:     destroyQueues();
  100:     return kIOReturnNoMemory;
  101: }
  102: 
  103: void RTW88WCLSkywalkQueues::destroyQueues()
  104: {
  105:     /* Release queues before their pools: queue implementations retain and
  106:      * reference their associated pool for packet and buffer accounting. */
  107:     if (_rxCompletion) {
  108:         _rxCompletion->release();
  109:         _rxCompletion = nullptr;
  110:     }
  111:     if (_rxSubmission) {
  112:         _rxSubmission->release();
  113:         _rxSubmission = nullptr;
  114:     }
  115:     if (_txCompletion) {
  116:         _txCompletion->release();
  117:         _txCompletion = nullptr;
  118:     }
  119:     if (_txSubmission) {
  120:         _txSubmission->release();
  121:         _txSubmission = nullptr;
  122:     }
  123:     if (_rxPool) {
  124:         _rxPool->release();
  125:         _rxPool = nullptr;
  126:     }
  127:     if (_txPool) {
  128:         _txPool->release();
  129:         _txPool = nullptr;
  130:     }
  131:     _allocated = false;
  132: }
  133: 
  134: bool RTW88WCLSkywalkQueues::queuesAllocated() const
  135: {
  136:     return _allocated && _txPool && _rxPool && _txSubmission &&
  137:            _txCompletion && _rxSubmission && _rxCompletion;
  138: }
  139: 
  140: IOReturn RTW88WCLSkywalkQueues::txSubmissionAction(
  141:     OSObject *owner, IOSkywalkTxSubmissionQueue *queue,
  142:     const IOSkywalkPacket **packets, UInt32 packetCount, void *refCon)
  143: {
  144:     (void)refCon;
  145:     auto *self = OSDynamicCast(RTW88WCLSkywalkQueues, owner);
  146:     if (!self || queue != self->_txSubmission || !packets || packetCount == 0)
  147:         return kIOReturnBadArgument;
  148: 
  149:     /* Validate every descriptor before a future TX path is allowed to copy
  150:      * bytes or hand ownership to RTW88. The callback remains fail-closed:
  151:      * a validated packet is not yet accepted until its hardware completion
  152:      * cookie is connected to the native completion queue. */
  153:     for (UInt32 i = 0; i < packetCount; ++i) {
  154:         if (!packets[i])
  155:             return kIOReturnBadArgument;
  156:         RTW88WCLPacketView view = {};
```

**RTW88WCLSkywalkQueues.cpp:161-194**

```cpp
  161: 
  162:     return kIOReturnNotReady;
  163: }
  164: 
  165: IOReturn RTW88WCLSkywalkQueues::txCompletionAction(
  166:     OSObject *owner, IOSkywalkTxCompletionQueue *queue,
  167:     IOSkywalkPacket **packets, UInt32 packetCount, void *refCon)
  168: {
  169:     (void)owner; (void)queue; (void)packets; (void)packetCount; (void)refCon;
  170:     return kIOReturnNotReady;
  171: }
  172: 
  173: IOReturn RTW88WCLSkywalkQueues::rxSubmissionAction(
  174:     OSObject *owner, IOSkywalkRxSubmissionQueue *queue,
  175:     const IOSkywalkPacket **packets, UInt32 packetCount, void *refCon)
  176: {
  177:     (void)owner; (void)queue; (void)packets; (void)packetCount; (void)refCon;
  178:     /* RX buffer ownership/refill is intentionally not accepted yet. */
  179:     return kIOReturnNotReady;
  180: }
  181: 
  182: IOReturn RTW88WCLSkywalkQueues::rxCompletionAction(
  183:     OSObject *owner, IOSkywalkRxCompletionQueue *queue,
  184:     IOSkywalkPacket **packets, UInt32 packetCount, void *refCon)
  185: {
  186:     (void)owner; (void)queue; (void)packets; (void)packetCount; (void)refCon;
  187:     return kIOReturnNotReady;
  188: }
  189: 
  190: void RTW88WCLSkywalkQueues::free()
  191: {
  192:     destroyQueues();
  193:     super::free();
  194: }
```

**RTW88WCLController.cpp:2-17**

```cpp
    2:  * Sequoia 24H32 native IO80211Controller with staged backend ownership.
    3:  */
    4: #include "RTW88WCLController.hpp"
    5: #include "RTW88WCL24H32InterfaceABI.hpp"
    6: #include "RTW88WCLSkywalkQueues.hpp"
    7: #include "RTW88WCLSkywalkRxAdapter.hpp"
    8: #include "../RTW88IEEE80211.hpp"
    9: 
   10: #include <IOKit/pci/IOPCIDevice.h>
   11: 
   12: #include <IOKit/IOLib.h>
   13: #include <IOKit/network/IOOutputQueue.h>
   14: #include <libkern/c++/OSMetaClass.h>
   15: 
   16: #define super IO80211Controller
   17: OSDefineMetaClassAndStructors(RTW88WCLController, IO80211Controller)
```

**RTW88WCLController.cpp:24-32**

```cpp
   24:     _packetPathInterface = nullptr;
   25:     _packetPathState = kPacketPathDisabled;
   26:     _packetPathInFlight = 0;
   27:     _pciBackend = nullptr;
   28:     _skywalkQueues = nullptr;
   29:     _rxAdapter = nullptr;
   30:     _stagedRxPackets.reset();
   31:     _radio = nullptr;
   32:     _baseStarted = false;
```

**RTW88WCLController.cpp:46-63**

```cpp
   46: {
   47:     return _workLoop;
   48: }
   49: 
   50: bool RTW88WCLController::start(IOService *provider)
   51: {
   52:     if (!provider || _baseStarted || _pciBackend || _radio)
   53:         return false;
   54:     if (!super::start(provider))
   55:         return false;
   56:     _baseStarted = true;
   57: 
   58:     /* Stage A: the controller workloop must exist before acquiring a PCI
   59:      * backend or registering any interrupt source. */
   60:     if (!createWorkLoop()) {
   61:         IOLog("rtl88wifi-wcl: controller workloop creation failed\n");
   62:         goto fail;
   63:     }
```

**RTW88WCLController.cpp:76-84**

```cpp
   76:             IOLog("rtl88wifi-wcl: PCI backend allocation failed\n");
   77:             goto fail;
   78:         }
   79:         if (!_pciBackend->init()) {
   80:             _pciBackend->release();
   81:             _pciBackend = nullptr;
   82:             IOLog("rtl88wifi-wcl: PCI backend initialization failed\n");
   83:             goto fail;
   84:         }
```

**RTW88WCLController.cpp:104-137**

```cpp
  104:             goto fail;
  105:         }
  106:         radio->setEventDelegate(this);
  107:         const IOReturn bindStatus = bindRadioBackend(radio);
  108:         radio->release();
  109:         if (bindStatus != kIOReturnSuccess) {
  110:             IOLog("rtl88wifi-wcl: RTW88 state-machine bind failed: 0x%08x\n",
  111:                   bindStatus);
  112:             goto fail;
  113:         }
  114:     }
  115: 
  116:     /* Stage D: reserve native Skywalk queue/pool objects while the PCI and
  117:      * RTW88 owners are still available for orderly unwind. These objects are
  118:      * intentionally not registered or scheduled until packet descriptor
  119:      * conversion and hardware completion correlation are implemented. */
  120:     _skywalkQueues = new RTW88WCLSkywalkQueues;
  121:     if (!_skywalkQueues || !_skywalkQueues->init()) {
  122:         if (_skywalkQueues) {
  123:             _skywalkQueues->release();
  124:             _skywalkQueues = nullptr;
  125:         }
  126:         IOLog("rtl88wifi-wcl: Skywalk queue owner allocation failed\n");
  127:         goto fail;
  128:     }
  129:     {
  130:         const IOReturn queueStatus = _skywalkQueues->createQueues();
  131:         if (queueStatus != kIOReturnSuccess) {
  132:             IOLog("rtl88wifi-wcl: Skywalk queue/pool allocation failed: 0x%08x\n",
  133:                   queueStatus);
  134:             goto fail;
  135:         }
  136:     }
  137: 
```

**RTW88WCLController.cpp:139-150**

```cpp
  139:      * It copies frames into native packet buffers, but its sink remains
  140:      * rejecting until the registration/completion ABI is closed. */
  141:     _rxAdapter = new RTW88WCLSkywalkRxAdapter;
  142:     if (!_rxAdapter || !_rxAdapter->init(
  143:             this, _workLoop, _skywalkQueues->rxPacketPool(),
  144:             &RTW88WCLController::stagedRxFrame, this)) {
  145:         if (_rxAdapter) {
  146:             _rxAdapter->release();
  147:             _rxAdapter = nullptr;
  148:         }
  149:         IOLog("rtl88wifi-wcl: RX packet adapter initialization failed\n");
  150:         goto fail;
```

**RTW88WCLController.cpp:161-179**

```cpp
  161: 
  162: fail:
  163:     releaseNativeResources();
  164:     if (_baseStarted) {
  165:         super::stop(provider);
  166:         _baseStarted = false;
  167:     }
  168:     return false;
  169: }
  170: 
  171: void RTW88WCLController::stop(IOService *provider)
  172: {
  173:     releaseNativeResources();
  174:     if (_baseStarted) {
  175:         super::stop(provider);
  176:         _baseStarted = false;
  177:     }
  178: }
  179: 
```

**RTW88WCLController.cpp:188-226**

```cpp
  188: 
  189:     /* Stop the RTW88 RX/TX producer before removing its deferred consumers or
  190:      * disabling PCI interrupts. The staged path currently leaves
  191:      * _radioStarted false; preserve this ordering when native radio start is
  192:      * enabled after queue registration. */
  193:     if (_radio && _radioStarted) {
  194:         _radio->stop();
  195:         _radioStarted = false;
  196:     }
  197: 
  198:     /* Remove the RX workloop source only after the RTW88 producer is stopped.
  199:      * stop() waits out an active checkForWork() and releases all staged mbufs. */
  200:     if (_rxAdapter) {
  201:         _rxAdapter->stop();
  202:         _rxAdapter->release();
  203:         _rxAdapter = nullptr;
  204:     }
  205: 
  206:     /* The RX adapter transfers accepted native packets into the controller's
  207:      * bounded ready ring. Recycle those packets while their pool still exists;
  208:      * on a pool error, retain the queue owner and PCI/backend context so a later
  209:      * stop/free attempt can retry rather than releasing live packet memory. */
  210:     const IOReturn recycleStatus = recycleStagedRxPackets();
  211:     if (recycleStatus != kIOReturnSuccess) {
  212:         IOLog("rtl88wifi-wcl: staged RX packet recycle deferred: 0x%08x\n",
  213:               recycleStatus);
  214:         return;
  215:     }
  216: 
  217:     /* Skywalk packet pools/queues are released only after both the mbuf staging
  218:      * adapter and the prepared-packet ownership ring have been drained. */
  219:     if (_skywalkQueues) {
  220:         _skywalkQueues->destroyQueues();
  221:         _skywalkQueues->release();
  222:         _skywalkQueues = nullptr;
  223:     }
  224: 
  225:     if (_pciBackend && _pciBackend->isRadioRunning()) {
  226:         const IOReturn fenceStatus = _pciBackend->setRadioRunning(false);
```

**RTW88WCLController.cpp:241-249**

```cpp
  241:             IOLog("rtl88wifi-wcl: PCI backend close deferred: 0x%08x\n",
  242:                   closeStatus);
  243:             return;
  244:         }
  245:         _pciBackend->release();
  246:         _pciBackend = nullptr;
  247:     }
  248: }
  249: 
```

**RTW88WCLController.cpp:252-260**

```cpp
  252:     releaseNativeResources();
  253:     if (_pciBackend)
  254:         IOLog("rtl88wifi-wcl: PCI backend retained because shutdown fence did not complete\n");
  255:     if (_workLoop) {
  256:         _workLoop->release();
  257:         _workLoop = nullptr;
  258:     }
  259:     super::free();
  260: }
```

**RTW88WCLController.cpp:435-443**

```cpp
  435: 
  436:     IO80211SkywalkInterface *interface = _packetPathInterface;
  437:     _packetPathInterface = nullptr;
  438:     if (interface)
  439:         interface->release();
  440:     __atomic_store_n(&_packetPathState, kPacketPathDisabled, __ATOMIC_RELEASE);
  441:     return kIOReturnSuccess;
  442: }
  443: 
```

**RTW88WCLController.cpp:460-469**

```cpp
  460: }
  461: 
  462: void RTW88WCLController::rtw88WCLResumeTransmit()
  463: {
  464:     /* RTW88's internal TX queues resume independently. The future Skywalk
  465:      * submission queue will connect its wakeup here after ring registration. */
  466: }
  467: 
  468: void RTW88WCLController::rtw88Event(RTW88Event event, void *data)
  469: {
```

**RTW88WCLController.cpp:494-516**

```cpp
  494:         mbuf_freem(packet);
  495:         return;
  496:     }
  497: 
  498:     /* enqueueFrame consumes the mbuf on both success and failure. The native
  499:      * RX completion queue is not registered yet, so the workloop sink below
  500:      * deliberately drops frames after staging rather than exposing them. */
  501:     (void)_rxAdapter->enqueueFrame(packet);
  502:     leavePacketPath();
  503: }
  504: 
  505: IOReturn RTW88WCLController::recycleStagedRxPackets()
  506: {
  507:     if (_stagedRxPackets.empty())
  508:         return kIOReturnSuccess;
  509:     if (!_skywalkQueues || !_skywalkQueues->rxPacketPool())
  510:         return kIOReturnNotReady;
  511: 
  512:     IOSkywalkPacketBufferPool *pool = _skywalkQueues->rxPacketPool();
  513:     IOSkywalkPacket *packet = nullptr;
  514:     bool disposalRequired = false;
  515:     while (_stagedRxPackets.pop(&packet)) {
  516:         if (!packet)
```

**RTW88WCLController.cpp:518-526**

```cpp
  518: 
  519:         const IOReturn status = pool->deallocatePacket(packet);
  520:         if (status != kIOReturnSuccess) {
  521:             /* The radio and RX event source are already quiesced, and these
  522:              * queues were never registered. If a packet cannot be returned
  523:              * individually, dispose the pool's packet set as one teardown
  524:              * operation before its memory segments are released. */
  525:             IOLog("rtl88wifi-wcl: RX packet recycle returned 0x%08x; pool disposal required\n",
  526:                   status);
```

**RTW88WCLController.cpp:542-551**

```cpp
  542:         return false;
  543: 
  544:     /* Preserve the pool-backed packet in a fixed-capacity owner ring. The
  545:      * ring is bounded to the RX pool's 128 packets; overflow returns false,
  546:      * causing the RX adapter to recycle the packet immediately. No queue API
  547:      * is called here: completion-queue registration/ownership is still fenced. */
  548:     return self->_stagedRxPackets.push(preparedPacket);
  549: }
  550: 
  551: IOWorkLoop *RTW88WCLController::getRxWorkLoop()
```

**RTW88WCLController.cpp:570-577**

```cpp
  570: 
  571: void RTW88WCLController::unbindRadioBackend()
  572: {
  573:     if (_radio) {
  574:         _radio->release();
  575:         _radio = nullptr;
  576:     }
  577: }
```

**RTW88WCLController.hpp:13-21**

```cpp
   13: #include "RTW88WCLMbufRing.hpp"
   14: #include <IOKit/IOWorkLoop.h>
   15: 
   16: class RTW88IEEE80211;
   17: class RTW88WCLSkywalkQueues;
   18: class RTW88WCLSkywalkRxAdapter;
   19: class IOSkywalkPacket;
   20: 
   21: class RTW88WCLController final : public IO80211Controller,
```

**RTW88WCLController.hpp:25-40**

```cpp
   25:     OSDeclareDefaultStructors(RTW88WCLController)
   26: 
   27: public:
   28:     bool init(OSDictionary *properties) override;
   29:     bool start(IOService *provider) override;
   30:     void stop(IOService *provider) override;
   31:     void free() override;
   32:     bool createWorkLoop() override;
   33:     IOWorkLoop *getWorkLoop() const override;
   34: 
   35:     /* Native Ethernet mbuf handoff seam. Skywalk queue callbacks must call these
   36:      * only after their packet rings are registered and the radio is started. */
   37:     UInt32 outputPacket(mbuf_t packet, void *param) override;
   38:     IOReturn activatePacketPath(IO80211SkywalkInterface *interface);
   39:     IOReturn quiescePacketPath();
   40: 
```

**RTW88WCLController.hpp:67-84**

```cpp
   67:     void unbindRadioBackend();
   68:     RTW88IEEE80211 *radioBackend() const { return _radio; }
   69:     RTW88WCLPCIBackend *pciBackend() const { return _pciBackend; }
   70: 
   71:     /* RTW88WCLPCIBackendClient: no native TX queue is registered yet. */
   72:     void rtw88WCLResumeTransmit() override;
   73: 
   74:     /* RTW88EventDelegate: events are deliberately not published until the
   75:      * Skywalk interface has completed registration. */
   76:     void rtw88Event(RTW88Event event, void *data) override;
   77: 
   78:     /* RTW88RxDelegate: receive mbufs enter a bounded workloop staging ring,
   79:      * then become pool-backed Skywalk packets. The sink still rejects them
   80:      * until the RX completion queue is registered and verified. */
   81:     mbuf_t allocateInputPacket(uint32_t length) override;
   82:     void injectRxFrame(mbuf_t packet) override;
   83:     IOWorkLoop *getRxWorkLoop() override;
   84:     void setLinkStatus(UInt32 status) override;
```

**RTW88WCLController.hpp:105-116**

```cpp
  105:     IO80211SkywalkInterface *_packetPathInterface = nullptr; // retained while active
  106:     volatile uint32_t _packetPathState = kPacketPathDisabled;
  107:     volatile uint32_t _packetPathInFlight = 0;
  108:     RTW88WCLPCIBackend *_pciBackend = nullptr; // retained
  109:     RTW88WCLSkywalkQueues *_skywalkQueues = nullptr; // retained, unregistered
  110:     RTW88WCLSkywalkRxAdapter *_rxAdapter = nullptr; // retained, workloop-bound
  111:     /* Accepted RX packets remain pool-owned here until a verified completion
  112:      * queue can consume them. This ring is bounded to the RX pool packet count. */
  113:     RTW88WCLMbufRing<IOSkywalkPacket *, kStagedRxPacketCapacity> _stagedRxPackets;
  114:     RTW88IEEE80211 *_radio = nullptr;          // retained via bindRadioBackend
  115:     bool _baseStarted = false;
  116:     bool _radioStarted = false;
```

**RTW88WCLInfraInterface.cpp:139-149**

```cpp
  139: bool RTW88WCLInfraInterface::init()
  140: {
  141:     if (!super::init())
  142:         return false;
  143:     clearRegistrationInfo();
  144:     _controller = nullptr;
  145:     _workQueue = nullptr;
  146:     _scanFilter = {};
  147:     bzero(_targetBSSID, sizeof(_targetBSSID));
  148:     _scanActive = false;
  149:     _activeScanGeneration = 0;
```

**RTW88WCLInfraInterface.cpp:165-202**

```cpp
  165: 
  166:     if (!IO80211SkywalkInterface::init(provider, address))
  167:         return false;
  168: 
  169:     clearRegistrationInfo();
  170:     return true;
  171: }
  172: 
  173: IOReturn RTW88WCLInfraInterface::attachRadio(RTW88IEEE80211 *radio)
  174: {
  175:     if (!radio || !_controller)
  176:         return kIOReturnBadArgument;
  177:     if (_bridge.isAttached() || _workQueue)
  178:         return kIOReturnBusy;
  179: 
  180:     IOWorkLoop *workLoop = _controller->getWorkLoop();
  181:     if (!workLoop)
  182:         return kIOReturnNotReady;
  183: 
  184:     RTW88WCLWorkQueue *queue = new RTW88WCLWorkQueue;
  185:     if (!queue)
  186:         return kIOReturnNoMemory;
  187:     if (!queue->init(this, workLoop, this)) {
  188:         queue->release();
  189:         return kIOReturnNoResources;
  190:     }
  191: 
  192:     IOReturn status = _bridge.attach(radio, queue);
  193:     if (status != kIOReturnSuccess) {
  194:         queue->stop();
  195:         queue->release();
  196:         return status;
  197:     }
  198:     _workQueue = queue;
  199:     _stopping = false;
  200:     return kIOReturnSuccess;
  201: }
  202: 
```

**RTW88WCLInfraInterface.cpp:205-216**

```cpp
  205:     _stopping = true;
  206:     /* Quiesce the producer first, then remove the work source. The controller
  207:      * must stop the radio before destroying its backend object. */
  208:     _bridge.detach();
  209:     if (_workQueue) {
  210:         _workQueue->stop();
  211:         _workQueue->release();
  212:         _workQueue = nullptr;
  213:     }
  214:     _scanActive = false;
  215:     _activeScanGeneration = 0;
  216:     _activeJoinGeneration = 0;
```

**RTW88WCLInfraInterface.cpp:219-266**

```cpp
  219: }
  220: 
  221: void RTW88WCLInfraInterface::free()
  222: {
  223:     clearRegistrationInfo();
  224:     detachRadio();
  225:     _controller = nullptr;
  226:     super::free();
  227: }
  228: 
  229: void RTW88WCLInfraInterface::clearRegistrationInfo()
  230: {
  231:     RTW88WCLRegistrationInfo24H32::clear(_registrationInfo);
  232:     _registrationInfoPrepared = false;
  233: }
  234: 
  235: bool RTW88WCLInfraInterface::prepareRegistrationInfo(const ether_addr &address)
  236: {
  237:     using namespace RTW88WCLRegistrationInfo24H32;
  238: 
  239:     clearRegistrationInfo();
  240:     auto *info = reinterpret_cast<IOSkywalkEthernetInterface::RegistrationInfo *>(
  241:         _registrationInfo.bytes);
  242: 
  243:     /* 24H32 initRegistrationInfo requires option 1 and the exact 0x130 size.
  244:      * It supplies the other opaque slots through this interface's virtual
  245:      * hooks; do not replace it with a guessed local structure initializer.
  246:      */
  247:     if (!initRegistrationInfo(info, 1, sizeof(_registrationInfo.bytes))) {
  248:         clearRegistrationInfo();
  249:         return false;
  250:     }
  251: 
  252:     if (!applyAppleProducerWrites(_registrationInfo, address.octet) ||
  253:         !matchesApple24H32Template(_registrationInfo, address.octet)) {
  254:         clearRegistrationInfo();
  255:         return false;
  256:     }
  257: 
  258:     _registrationInfoPrepared = true;
  259:     return true;
  260: }
  261: 
  262: bool RTW88WCLInfraInterface::start(IOService *provider)
  263: {
  264:     /* The native controller has not yet completed PCI/DMA ownership transfer,
  265:      * Skywalk registration-info allocation or RX/TX ring registration. Never
  266:      * publish a half-initialized Wi-Fi service. */
```

**RTW88WCLInfraInterface.cpp:270-307**

```cpp
  270:     }
  271:     return false;
  272: }
  273: 
  274: void RTW88WCLInfraInterface::stop(IOService *provider)
  275: {
  276:     clearRegistrationInfo();
  277:     detachRadio();
  278:     if (provider)
  279:         provider->setProperty("RTW88WCLInfraInterfaceStopped", kOSBooleanTrue);
  280:     super::stop(provider);
  281: }
  282: 
  283: IOReturn RTW88WCLInfraInterface::enable(unsigned int options)
  284: {
  285:     (void)options;
  286:     if (_stopping || !_bridge.isAttached() || !_controller)
  287:         return kIOReturnNotReady;
  288: 
  289:     /* Bring the RTW88 station path up first. Only then may the controller's
  290:      * standard mbuf TX hook admit packets for this registered interface. */
  291:     IOReturn status = _bridge.powerOn();
  292:     if (status != kIOReturnSuccess)
  293:         return status;
  294: 
  295:     status = _controller->activatePacketPath(this);
  296:     if (status != kIOReturnSuccess) {
  297:         _bridge.powerOff();
  298:         return status;
  299:     }
  300:     return kIOReturnSuccess;
  301: }
  302: 
  303: IOReturn RTW88WCLInfraInterface::disable(unsigned int options)
  304: {
  305:     (void)options;
  306:     if (!_bridge.isAttached() || !_controller)
  307:         return kIOReturnNotReady;
```

**RTW88WCLInfraInterface.cpp:310-318**

```cpp
  310:      * asking RTW88 to power down. A busy path leaves the radio running. */
  311:     IOReturn status = _controller->quiescePacketPath();
  312:     if (status != kIOReturnSuccess)
  313:         return status;
  314:     return _bridge.powerOff();
  315: }
  316: 
  317: SInt32 RTW88WCLInfraInterface::initBSDInterfaceParameters(
  318:     ifnet_init_eparams *params, sockaddr_dl **address)
```

### Manual questions

- [ ] Which object owns RegistrationInfo and its backing arrays on success?
- [ ] Who releases partially constructed registration state on each failure edge?
- [ ] Does deregistration synchronously quiesce callbacks and release queues?
- [ ] What ordering is required between interface stop, deregistration and pool release?

**Review outcome:** `UNRESOLVED — do not enable this contract`

## queue_enable_synchronize_teardown: Queue enable/disable/synchronize and teardown ordering

**Status:** MANUAL_REVIEW_REQUIRED
**Candidate method bodies:** 306

### Kernel method candidates

| Class | Address | Instructions | Exact symbol | Assembly file |
|---|---:|---:|---|---|
| `IOSkywalkPacketQueue` | `0xffffff800298077a` | 15 | `__ZN20IOSkywalkPacketQueue9MetaClassC1Ev` | `asm/ZN20IOSkywalkPacketQueue9MetaClassC1Ev.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff80029807ac` | 4 | `__ZN20IOSkywalkPacketQueue9MetaClassD1Ev` | `asm/ZN20IOSkywalkPacketQueue9MetaClassD1Ev.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff80029807b6` | 13 | `__ZN20IOSkywalkPacketQueueC2EPK11OSMetaClass` | `asm/ZN20IOSkywalkPacketQueueC2EPK11OSMetaClass.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff80029807d6` | 4 | `__ZN20IOSkywalkPacketQueueD2Ev` | `asm/ZN20IOSkywalkPacketQueueD2Ev.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff80029807e0` | 3 | `__ZN20IOSkywalkPacketQueueD1Ev` | `asm/ZN20IOSkywalkPacketQueueD1Ev.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff80029807e6` | 3 | `__ZN20IOSkywalkPacketQueueD0Ev` | `asm/ZN20IOSkywalkPacketQueueD0Ev.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff80029807ec` | 6 | `__ZNK20IOSkywalkPacketQueue12getMetaClassEv` | `asm/ZNK20IOSkywalkPacketQueue12getMetaClassEv.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff80029807fa` | 15 | `__ZN20IOSkywalkPacketQueue9MetaClassC2Ev` | `asm/ZN20IOSkywalkPacketQueue9MetaClassC2Ev.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff800298082c` | 5 | `__ZNK20IOSkywalkPacketQueue9MetaClass5allocEv` | `asm/ZNK20IOSkywalkPacketQueue9MetaClass5allocEv.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff8002980834` | 6 | `__ZN20IOSkywalkPacketQueuenwEm` | `asm/ZN20IOSkywalkPacketQueuenwEm.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff8002980848` | 8 | `__ZN20IOSkywalkPacketQueuedlEPvm` | `asm/ZN20IOSkywalkPacketQueuedlEPvm.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff8002980860` | 56 | `__ZN20IOSkywalkPacketQueue12initWithPoolEP25IOSkywalkPacketBufferPooljjjjP8OSObjectPFvS3_zEPv` | `asm/ZN20IOSkywalkPacketQueue12initWithPoolEP25IOSkywalkPacketBufferPooljjjjP8OSObjectPFvS3_zEPv.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff800298091a` | 20 | `__ZN20IOSkywalkPacketQueue4freeEv` | `asm/ZN20IOSkywalkPacketQueue4freeEv.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff800298095a` | 54 | `__ZN20IOSkywalkPacketQueue10initializeEPv` | `asm/ZN20IOSkywalkPacketQueue10initializeEPv.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff8002980a20` | 21 | `__ZNK20IOSkywalkPacketQueue12getInterfaceEv` | `asm/ZNK20IOSkywalkPacketQueue12getInterfaceEv.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff8002980a58` | 35 | `__ZN20IOSkywalkPacketQueue8finalizeEv` | `asm/ZN20IOSkywalkPacketQueue8finalizeEv.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff8002980ac0` | 15 | `__ZN20IOSkywalkPacketQueue7disableEv` | `asm/ZN20IOSkywalkPacketQueue7disableEv.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff8002980aee` | 25 | `__ZN20IOSkywalkPacketQueue9resetABFSEv` | `asm/ZN20IOSkywalkPacketQueue9resetABFSEv.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff8002980b44` | 6 | `__ZN20IOSkywalkPacketQueue11synchronizeEj` | `asm/ZN20IOSkywalkPacketQueue11synchronizeEj.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff8002980b50` | 6 | `__ZN20IOSkywalkPacketQueue16packetSubmissionEPyPjS1_` | `asm/ZN20IOSkywalkPacketQueue16packetSubmissionEPyPjS1_.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff8002980b5c` | 6 | `__ZN20IOSkywalkPacketQueue16packetSubmissionEb` | `asm/ZN20IOSkywalkPacketQueue16packetSubmissionEb.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff8002980b68` | 6 | `__ZN20IOSkywalkPacketQueue16sendNotificationEj` | `asm/ZN20IOSkywalkPacketQueue16sendNotificationEj.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff8002980b74` | 5 | `__ZNK20IOSkywalkPacketQueue12getDirectionEv` | `asm/ZNK20IOSkywalkPacketQueue12getDirectionEv.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff8002980b80` | 5 | `__ZNK20IOSkywalkPacketQueue10getQueueIdEv` | `asm/ZNK20IOSkywalkPacketQueue10getQueueIdEv.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff8002980b8c` | 5 | `__ZNK20IOSkywalkPacketQueue11getCapacityEv` | `asm/ZNK20IOSkywalkPacketQueue11getCapacityEv.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff8002980b98` | 5 | `__ZNK20IOSkywalkPacketQueue13getBufferSizeEv` | `asm/ZNK20IOSkywalkPacketQueue13getBufferSizeEv.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff8002980ba4` | 5 | `__ZNK20IOSkywalkPacketQueue12isQueueReadyEv` | `asm/ZNK20IOSkywalkPacketQueue12isQueueReadyEv.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff8002980bb0` | 5 | `__ZNK20IOSkywalkPacketQueue15getServiceClassEv` | `asm/ZNK20IOSkywalkPacketQueue15getServiceClassEv.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff8002980bbc` | 5 | `__ZNK20IOSkywalkPacketQueue9getRefconEv` | `asm/ZNK20IOSkywalkPacketQueue9getRefconEv.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff8002980bc6` | 5 | `__ZNK20IOSkywalkPacketQueue19getPacketBufferPoolEv` | `asm/ZNK20IOSkywalkPacketQueue19getPacketBufferPoolEv.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff8002980bd0` | 6 | `__ZN20IOSkywalkPacketQueue19setPacketBufferPoolEP25IOSkywalkPacketBufferPool` | `asm/ZN20IOSkywalkPacketQueue19setPacketBufferPoolEP25IOSkywalkPacketBufferPool.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff8002980bdc` | 6 | `__ZN20IOSkywalkPacketQueue15setPacketPollerEP21IOSkywalkPacketPoller` | `asm/ZN20IOSkywalkPacketQueue15setPacketPollerEP21IOSkywalkPacketPoller.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff8002980be8` | 5 | `__ZNK20IOSkywalkPacketQueue20getPacketBufferCountEv` | `asm/ZNK20IOSkywalkPacketQueue20getPacketBufferCountEv.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff8002980bf0` | 19 | `__ZNK20IOSkywalkPacketQueue12getFreeSpaceEv` | `asm/ZNK20IOSkywalkPacketQueue12getFreeSpaceEv.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff8002980c1e` | 7 | `__ZN20IOSkywalkPacketQueue16packetCompletionEP15IOSkywalkPacketPS_j` | `asm/ZN20IOSkywalkPacketQueue16packetCompletionEP15IOSkywalkPacketPS_j.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff8002980c3c` | 7 | `__ZN20IOSkywalkPacketQueue16bufferCompletionEP21IOSkywalkPacketBufferPS_j` | `asm/ZN20IOSkywalkPacketQueue16bufferCompletionEP21IOSkywalkPacketBufferPS_j.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff8002980c5a` | 6 | `__ZN20IOSkywalkPacketQueue14performCommandEjPvm` | `asm/ZN20IOSkywalkPacketQueue14performCommandEjPvm.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff8002980c66` | 19 | `__ZN20IOSkywalkPacketQueue12setInterfaceEP18IOSkywalkInterface` | `asm/ZN20IOSkywalkPacketQueue12setInterfaceEP18IOSkywalkInterface.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff8002980c9a` | 20 | `__ZN20IOSkywalkPacketQueue18statGetElapsedTimeEPKy` | `asm/ZN20IOSkywalkPacketQueue18statGetElapsedTimeEPKy.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff8002980cd8` | 5 | `__ZN20IOSkywalkPacketQueue17setKernNetifQueueEP11netif_queue` | `asm/ZN20IOSkywalkPacketQueue17setKernNetifQueueEP11netif_queue.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff8002980ce2` | 5 | `__ZN20IOSkywalkPacketQueue17getKernNetifQueueEv` | `asm/ZN20IOSkywalkPacketQueue17getKernNetifQueueEv.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff8002980cec` | 6 | `__ZN20IOSkywalkPacketQueue11getQueueSetEv` | `asm/ZN20IOSkywalkPacketQueue11getQueueSetEv.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff8002980cfa` | 6 | `__ZN20IOSkywalkPacketQueue11setQueueSetEP17IOSkywalkQueueSet` | `asm/ZN20IOSkywalkPacketQueue11setQueueSetEP17IOSkywalkQueueSet.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff8002980d08` | 80 | `__ZN20IOSkywalkPacketQueue14getDescriptionEPcm` | `asm/ZN20IOSkywalkPacketQueue14getDescriptionEPcm.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff8002980e2a` | 6 | `__ZN20IOSkywalkPacketQueue10setOwnerIdEy` | `asm/ZN20IOSkywalkPacketQueue10setOwnerIdEy.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff8002980e38` | 11 | `__ZN20IOSkywalkPacketQueue17setTraceTagActionEPFtPS_E` | `asm/ZN20IOSkywalkPacketQueue17setTraceTagActionEPFtPS_E.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff8002980e54` | 25 | `__ZN20IOSkywalkPacketQueue8initABFSEv` | `asm/ZN20IOSkywalkPacketQueue8initABFSEv.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff8002980eae` | 7 | `__ZN20IOSkywalkPacketQueue21setABFSHysteresisTimeEj` | `asm/ZN20IOSkywalkPacketQueue21setABFSHysteresisTimeEj.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff8002980ec2` | 37 | `__ZN20IOSkywalkPacketQueue14notifySrcQueueEbPS_j` | `asm/ZN20IOSkywalkPacketQueue14notifySrcQueueEbPS_j.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff8002980f36` | 32 | `__ZN20IOSkywalkPacketQueue16packetSubmissionEjj` | `asm/ZN20IOSkywalkPacketQueue16packetSubmissionEjj.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff8002980f88` | 146 | `__ZN20IOSkywalkPacketQueue16packetCompletionEjjb` | `asm/ZN20IOSkywalkPacketQueue16packetCompletionEjjb.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff800298115a` | 10 | `__ZN20IOSkywalkPacketQueue18queryByteFreeSpaceEv` | `asm/ZN20IOSkywalkPacketQueue18queryByteFreeSpaceEv.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff8002981170` | 7 | `__ZN20IOSkywalkPacketQueue30_RESERVEDIOSkywalkPacketQueue0Ev` | `asm/ZN20IOSkywalkPacketQueue30_RESERVEDIOSkywalkPacketQueue0Ev.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff8002981184` | 6 | `__ZN20IOSkywalkPacketQueue30_RESERVEDIOSkywalkPacketQueue1Ev` | `asm/ZN20IOSkywalkPacketQueue30_RESERVEDIOSkywalkPacketQueue1Ev.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff800298119a` | 6 | `__ZN20IOSkywalkPacketQueue30_RESERVEDIOSkywalkPacketQueue2Ev` | `asm/ZN20IOSkywalkPacketQueue30_RESERVEDIOSkywalkPacketQueue2Ev.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff80029811b0` | 6 | `__ZN20IOSkywalkPacketQueue30_RESERVEDIOSkywalkPacketQueue3Ev` | `asm/ZN20IOSkywalkPacketQueue30_RESERVEDIOSkywalkPacketQueue3Ev.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff80029811c6` | 6 | `__ZN20IOSkywalkPacketQueue30_RESERVEDIOSkywalkPacketQueue4Ev` | `asm/ZN20IOSkywalkPacketQueue30_RESERVEDIOSkywalkPacketQueue4Ev.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff80029811dc` | 6 | `__ZN20IOSkywalkPacketQueue30_RESERVEDIOSkywalkPacketQueue5Ev` | `asm/ZN20IOSkywalkPacketQueue30_RESERVEDIOSkywalkPacketQueue5Ev.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff80029811f2` | 6 | `__ZN20IOSkywalkPacketQueue30_RESERVEDIOSkywalkPacketQueue6Ev` | `asm/ZN20IOSkywalkPacketQueue30_RESERVEDIOSkywalkPacketQueue6Ev.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff8002981208` | 6 | `__ZN20IOSkywalkPacketQueue30_RESERVEDIOSkywalkPacketQueue7Ev` | `asm/ZN20IOSkywalkPacketQueue30_RESERVEDIOSkywalkPacketQueue7Ev.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff800298121e` | 6 | `__ZN20IOSkywalkPacketQueue30_RESERVEDIOSkywalkPacketQueue8Ev` | `asm/ZN20IOSkywalkPacketQueue30_RESERVEDIOSkywalkPacketQueue8Ev.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff8002981234` | 6 | `__ZN20IOSkywalkPacketQueue30_RESERVEDIOSkywalkPacketQueue9Ev` | `asm/ZN20IOSkywalkPacketQueue30_RESERVEDIOSkywalkPacketQueue9Ev.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff800298124a` | 6 | `__ZN20IOSkywalkPacketQueue31_RESERVEDIOSkywalkPacketQueue10Ev` | `asm/ZN20IOSkywalkPacketQueue31_RESERVEDIOSkywalkPacketQueue10Ev.asm.txt` |
| `IOSkywalkPacketQueue` | `0xffffff8002981260` | 4 | `__ZN20IOSkywalkPacketQueue9MetaClassD0Ev` | `asm/ZN20IOSkywalkPacketQueue9MetaClassD0Ev.asm.txt` |
| `IOSkywalkRxSubmissionQueue` | `0xffffff8002985558` | 15 | `__ZN26IOSkywalkRxSubmissionQueue9MetaClassC1Ev` | `asm/ZN26IOSkywalkRxSubmissionQueue9MetaClassC1Ev.asm.txt` |
| `IOSkywalkRxSubmissionQueue` | `0xffffff800298558a` | 4 | `__ZN26IOSkywalkRxSubmissionQueue9MetaClassD1Ev` | `asm/ZN26IOSkywalkRxSubmissionQueue9MetaClassD1Ev.asm.txt` |
| `IOSkywalkRxSubmissionQueue` | `0xffffff8002985594` | 13 | `__ZN26IOSkywalkRxSubmissionQueueC2EPK11OSMetaClass` | `asm/ZN26IOSkywalkRxSubmissionQueueC2EPK11OSMetaClass.asm.txt` |
| `IOSkywalkRxSubmissionQueue` | `0xffffff80029855b4` | 13 | `__ZN26IOSkywalkRxSubmissionQueueC1EPK11OSMetaClass` | `asm/ZN26IOSkywalkRxSubmissionQueueC1EPK11OSMetaClass.asm.txt` |
| `IOSkywalkRxSubmissionQueue` | `0xffffff80029855d4` | 4 | `__ZN26IOSkywalkRxSubmissionQueueD2Ev` | `asm/ZN26IOSkywalkRxSubmissionQueueD2Ev.asm.txt` |
| `IOSkywalkRxSubmissionQueue` | `0xffffff80029855de` | 4 | `__ZN26IOSkywalkRxSubmissionQueueD1Ev` | `asm/ZN26IOSkywalkRxSubmissionQueueD1Ev.asm.txt` |
| `IOSkywalkRxSubmissionQueue` | `0xffffff80029855e8` | 13 | `__ZN26IOSkywalkRxSubmissionQueueD0Ev` | `asm/ZN26IOSkywalkRxSubmissionQueueD0Ev.asm.txt` |
| `IOSkywalkRxSubmissionQueue` | `0xffffff8002985610` | 8 | `__ZN26IOSkywalkRxSubmissionQueuedlEPvm` | `asm/ZN26IOSkywalkRxSubmissionQueuedlEPvm.asm.txt` |
| `IOSkywalkRxSubmissionQueue` | `0xffffff8002985628` | 6 | `__ZNK26IOSkywalkRxSubmissionQueue12getMetaClassEv` | `asm/ZNK26IOSkywalkRxSubmissionQueue12getMetaClassEv.asm.txt` |
| `IOSkywalkRxSubmissionQueue` | `0xffffff8002985636` | 15 | `__ZN26IOSkywalkRxSubmissionQueue9MetaClassC2Ev` | `asm/ZN26IOSkywalkRxSubmissionQueue9MetaClassC2Ev.asm.txt` |
| `IOSkywalkRxSubmissionQueue` | `0xffffff8002985668` | 22 | `__ZNK26IOSkywalkRxSubmissionQueue9MetaClass5allocEv` | `asm/ZNK26IOSkywalkRxSubmissionQueue9MetaClass5allocEv.asm.txt` |
| `IOSkywalkRxSubmissionQueue` | `0xffffff80029856b0` | 6 | `__ZN26IOSkywalkRxSubmissionQueuenwEm` | `asm/ZN26IOSkywalkRxSubmissionQueuenwEm.asm.txt` |
| `IOSkywalkRxSubmissionQueue` | `0xffffff80029856c4` | 16 | `__ZN26IOSkywalkRxSubmissionQueueC1Ev` | `asm/ZN26IOSkywalkRxSubmissionQueueC1Ev.asm.txt` |
| `IOSkywalkRxSubmissionQueue` | `0xffffff80029856f4` | 16 | `__ZN26IOSkywalkRxSubmissionQueueC2Ev` | `asm/ZN26IOSkywalkRxSubmissionQueueC2Ev.asm.txt` |
| `IOSkywalkRxSubmissionQueue` | `0xffffff8002985724` | 56 | `__ZN26IOSkywalkRxSubmissionQueue8withPoolEP25IOSkywalkPacketBufferPooljjjP8OSObjectPFjS3_PS_PKP15IOSkywalkPacketjPvES9_j` | `asm/ZN26IOSkywalkRxSubmissionQueue8withPoolEP25IOSkywalkPacketBufferPooljjjP8OSObjectPFjS3_PS_PKP15IOSkywalkPacketjPvES9_j.asm.txt` |
| `IOSkywalkRxSubmissionQueue` | `0xffffff80029857d4` | 11 | `__ZN26IOSkywalkRxSubmissionQueue8withPoolEP25IOSkywalkPacketBufferPooljjjP8OSObjectPFjS3_PS_PP15IOSkywalkPacketjPvES8_j` | `asm/ZN26IOSkywalkRxSubmissionQueue8withPoolEP25IOSkywalkPacketBufferPooljjjP8OSObjectPFjS3_PS_PP15IOSkywalkPacketjPvES8_j.asm.txt` |
| `IOSkywalkRxSubmissionQueue` | `0xffffff80029857ee` | 80 | `__ZN26IOSkywalkRxSubmissionQueue12initWithPoolEP25IOSkywalkPacketBufferPooljjjP8OSObjectPFjS3_PS_PKP15IOSkywalkPacketjPvES9_j` | `asm/ZN26IOSkywalkRxSubmissionQueue12initWithPoolEP25IOSkywalkPacketBufferPooljjjP8OSObjectPFjS3_PS_PKP15IOSkywalkPacketjPvES9_j.asm.txt` |
| `IOSkywalkRxSubmissionQueue` | `0xffffff8002985914` | 15 | `__ZN26IOSkywalkRxSubmissionQueue12retryDequeueEv` | `asm/ZN26IOSkywalkRxSubmissionQueue12retryDequeueEv.asm.txt` |
| `IOSkywalkRxSubmissionQueue` | `0xffffff800298593e` | 35 | `__ZN26IOSkywalkRxSubmissionQueue4freeEv` | `asm/ZN26IOSkywalkRxSubmissionQueue4freeEv.asm.txt` |
| `IOSkywalkRxSubmissionQueue` | `0xffffff80029859de` | 7 | `__ZN26IOSkywalkRxSubmissionQueue20adjustPacketCountersEv` | `asm/ZN26IOSkywalkRxSubmissionQueue20adjustPacketCountersEv.asm.txt` |
| `IOSkywalkRxSubmissionQueue` | `0xffffff80029859f2` | 5 | `__ZN26IOSkywalkRxSubmissionQueue20getEffectiveCapacityEj` | `asm/ZN26IOSkywalkRxSubmissionQueue20getEffectiveCapacityEj.asm.txt` |
| `IOSkywalkRxSubmissionQueue` | `0xffffff80029859fa` | 14 | `__ZN26IOSkywalkRxSubmissionQueue6enableEv` | `asm/ZN26IOSkywalkRxSubmissionQueue6enableEv.asm.txt` |
| `IOSkywalkRxSubmissionQueue` | `0xffffff8002985a26` | 25 | `__ZN26IOSkywalkRxSubmissionQueue7disableEv` | `asm/ZN26IOSkywalkRxSubmissionQueue7disableEv.asm.txt` |
| `IOSkywalkRxSubmissionQueue` | `0xffffff8002985a6c` | 122 | `__ZN26IOSkywalkRxSubmissionQueue12refillRxRingEj` | `asm/ZN26IOSkywalkRxSubmissionQueue12refillRxRingEj.asm.txt` |
| `IOSkywalkRxSubmissionQueue` | `0xffffff8002985c32` | 32 | `__ZN26IOSkywalkRxSubmissionQueue12purgePacketsEv` | `asm/ZN26IOSkywalkRxSubmissionQueue12purgePacketsEv.asm.txt` |
| `IOSkywalkRxSubmissionQueue` | `0xffffff8002985caa` | 19 | `__ZN26IOSkywalkRxSubmissionQueue16packetCompletionEP15IOSkywalkPacketP20IOSkywalkPacketQueuej` | `asm/ZN26IOSkywalkRxSubmissionQueue16packetCompletionEP15IOSkywalkPacketP20IOSkywalkPacketQueuej.asm.txt` |
| `IOSkywalkRxSubmissionQueue` | `0xffffff8002985ce4` | 33 | `__ZN26IOSkywalkRxSubmissionQueue10initializeEPv` | `asm/ZN26IOSkywalkRxSubmissionQueue10initializeEPv.asm.txt` |
| `IOSkywalkRxSubmissionQueue` | `0xffffff8002985d52` | 32 | `__ZN26IOSkywalkRxSubmissionQueue8finalizeEv` | `asm/ZN26IOSkywalkRxSubmissionQueue8finalizeEv.asm.txt` |
| `IOSkywalkRxSubmissionQueue` | `0xffffff8002985dba` | 34 | `__ZN26IOSkywalkRxSubmissionQueue14performCommandEjPvm` | `asm/ZN26IOSkywalkRxSubmissionQueue14performCommandEjPvm.asm.txt` |
| `IOSkywalkRxSubmissionQueue` | `0xffffff8002985e2e` | 84 | `__ZN26IOSkywalkRxSubmissionQueue12addReportersEP9IOServiceP5OSSet` | `asm/ZN26IOSkywalkRxSubmissionQueue12addReportersEP9IOServiceP5OSSet.asm.txt` |
| `IOSkywalkRxSubmissionQueue` | `0xffffff8002985f6c` | 94 | `__ZN26IOSkywalkRxSubmissionQueue21getReportChannelValueEy` | `asm/ZN26IOSkywalkRxSubmissionQueue21getReportChannelValueEy.asm.txt` |
| `IOSkywalkRxSubmissionQueue` | `0xffffff80029860d4` | 7 | `__ZN26IOSkywalkRxSubmissionQueue36_RESERVEDIOSkywalkRxSubmissionQueue0Ev` | `asm/ZN26IOSkywalkRxSubmissionQueue36_RESERVEDIOSkywalkRxSubmissionQueue0Ev.asm.txt` |
| `IOSkywalkRxSubmissionQueue` | `0xffffff80029860e8` | 6 | `__ZN26IOSkywalkRxSubmissionQueue36_RESERVEDIOSkywalkRxSubmissionQueue1Ev` | `asm/ZN26IOSkywalkRxSubmissionQueue36_RESERVEDIOSkywalkRxSubmissionQueue1Ev.asm.txt` |
| `IOSkywalkRxSubmissionQueue` | `0xffffff80029860fe` | 6 | `__ZN26IOSkywalkRxSubmissionQueue36_RESERVEDIOSkywalkRxSubmissionQueue2Ev` | `asm/ZN26IOSkywalkRxSubmissionQueue36_RESERVEDIOSkywalkRxSubmissionQueue2Ev.asm.txt` |
| `IOSkywalkRxSubmissionQueue` | `0xffffff8002986114` | 6 | `__ZN26IOSkywalkRxSubmissionQueue36_RESERVEDIOSkywalkRxSubmissionQueue3Ev` | `asm/ZN26IOSkywalkRxSubmissionQueue36_RESERVEDIOSkywalkRxSubmissionQueue3Ev.asm.txt` |
| `IOSkywalkRxSubmissionQueue` | `0xffffff800298612a` | 6 | `__ZN26IOSkywalkRxSubmissionQueue36_RESERVEDIOSkywalkRxSubmissionQueue4Ev` | `asm/ZN26IOSkywalkRxSubmissionQueue36_RESERVEDIOSkywalkRxSubmissionQueue4Ev.asm.txt` |
| `IOSkywalkRxSubmissionQueue` | `0xffffff8002986140` | 6 | `__ZN26IOSkywalkRxSubmissionQueue36_RESERVEDIOSkywalkRxSubmissionQueue5Ev` | `asm/ZN26IOSkywalkRxSubmissionQueue36_RESERVEDIOSkywalkRxSubmissionQueue5Ev.asm.txt` |
| `IOSkywalkRxSubmissionQueue` | `0xffffff8002986156` | 6 | `__ZN26IOSkywalkRxSubmissionQueue36_RESERVEDIOSkywalkRxSubmissionQueue6Ev` | `asm/ZN26IOSkywalkRxSubmissionQueue36_RESERVEDIOSkywalkRxSubmissionQueue6Ev.asm.txt` |
| `IOSkywalkRxSubmissionQueue` | `0xffffff800298616c` | 6 | `__ZN26IOSkywalkRxSubmissionQueue36_RESERVEDIOSkywalkRxSubmissionQueue7Ev` | `asm/ZN26IOSkywalkRxSubmissionQueue36_RESERVEDIOSkywalkRxSubmissionQueue7Ev.asm.txt` |
| `IOSkywalkRxSubmissionQueue` | `0xffffff8002986182` | 6 | `__ZN26IOSkywalkRxSubmissionQueue36_RESERVEDIOSkywalkRxSubmissionQueue8Ev` | `asm/ZN26IOSkywalkRxSubmissionQueue36_RESERVEDIOSkywalkRxSubmissionQueue8Ev.asm.txt` |
| `IOSkywalkRxSubmissionQueue` | `0xffffff8002986198` | 6 | `__ZN26IOSkywalkRxSubmissionQueue36_RESERVEDIOSkywalkRxSubmissionQueue9Ev` | `asm/ZN26IOSkywalkRxSubmissionQueue36_RESERVEDIOSkywalkRxSubmissionQueue9Ev.asm.txt` |
| `IOSkywalkRxSubmissionQueue` | `0xffffff80029861ae` | 6 | `__ZN26IOSkywalkRxSubmissionQueue37_RESERVEDIOSkywalkRxSubmissionQueue10Ev` | `asm/ZN26IOSkywalkRxSubmissionQueue37_RESERVEDIOSkywalkRxSubmissionQueue10Ev.asm.txt` |
| `IOSkywalkRxSubmissionQueue` | `0xffffff80029861c4` | 4 | `__ZN26IOSkywalkRxSubmissionQueue9MetaClassD0Ev` | `asm/ZN26IOSkywalkRxSubmissionQueue9MetaClassD0Ev.asm.txt` |
| `IOSkywalkRxSubmissionQueue` | `0xffffff80029a2fee` | 16 | `__ZN26IOSkywalkRxSubmissionQueue12checkForWorkEv` | `asm/ZN26IOSkywalkRxSubmissionQueue12checkForWorkEv.asm.txt` |
| `IOSkywalkRxSubmissionQueue` | `0xffffff80029a3028` | 58 | `__ZN26IOSkywalkRxSubmissionQueue12gatedDequeueEPv` | `asm/ZN26IOSkywalkRxSubmissionQueue12gatedDequeueEPv.asm.txt` |
| `IOSkywalkRxSubmissionQueue` | `0xffffff80029a30f2` | 79 | `__ZN26IOSkywalkRxSubmissionQueue13legacyDequeueEPv` | `asm/ZN26IOSkywalkRxSubmissionQueue13legacyDequeueEPv.asm.txt` |
| `IOSkywalkRxSubmissionQueue` | `0xffffff80029a31fa` | 124 | `__ZN26IOSkywalkRxSubmissionQueue11listDequeueEPv` | `asm/ZN26IOSkywalkRxSubmissionQueue11listDequeueEPv.asm.txt` |
| `IOSkywalkRxSubmissionQueue` | `0xffffff80029a33c0` | 45 | `__ZN26IOSkywalkRxSubmissionQueue14requestDequeueEPvj` | `asm/ZN26IOSkywalkRxSubmissionQueue14requestDequeueEPvj.asm.txt` |
| `IOSkywalkRxSubmissionQueue` | `0xffffff80029a3450` | 20 | `__ZNK26IOSkywalkRxSubmissionQueue14getPacketCountEv` | `asm/ZNK26IOSkywalkRxSubmissionQueue14getPacketCountEv.asm.txt` |
| `IOSkywalkRxSubmissionQueue` | `0xffffff80029a3486` | 13 | `__ZN26IOSkywalkRxSubmissionQueue16packetCompletionEP15IOSkywalkPacketP20IOSkywalkPacketQueuej.cold.1` | `asm/ZN26IOSkywalkRxSubmissionQueue16packetCompletionEP15IOSkywalkPacketP20IOSkywalkPacketQueuej.cold.1.asm.txt` |
| `IOSkywalkRxCompletionQueue` | `0xffffff8002986214` | 15 | `__ZN26IOSkywalkRxCompletionQueue9MetaClassC1Ev` | `asm/ZN26IOSkywalkRxCompletionQueue9MetaClassC1Ev.asm.txt` |
| `IOSkywalkRxCompletionQueue` | `0xffffff8002986246` | 4 | `__ZN26IOSkywalkRxCompletionQueue9MetaClassD1Ev` | `asm/ZN26IOSkywalkRxCompletionQueue9MetaClassD1Ev.asm.txt` |
| `IOSkywalkRxCompletionQueue` | `0xffffff8002986250` | 13 | `__ZN26IOSkywalkRxCompletionQueueC2EPK11OSMetaClass` | `asm/ZN26IOSkywalkRxCompletionQueueC2EPK11OSMetaClass.asm.txt` |
| `IOSkywalkRxCompletionQueue` | `0xffffff8002986270` | 13 | `__ZN26IOSkywalkRxCompletionQueueC1EPK11OSMetaClass` | `asm/ZN26IOSkywalkRxCompletionQueueC1EPK11OSMetaClass.asm.txt` |
| `IOSkywalkRxCompletionQueue` | `0xffffff8002986290` | 4 | `__ZN26IOSkywalkRxCompletionQueueD2Ev` | `asm/ZN26IOSkywalkRxCompletionQueueD2Ev.asm.txt` |
| `IOSkywalkRxCompletionQueue` | `0xffffff800298629a` | 4 | `__ZN26IOSkywalkRxCompletionQueueD1Ev` | `asm/ZN26IOSkywalkRxCompletionQueueD1Ev.asm.txt` |
| `IOSkywalkRxCompletionQueue` | `0xffffff80029862a4` | 13 | `__ZN26IOSkywalkRxCompletionQueueD0Ev` | `asm/ZN26IOSkywalkRxCompletionQueueD0Ev.asm.txt` |
| `IOSkywalkRxCompletionQueue` | `0xffffff80029862cc` | 8 | `__ZN26IOSkywalkRxCompletionQueuedlEPvm` | `asm/ZN26IOSkywalkRxCompletionQueuedlEPvm.asm.txt` |
| `IOSkywalkRxCompletionQueue` | `0xffffff80029862e4` | 6 | `__ZNK26IOSkywalkRxCompletionQueue12getMetaClassEv` | `asm/ZNK26IOSkywalkRxCompletionQueue12getMetaClassEv.asm.txt` |
| `IOSkywalkRxCompletionQueue` | `0xffffff80029862f2` | 15 | `__ZN26IOSkywalkRxCompletionQueue9MetaClassC2Ev` | `asm/ZN26IOSkywalkRxCompletionQueue9MetaClassC2Ev.asm.txt` |
| `IOSkywalkRxCompletionQueue` | `0xffffff8002986324` | 22 | `__ZNK26IOSkywalkRxCompletionQueue9MetaClass5allocEv` | `asm/ZNK26IOSkywalkRxCompletionQueue9MetaClass5allocEv.asm.txt` |
| `IOSkywalkRxCompletionQueue` | `0xffffff800298636c` | 6 | `__ZN26IOSkywalkRxCompletionQueuenwEm` | `asm/ZN26IOSkywalkRxCompletionQueuenwEm.asm.txt` |
| `IOSkywalkRxCompletionQueue` | `0xffffff8002986380` | 16 | `__ZN26IOSkywalkRxCompletionQueueC1Ev` | `asm/ZN26IOSkywalkRxCompletionQueueC1Ev.asm.txt` |
| `IOSkywalkRxCompletionQueue` | `0xffffff80029863b0` | 16 | `__ZN26IOSkywalkRxCompletionQueueC2Ev` | `asm/ZN26IOSkywalkRxCompletionQueueC2Ev.asm.txt` |
| `IOSkywalkRxCompletionQueue` | `0xffffff80029863e0` | 54 | `__ZN26IOSkywalkRxCompletionQueue8withPoolEP25IOSkywalkPacketBufferPooljjP8OSObjectPFjS3_PS_PP15IOSkywalkPacketjPvES8_j` | `asm/ZN26IOSkywalkRxCompletionQueue8withPoolEP25IOSkywalkPacketBufferPooljjP8OSObjectPFjS3_PS_PP15IOSkywalkPacketjPvES8_j.asm.txt` |
| `IOSkywalkRxCompletionQueue` | `0xffffff800298648a` | 50 | `__ZN26IOSkywalkRxCompletionQueue12initWithPoolEP25IOSkywalkPacketBufferPooljjP8OSObjectPFjS3_PS_PP15IOSkywalkPacketjPvES8_j` | `asm/ZN26IOSkywalkRxCompletionQueue12initWithPoolEP25IOSkywalkPacketBufferPooljjP8OSObjectPFjS3_PS_PP15IOSkywalkPacketjPvES8_j.asm.txt` |
| `IOSkywalkRxCompletionQueue` | `0xffffff8002986526` | 32 | `__ZN26IOSkywalkRxCompletionQueue4freeEv` | `asm/ZN26IOSkywalkRxCompletionQueue4freeEv.asm.txt` |
| `IOSkywalkRxCompletionQueue` | `0xffffff80029865b2` | 6 | `__ZN26IOSkywalkRxCompletionQueue20getEffectiveCapacityEj` | `asm/ZN26IOSkywalkRxCompletionQueue20getEffectiveCapacityEj.asm.txt` |
| `IOSkywalkRxCompletionQueue` | `0xffffff80029865bc` | 30 | `__ZN26IOSkywalkRxCompletionQueue6enableEv` | `asm/ZN26IOSkywalkRxCompletionQueue6enableEv.asm.txt` |
| `IOSkywalkRxCompletionQueue` | `0xffffff800298661c` | 23 | `__ZN26IOSkywalkRxCompletionQueue7disableEv` | `asm/ZN26IOSkywalkRxCompletionQueue7disableEv.asm.txt` |
| `IOSkywalkRxCompletionQueue` | `0xffffff8002986660` | 36 | `__ZN26IOSkywalkRxCompletionQueue10initializeEPv` | `asm/ZN26IOSkywalkRxCompletionQueue10initializeEPv.asm.txt` |
| `IOSkywalkRxCompletionQueue` | `0xffffff80029866d2` | 33 | `__ZN26IOSkywalkRxCompletionQueue8finalizeEv` | `asm/ZN26IOSkywalkRxCompletionQueue8finalizeEv.asm.txt` |
| `IOSkywalkRxCompletionQueue` | `0xffffff8002986748` | 104 | `__ZN26IOSkywalkRxCompletionQueue11synchronizeEj` | `asm/ZN26IOSkywalkRxCompletionQueue11synchronizeEj.asm.txt` |
| `IOSkywalkRxCompletionQueue` | `0xffffff80029868d0` | 25 | `__ZN26IOSkywalkRxCompletionQueue15setPacketPollerEP21IOSkywalkPacketPoller` | `asm/ZN26IOSkywalkRxCompletionQueue15setPacketPollerEP21IOSkywalkPacketPoller.asm.txt` |
| `IOSkywalkRxCompletionQueue` | `0xffffff8002986918` | 91 | `__ZN26IOSkywalkRxCompletionQueue27enqueuePacketsForNetworkingEPKP15IOSkywalkPacketjj` | `asm/ZN26IOSkywalkRxCompletionQueue27enqueuePacketsForNetworkingEPKP15IOSkywalkPacketjj.asm.txt` |
| `IOSkywalkRxCompletionQueue` | `0xffffff8002986a5a` | 65 | `__ZN26IOSkywalkRxCompletionQueue22enqueuePacketsForKPipeEPKP15IOSkywalkPacketjj` | `asm/ZN26IOSkywalkRxCompletionQueue22enqueuePacketsForKPipeEPKP15IOSkywalkPacketjj.asm.txt` |
| `IOSkywalkRxCompletionQueue` | `0xffffff8002986b24` | 45 | `__ZN26IOSkywalkRxCompletionQueue14performCommandEjPvm` | `asm/ZN26IOSkywalkRxCompletionQueue14performCommandEjPvm.asm.txt` |
| `IOSkywalkRxCompletionQueue` | `0xffffff8002986bc6` | 84 | `__ZN26IOSkywalkRxCompletionQueue12addReportersEP9IOServiceP5OSSet` | `asm/ZN26IOSkywalkRxCompletionQueue12addReportersEP9IOServiceP5OSSet.asm.txt` |
| `IOSkywalkRxCompletionQueue` | `0xffffff8002986d04` | 65 | `__ZN26IOSkywalkRxCompletionQueue21getReportChannelValueEy` | `asm/ZN26IOSkywalkRxCompletionQueue21getReportChannelValueEy.asm.txt` |
| `IOSkywalkRxCompletionQueue` | `0xffffff8002986df0` | 7 | `__ZN26IOSkywalkRxCompletionQueue36_RESERVEDIOSkywalkRxCompletionQueue0Ev` | `asm/ZN26IOSkywalkRxCompletionQueue36_RESERVEDIOSkywalkRxCompletionQueue0Ev.asm.txt` |
| `IOSkywalkRxCompletionQueue` | `0xffffff8002986e04` | 6 | `__ZN26IOSkywalkRxCompletionQueue36_RESERVEDIOSkywalkRxCompletionQueue1Ev` | `asm/ZN26IOSkywalkRxCompletionQueue36_RESERVEDIOSkywalkRxCompletionQueue1Ev.asm.txt` |
| `IOSkywalkRxCompletionQueue` | `0xffffff8002986e1a` | 6 | `__ZN26IOSkywalkRxCompletionQueue36_RESERVEDIOSkywalkRxCompletionQueue2Ev` | `asm/ZN26IOSkywalkRxCompletionQueue36_RESERVEDIOSkywalkRxCompletionQueue2Ev.asm.txt` |
| `IOSkywalkRxCompletionQueue` | `0xffffff8002986e30` | 6 | `__ZN26IOSkywalkRxCompletionQueue36_RESERVEDIOSkywalkRxCompletionQueue3Ev` | `asm/ZN26IOSkywalkRxCompletionQueue36_RESERVEDIOSkywalkRxCompletionQueue3Ev.asm.txt` |
| `IOSkywalkRxCompletionQueue` | `0xffffff8002986e46` | 6 | `__ZN26IOSkywalkRxCompletionQueue36_RESERVEDIOSkywalkRxCompletionQueue4Ev` | `asm/ZN26IOSkywalkRxCompletionQueue36_RESERVEDIOSkywalkRxCompletionQueue4Ev.asm.txt` |
| `IOSkywalkRxCompletionQueue` | `0xffffff8002986e5c` | 6 | `__ZN26IOSkywalkRxCompletionQueue36_RESERVEDIOSkywalkRxCompletionQueue5Ev` | `asm/ZN26IOSkywalkRxCompletionQueue36_RESERVEDIOSkywalkRxCompletionQueue5Ev.asm.txt` |
| `IOSkywalkRxCompletionQueue` | `0xffffff8002986e72` | 6 | `__ZN26IOSkywalkRxCompletionQueue36_RESERVEDIOSkywalkRxCompletionQueue6Ev` | `asm/ZN26IOSkywalkRxCompletionQueue36_RESERVEDIOSkywalkRxCompletionQueue6Ev.asm.txt` |
| `IOSkywalkRxCompletionQueue` | `0xffffff8002986e88` | 6 | `__ZN26IOSkywalkRxCompletionQueue36_RESERVEDIOSkywalkRxCompletionQueue7Ev` | `asm/ZN26IOSkywalkRxCompletionQueue36_RESERVEDIOSkywalkRxCompletionQueue7Ev.asm.txt` |
| `IOSkywalkRxCompletionQueue` | `0xffffff8002986e9e` | 6 | `__ZN26IOSkywalkRxCompletionQueue36_RESERVEDIOSkywalkRxCompletionQueue8Ev` | `asm/ZN26IOSkywalkRxCompletionQueue36_RESERVEDIOSkywalkRxCompletionQueue8Ev.asm.txt` |
| `IOSkywalkRxCompletionQueue` | `0xffffff8002986eb4` | 6 | `__ZN26IOSkywalkRxCompletionQueue36_RESERVEDIOSkywalkRxCompletionQueue9Ev` | `asm/ZN26IOSkywalkRxCompletionQueue36_RESERVEDIOSkywalkRxCompletionQueue9Ev.asm.txt` |
| `IOSkywalkRxCompletionQueue` | `0xffffff8002986eca` | 6 | `__ZN26IOSkywalkRxCompletionQueue37_RESERVEDIOSkywalkRxCompletionQueue10Ev` | `asm/ZN26IOSkywalkRxCompletionQueue37_RESERVEDIOSkywalkRxCompletionQueue10Ev.asm.txt` |
| `IOSkywalkRxCompletionQueue` | `0xffffff8002986ee0` | 4 | `__ZN26IOSkywalkRxCompletionQueue9MetaClassD0Ev` | `asm/ZN26IOSkywalkRxCompletionQueue9MetaClassD0Ev.asm.txt` |
| `IOSkywalkRxCompletionQueue` | `0xffffff80029a34ac` | 16 | `__ZN26IOSkywalkRxCompletionQueue12checkForWorkEv` | `asm/ZN26IOSkywalkRxCompletionQueue12checkForWorkEv.asm.txt` |
| `IOSkywalkRxCompletionQueue` | `0xffffff80029a34e6` | 96 | `__ZN26IOSkywalkRxCompletionQueue12gatedEnqueueEPv` | `asm/ZN26IOSkywalkRxCompletionQueue12gatedEnqueueEPv.asm.txt` |
| `IOSkywalkRxCompletionQueue` | `0xffffff80029a3628` | 43 | `__ZN26IOSkywalkRxCompletionQueue14requestEnqueueEPvj` | `asm/ZN26IOSkywalkRxCompletionQueue14requestEnqueueEPvj.asm.txt` |
| `IOSkywalkRxCompletionQueue` | `0xffffff80029a36b6` | 54 | `__ZN26IOSkywalkRxCompletionQueue14enqueuePacketsEPKP15IOSkywalkPacketjj` | `asm/ZN26IOSkywalkRxCompletionQueue14enqueuePacketsEPKP15IOSkywalkPacketjj.asm.txt` |
| `IOSkywalkRxCompletionQueue` | `0xffffff80029a3760` | 117 | `__ZN26IOSkywalkRxCompletionQueue14enqueuePacketsEP15IOSkywalkPacketjj` | `asm/ZN26IOSkywalkRxCompletionQueue14enqueuePacketsEP15IOSkywalkPacketjj.asm.txt` |
| `IOSkywalkRxCompletionQueue` | `0xffffff80029a390e` | 18 | `__ZNK26IOSkywalkRxCompletionQueue14getPacketCountEv` | `asm/ZNK26IOSkywalkRxCompletionQueue14getPacketCountEv.asm.txt` |
| `IOSkywalkRxCompletionQueue` | `0xffffff80029a3942` | 26 | `__ZN26IOSkywalkRxCompletionQueue16sendNotificationEj` | `asm/ZN26IOSkywalkRxCompletionQueue16sendNotificationEj.asm.txt` |
| `IOSkywalkRxCompletionQueue` | `0xffffff80029a3982` | 15 | `__ZN26IOSkywalkRxCompletionQueue11synchronizeEj.cold.1` | `asm/ZN26IOSkywalkRxCompletionQueue11synchronizeEj.cold.1.asm.txt` |
| `IOSkywalkTxSubmissionQueue` | `0xffffff8002983e24` | 15 | `__ZN26IOSkywalkTxSubmissionQueue9MetaClassC1Ev` | `asm/ZN26IOSkywalkTxSubmissionQueue9MetaClassC1Ev.asm.txt` |
| `IOSkywalkTxSubmissionQueue` | `0xffffff8002983e56` | 4 | `__ZN26IOSkywalkTxSubmissionQueue9MetaClassD1Ev` | `asm/ZN26IOSkywalkTxSubmissionQueue9MetaClassD1Ev.asm.txt` |
| `IOSkywalkTxSubmissionQueue` | `0xffffff8002983e60` | 13 | `__ZN26IOSkywalkTxSubmissionQueueC2EPK11OSMetaClass` | `asm/ZN26IOSkywalkTxSubmissionQueueC2EPK11OSMetaClass.asm.txt` |
| `IOSkywalkTxSubmissionQueue` | `0xffffff8002983e80` | 13 | `__ZN26IOSkywalkTxSubmissionQueueC1EPK11OSMetaClass` | `asm/ZN26IOSkywalkTxSubmissionQueueC1EPK11OSMetaClass.asm.txt` |
| `IOSkywalkTxSubmissionQueue` | `0xffffff8002983ea0` | 4 | `__ZN26IOSkywalkTxSubmissionQueueD2Ev` | `asm/ZN26IOSkywalkTxSubmissionQueueD2Ev.asm.txt` |
| `IOSkywalkTxSubmissionQueue` | `0xffffff8002983eaa` | 4 | `__ZN26IOSkywalkTxSubmissionQueueD1Ev` | `asm/ZN26IOSkywalkTxSubmissionQueueD1Ev.asm.txt` |
| `IOSkywalkTxSubmissionQueue` | `0xffffff8002983eb4` | 13 | `__ZN26IOSkywalkTxSubmissionQueueD0Ev` | `asm/ZN26IOSkywalkTxSubmissionQueueD0Ev.asm.txt` |
| `IOSkywalkTxSubmissionQueue` | `0xffffff8002983edc` | 8 | `__ZN26IOSkywalkTxSubmissionQueuedlEPvm` | `asm/ZN26IOSkywalkTxSubmissionQueuedlEPvm.asm.txt` |
| `IOSkywalkTxSubmissionQueue` | `0xffffff8002983ef4` | 6 | `__ZNK26IOSkywalkTxSubmissionQueue12getMetaClassEv` | `asm/ZNK26IOSkywalkTxSubmissionQueue12getMetaClassEv.asm.txt` |
| `IOSkywalkTxSubmissionQueue` | `0xffffff8002983f02` | 15 | `__ZN26IOSkywalkTxSubmissionQueue9MetaClassC2Ev` | `asm/ZN26IOSkywalkTxSubmissionQueue9MetaClassC2Ev.asm.txt` |
| `IOSkywalkTxSubmissionQueue` | `0xffffff8002983f34` | 22 | `__ZNK26IOSkywalkTxSubmissionQueue9MetaClass5allocEv` | `asm/ZNK26IOSkywalkTxSubmissionQueue9MetaClass5allocEv.asm.txt` |
| `IOSkywalkTxSubmissionQueue` | `0xffffff8002983f7c` | 6 | `__ZN26IOSkywalkTxSubmissionQueuenwEm` | `asm/ZN26IOSkywalkTxSubmissionQueuenwEm.asm.txt` |
| `IOSkywalkTxSubmissionQueue` | `0xffffff8002983f90` | 16 | `__ZN26IOSkywalkTxSubmissionQueueC1Ev` | `asm/ZN26IOSkywalkTxSubmissionQueueC1Ev.asm.txt` |
| `IOSkywalkTxSubmissionQueue` | `0xffffff8002983fc0` | 16 | `__ZN26IOSkywalkTxSubmissionQueueC2Ev` | `asm/ZN26IOSkywalkTxSubmissionQueueC2Ev.asm.txt` |
| `IOSkywalkTxSubmissionQueue` | `0xffffff8002983ff0` | 55 | `__ZN26IOSkywalkTxSubmissionQueue8withPoolEP25IOSkywalkPacketBufferPooljjP8OSObjectPFjS3_PS_PjEPFjS3_S4_PKP15IOSkywalkPacketjPvESC_jj` | `asm/ZN26IOSkywalkTxSubmissionQueue8withPoolEP25IOSkywalkPacketBufferPooljjP8OSObjectPFjS3_PS_PjEPFjS3_S4_PKP15IOSkywalkPacketjPvESC_jj.asm.txt` |
| `IOSkywalkTxSubmissionQueue` | `0xffffff800298409e` | 13 | `__ZN26IOSkywalkTxSubmissionQueue8withPoolEP25IOSkywalkPacketBufferPooljjP8OSObjectPFjS3_PS_PjEPFjS3_S4_PP15IOSkywalkPacketjPvESB_jj` | `asm/ZN26IOSkywalkTxSubmissionQueue8withPoolEP25IOSkywalkPacketBufferPooljjP8OSObjectPFjS3_PS_PjEPFjS3_S4_PP15IOSkywalkPacketjPvESB_jj.asm.txt` |
| `IOSkywalkTxSubmissionQueue` | `0xffffff80029840c2` | 15 | `__ZN26IOSkywalkTxSubmissionQueue8withPoolEP25IOSkywalkPacketBufferPooljjP8OSObjectPFjS3_PS_PKP15IOSkywalkPacketjPvES9_j` | `asm/ZN26IOSkywalkTxSubmissionQueue8withPoolEP25IOSkywalkPacketBufferPooljjP8OSObjectPFjS3_PS_PKP15IOSkywalkPacketjPvES9_j.asm.txt` |
| `IOSkywalkTxSubmissionQueue` | `0xffffff80029840e8` | 78 | `__ZN26IOSkywalkTxSubmissionQueue12initWithPoolEP25IOSkywalkPacketBufferPooljjjP8OSObjectPFjS3_PS_PjEPFjS3_S4_PKP15IOSkywalkPacketjPvESC_j` | `asm/ZN26IOSkywalkTxSubmissionQueue12initWithPoolEP25IOSkywalkPacketBufferPooljjjP8OSObjectPFjS3_PS_PjEPFjS3_S4_PKP15IOSkywalkPacketjPvESC_j.asm.txt` |
| `IOSkywalkTxSubmissionQueue` | `0xffffff800298420a` | 7 | `__ZN26IOSkywalkTxSubmissionQueue20adjustPacketCountersEv` | `asm/ZN26IOSkywalkTxSubmissionQueue20adjustPacketCountersEv.asm.txt` |
| `IOSkywalkTxSubmissionQueue` | `0xffffff800298421e` | 32 | `__ZN26IOSkywalkTxSubmissionQueue4freeEv` | `asm/ZN26IOSkywalkTxSubmissionQueue4freeEv.asm.txt` |
| `IOSkywalkTxSubmissionQueue` | `0xffffff80029842aa` | 5 | `__ZN26IOSkywalkTxSubmissionQueue20getEffectiveCapacityEj` | `asm/ZN26IOSkywalkTxSubmissionQueue20getEffectiveCapacityEj.asm.txt` |
| `IOSkywalkTxSubmissionQueue` | `0xffffff80029842b2` | 29 | `__ZN26IOSkywalkTxSubmissionQueue6enableEv` | `asm/ZN26IOSkywalkTxSubmissionQueue6enableEv.asm.txt` |
| `IOSkywalkTxSubmissionQueue` | `0xffffff8002984312` | 23 | `__ZN26IOSkywalkTxSubmissionQueue7disableEv` | `asm/ZN26IOSkywalkTxSubmissionQueue7disableEv.asm.txt` |
| `IOSkywalkTxSubmissionQueue` | `0xffffff8002984356` | 99 | `__ZN26IOSkywalkTxSubmissionQueue24packetSubmissionForKPipeEb` | `asm/ZN26IOSkywalkTxSubmissionQueue24packetSubmissionForKPipeEb.asm.txt` |
| `IOSkywalkTxSubmissionQueue` | `0xffffff80029844ca` | 41 | `__ZN26IOSkywalkTxSubmissionQueue10initializeEPv` | `asm/ZN26IOSkywalkTxSubmissionQueue10initializeEPv.asm.txt` |
| `IOSkywalkTxSubmissionQueue` | `0xffffff8002984552` | 32 | `__ZN26IOSkywalkTxSubmissionQueue8finalizeEv` | `asm/ZN26IOSkywalkTxSubmissionQueue8finalizeEv.asm.txt` |
| `IOSkywalkTxSubmissionQueue` | `0xffffff80029845c0` | 18 | `__ZN26IOSkywalkTxSubmissionQueue11synchronizeEj` | `asm/ZN26IOSkywalkTxSubmissionQueue11synchronizeEj.asm.txt` |
| `IOSkywalkTxSubmissionQueue` | `0xffffff80029845f2` | 118 | `__ZN26IOSkywalkTxSubmissionQueue20refillTxRingForKPipeEj` | `asm/ZN26IOSkywalkTxSubmissionQueue20refillTxRingForKPipeEj.asm.txt` |
| `IOSkywalkTxSubmissionQueue` | `0xffffff80029847a0` | 136 | `__ZN26IOSkywalkTxSubmissionQueue21getPacketListForKPipeEv` | `asm/ZN26IOSkywalkTxSubmissionQueue21getPacketListForKPipeEv.asm.txt` |
| `IOSkywalkTxSubmissionQueue` | `0xffffff8002984998` | 50 | `__ZN26IOSkywalkTxSubmissionQueue20refillTxRingForKPipeEjb` | `asm/ZN26IOSkywalkTxSubmissionQueue20refillTxRingForKPipeEjb.asm.txt` |
| `IOSkywalkTxSubmissionQueue` | `0xffffff8002984a3e` | 120 | `__ZN26IOSkywalkTxSubmissionQueue25refillTxRingForNetworkingEjjb` | `asm/ZN26IOSkywalkTxSubmissionQueue25refillTxRingForNetworkingEjjb.asm.txt` |
| `IOSkywalkTxSubmissionQueue` | `0xffffff8002984c04` | 150 | `__ZN26IOSkywalkTxSubmissionQueue26getPacketListForNetworkingEjjb` | `asm/ZN26IOSkywalkTxSubmissionQueue26getPacketListForNetworkingEjjb.asm.txt` |
| `IOSkywalkTxSubmissionQueue` | `0xffffff8002984e32` | 34 | `__ZN26IOSkywalkTxSubmissionQueue16packetCompletionEP15IOSkywalkPacketP20IOSkywalkPacketQueuej` | `asm/ZN26IOSkywalkTxSubmissionQueue16packetCompletionEP15IOSkywalkPacketP20IOSkywalkPacketQueuej.asm.txt` |
| `IOSkywalkTxSubmissionQueue` | `0xffffff8002984e9c` | 55 | `__ZN26IOSkywalkTxSubmissionQueue16packetCompletionEjjb` | `asm/ZN26IOSkywalkTxSubmissionQueue16packetCompletionEjjb.asm.txt` |
| `IOSkywalkTxSubmissionQueue` | `0xffffff8002984f4a` | 9 | `__ZN26IOSkywalkTxSubmissionQueue12purgePacketsEv` | `asm/ZN26IOSkywalkTxSubmissionQueue12purgePacketsEv.asm.txt` |
| `IOSkywalkTxSubmissionQueue` | `0xffffff8002984f5e` | 15 | `__ZNK26IOSkywalkTxSubmissionQueue14getPacketCountEv` | `asm/ZNK26IOSkywalkTxSubmissionQueue14getPacketCountEv.asm.txt` |
| `IOSkywalkTxSubmissionQueue` | `0xffffff8002984f90` | 61 | `__ZN26IOSkywalkTxSubmissionQueue14performCommandEjPvm` | `asm/ZN26IOSkywalkTxSubmissionQueue14performCommandEjPvm.asm.txt` |
| `IOSkywalkTxSubmissionQueue` | `0xffffff8002985064` | 106 | `__ZN26IOSkywalkTxSubmissionQueue12addReportersEP9IOServiceP5OSSet` | `asm/ZN26IOSkywalkTxSubmissionQueue12addReportersEP9IOServiceP5OSSet.asm.txt` |
| `IOSkywalkTxSubmissionQueue` | `0xffffff8002985230` | 18 | `__ZN26IOSkywalkTxSubmissionQueue19setNICObservedCountEj` | `asm/ZN26IOSkywalkTxSubmissionQueue19setNICObservedCountEj.asm.txt` |
| `IOSkywalkTxSubmissionQueue` | `0xffffff8002985260` | 121 | `__ZN26IOSkywalkTxSubmissionQueue21getReportChannelValueEy` | `asm/ZN26IOSkywalkTxSubmissionQueue21getReportChannelValueEy.asm.txt` |
| `IOSkywalkTxSubmissionQueue` | `0xffffff8002985418` | 7 | `__ZN26IOSkywalkTxSubmissionQueue36_RESERVEDIOSkywalkTxSubmissionQueue0Ev` | `asm/ZN26IOSkywalkTxSubmissionQueue36_RESERVEDIOSkywalkTxSubmissionQueue0Ev.asm.txt` |
| `IOSkywalkTxSubmissionQueue` | `0xffffff800298542c` | 6 | `__ZN26IOSkywalkTxSubmissionQueue36_RESERVEDIOSkywalkTxSubmissionQueue1Ev` | `asm/ZN26IOSkywalkTxSubmissionQueue36_RESERVEDIOSkywalkTxSubmissionQueue1Ev.asm.txt` |
| `IOSkywalkTxSubmissionQueue` | `0xffffff8002985442` | 6 | `__ZN26IOSkywalkTxSubmissionQueue36_RESERVEDIOSkywalkTxSubmissionQueue2Ev` | `asm/ZN26IOSkywalkTxSubmissionQueue36_RESERVEDIOSkywalkTxSubmissionQueue2Ev.asm.txt` |
| `IOSkywalkTxSubmissionQueue` | `0xffffff8002985458` | 6 | `__ZN26IOSkywalkTxSubmissionQueue36_RESERVEDIOSkywalkTxSubmissionQueue3Ev` | `asm/ZN26IOSkywalkTxSubmissionQueue36_RESERVEDIOSkywalkTxSubmissionQueue3Ev.asm.txt` |
| `IOSkywalkTxSubmissionQueue` | `0xffffff800298546e` | 6 | `__ZN26IOSkywalkTxSubmissionQueue36_RESERVEDIOSkywalkTxSubmissionQueue4Ev` | `asm/ZN26IOSkywalkTxSubmissionQueue36_RESERVEDIOSkywalkTxSubmissionQueue4Ev.asm.txt` |
| `IOSkywalkTxSubmissionQueue` | `0xffffff8002985484` | 6 | `__ZN26IOSkywalkTxSubmissionQueue36_RESERVEDIOSkywalkTxSubmissionQueue5Ev` | `asm/ZN26IOSkywalkTxSubmissionQueue36_RESERVEDIOSkywalkTxSubmissionQueue5Ev.asm.txt` |
| `IOSkywalkTxSubmissionQueue` | `0xffffff800298549a` | 6 | `__ZN26IOSkywalkTxSubmissionQueue36_RESERVEDIOSkywalkTxSubmissionQueue6Ev` | `asm/ZN26IOSkywalkTxSubmissionQueue36_RESERVEDIOSkywalkTxSubmissionQueue6Ev.asm.txt` |
| `IOSkywalkTxSubmissionQueue` | `0xffffff80029854b0` | 6 | `__ZN26IOSkywalkTxSubmissionQueue36_RESERVEDIOSkywalkTxSubmissionQueue7Ev` | `asm/ZN26IOSkywalkTxSubmissionQueue36_RESERVEDIOSkywalkTxSubmissionQueue7Ev.asm.txt` |
| `IOSkywalkTxSubmissionQueue` | `0xffffff80029854c6` | 6 | `__ZN26IOSkywalkTxSubmissionQueue36_RESERVEDIOSkywalkTxSubmissionQueue8Ev` | `asm/ZN26IOSkywalkTxSubmissionQueue36_RESERVEDIOSkywalkTxSubmissionQueue8Ev.asm.txt` |
| `IOSkywalkTxSubmissionQueue` | `0xffffff80029854dc` | 6 | `__ZN26IOSkywalkTxSubmissionQueue36_RESERVEDIOSkywalkTxSubmissionQueue9Ev` | `asm/ZN26IOSkywalkTxSubmissionQueue36_RESERVEDIOSkywalkTxSubmissionQueue9Ev.asm.txt` |
| `IOSkywalkTxSubmissionQueue` | `0xffffff80029854f2` | 6 | `__ZN26IOSkywalkTxSubmissionQueue37_RESERVEDIOSkywalkTxSubmissionQueue10Ev` | `asm/ZN26IOSkywalkTxSubmissionQueue37_RESERVEDIOSkywalkTxSubmissionQueue10Ev.asm.txt` |
| `IOSkywalkTxSubmissionQueue` | `0xffffff8002985508` | 4 | `__ZN26IOSkywalkTxSubmissionQueue9MetaClassD0Ev` | `asm/ZN26IOSkywalkTxSubmissionQueue9MetaClassD0Ev.asm.txt` |
| `IOSkywalkTxSubmissionQueue` | `0xffffff80029a268a` | 73 | `__ZN26IOSkywalkTxSubmissionQueue12checkForWorkEv` | `asm/ZN26IOSkywalkTxSubmissionQueue12checkForWorkEv.asm.txt` |
| `IOSkywalkTxSubmissionQueue` | `0xffffff80029a27a4` | 82 | `__ZN26IOSkywalkTxSubmissionQueue13legacyDequeueEv` | `asm/ZN26IOSkywalkTxSubmissionQueue13legacyDequeueEv.asm.txt` |
| `IOSkywalkTxSubmissionQueue` | `0xffffff80029a28c8` | 68 | `__ZN26IOSkywalkTxSubmissionQueue11listDequeueEv` | `asm/ZN26IOSkywalkTxSubmissionQueue11listDequeueEv.asm.txt` |
| `IOSkywalkTxSubmissionQueue` | `0xffffff80029a29be` | 41 | `__ZN26IOSkywalkTxSubmissionQueue14requestDequeueEPvj` | `asm/ZN26IOSkywalkTxSubmissionQueue14requestDequeueEPvj.asm.txt` |
| `IOSkywalkTxSubmissionQueue` | `0xffffff80029a2a40` | 20 | `__ZN26IOSkywalkTxSubmissionQueue16sendNotificationEj` | `asm/ZN26IOSkywalkTxSubmissionQueue16sendNotificationEj.asm.txt` |
| `IOSkywalkTxSubmissionQueue` | `0xffffff80029a2a6e` | 154 | `__ZN26IOSkywalkTxSubmissionQueue16packetSubmissionEPyPjS1_` | `asm/ZN26IOSkywalkTxSubmissionQueue16packetSubmissionEPyPjS1_.asm.txt` |
| `IOSkywalkTxSubmissionQueue` | `0xffffff80029a2cac` | 139 | `__ZN26IOSkywalkTxSubmissionQueue16packetSubmissionEb` | `asm/ZN26IOSkywalkTxSubmissionQueue16packetSubmissionEb.asm.txt` |
| `IOSkywalkTxSubmissionQueue` | `0xffffff80029a2eb2` | 50 | `__ZN26IOSkywalkTxSubmissionQueue11synchronizeEj.cold.1` | `asm/ZN26IOSkywalkTxSubmissionQueue11synchronizeEj.cold.1.asm.txt` |
| `IOSkywalkTxSubmissionQueue` | `0xffffff80029a2f59` | 40 | `__ZN26IOSkywalkTxSubmissionQueue12purgePacketsEv.cold.1` | `asm/ZN26IOSkywalkTxSubmissionQueue12purgePacketsEv.cold.1.asm.txt` |
| `IOSkywalkTxCompletionQueue` | `0xffffff8002989c20` | 15 | `__ZN26IOSkywalkTxCompletionQueue9MetaClassC1Ev` | `asm/ZN26IOSkywalkTxCompletionQueue9MetaClassC1Ev.asm.txt` |
| `IOSkywalkTxCompletionQueue` | `0xffffff8002989c52` | 4 | `__ZN26IOSkywalkTxCompletionQueue9MetaClassD1Ev` | `asm/ZN26IOSkywalkTxCompletionQueue9MetaClassD1Ev.asm.txt` |
| `IOSkywalkTxCompletionQueue` | `0xffffff8002989c5c` | 13 | `__ZN26IOSkywalkTxCompletionQueueC2EPK11OSMetaClass` | `asm/ZN26IOSkywalkTxCompletionQueueC2EPK11OSMetaClass.asm.txt` |
| `IOSkywalkTxCompletionQueue` | `0xffffff8002989c7c` | 13 | `__ZN26IOSkywalkTxCompletionQueueC1EPK11OSMetaClass` | `asm/ZN26IOSkywalkTxCompletionQueueC1EPK11OSMetaClass.asm.txt` |
| `IOSkywalkTxCompletionQueue` | `0xffffff8002989c9c` | 4 | `__ZN26IOSkywalkTxCompletionQueueD2Ev` | `asm/ZN26IOSkywalkTxCompletionQueueD2Ev.asm.txt` |
| `IOSkywalkTxCompletionQueue` | `0xffffff8002989ca6` | 4 | `__ZN26IOSkywalkTxCompletionQueueD1Ev` | `asm/ZN26IOSkywalkTxCompletionQueueD1Ev.asm.txt` |
| `IOSkywalkTxCompletionQueue` | `0xffffff8002989cb0` | 13 | `__ZN26IOSkywalkTxCompletionQueueD0Ev` | `asm/ZN26IOSkywalkTxCompletionQueueD0Ev.asm.txt` |
| `IOSkywalkTxCompletionQueue` | `0xffffff8002989cd8` | 8 | `__ZN26IOSkywalkTxCompletionQueuedlEPvm` | `asm/ZN26IOSkywalkTxCompletionQueuedlEPvm.asm.txt` |
| `IOSkywalkTxCompletionQueue` | `0xffffff8002989cf0` | 6 | `__ZNK26IOSkywalkTxCompletionQueue12getMetaClassEv` | `asm/ZNK26IOSkywalkTxCompletionQueue12getMetaClassEv.asm.txt` |
| `IOSkywalkTxCompletionQueue` | `0xffffff8002989cfe` | 15 | `__ZN26IOSkywalkTxCompletionQueue9MetaClassC2Ev` | `asm/ZN26IOSkywalkTxCompletionQueue9MetaClassC2Ev.asm.txt` |
| `IOSkywalkTxCompletionQueue` | `0xffffff8002989d30` | 22 | `__ZNK26IOSkywalkTxCompletionQueue9MetaClass5allocEv` | `asm/ZNK26IOSkywalkTxCompletionQueue9MetaClass5allocEv.asm.txt` |
| `IOSkywalkTxCompletionQueue` | `0xffffff8002989d78` | 6 | `__ZN26IOSkywalkTxCompletionQueuenwEm` | `asm/ZN26IOSkywalkTxCompletionQueuenwEm.asm.txt` |
| `IOSkywalkTxCompletionQueue` | `0xffffff8002989d8c` | 16 | `__ZN26IOSkywalkTxCompletionQueueC1Ev` | `asm/ZN26IOSkywalkTxCompletionQueueC1Ev.asm.txt` |
| `IOSkywalkTxCompletionQueue` | `0xffffff8002989dbc` | 16 | `__ZN26IOSkywalkTxCompletionQueueC2Ev` | `asm/ZN26IOSkywalkTxCompletionQueueC2Ev.asm.txt` |
| `IOSkywalkTxCompletionQueue` | `0xffffff8002989dec` | 54 | `__ZN26IOSkywalkTxCompletionQueue8withPoolEP25IOSkywalkPacketBufferPooljjP8OSObjectPFjS3_PS_PP15IOSkywalkPacketjPvES8_j` | `asm/ZN26IOSkywalkTxCompletionQueue8withPoolEP25IOSkywalkPacketBufferPooljjP8OSObjectPFjS3_PS_PP15IOSkywalkPacketjPvES8_j.asm.txt` |
| `IOSkywalkTxCompletionQueue` | `0xffffff8002989e96` | 57 | `__ZN26IOSkywalkTxCompletionQueue12initWithPoolEP25IOSkywalkPacketBufferPooljjP8OSObjectPFjS3_PS_PP15IOSkywalkPacketjPvES8_j` | `asm/ZN26IOSkywalkTxCompletionQueue12initWithPoolEP25IOSkywalkPacketBufferPooljjP8OSObjectPFjS3_PS_PP15IOSkywalkPacketjPvES8_j.asm.txt` |
| `IOSkywalkTxCompletionQueue` | `0xffffff8002989f4e` | 26 | `__ZN26IOSkywalkTxCompletionQueue4freeEv` | `asm/ZN26IOSkywalkTxCompletionQueue4freeEv.asm.txt` |
| `IOSkywalkTxCompletionQueue` | `0xffffff8002989fc2` | 5 | `__ZN26IOSkywalkTxCompletionQueue20getEffectiveCapacityEj` | `asm/ZN26IOSkywalkTxCompletionQueue20getEffectiveCapacityEj.asm.txt` |
| `IOSkywalkTxCompletionQueue` | `0xffffff8002989fca` | 14 | `__ZN26IOSkywalkTxCompletionQueue6enableEv` | `asm/ZN26IOSkywalkTxCompletionQueue6enableEv.asm.txt` |
| `IOSkywalkTxCompletionQueue` | `0xffffff8002989ff6` | 25 | `__ZN26IOSkywalkTxCompletionQueue7disableEv` | `asm/ZN26IOSkywalkTxCompletionQueue7disableEv.asm.txt` |
| `IOSkywalkTxCompletionQueue` | `0xffffff800298a03c` | 84 | `__ZN26IOSkywalkTxCompletionQueue15completePacketsEPP15IOSkywalkPacketj` | `asm/ZN26IOSkywalkTxCompletionQueue15completePacketsEPP15IOSkywalkPacketj.asm.txt` |
| `IOSkywalkTxCompletionQueue` | `0xffffff800298a14e` | 5 | `__ZNK26IOSkywalkTxCompletionQueue14getPacketCountEv` | `asm/ZNK26IOSkywalkTxCompletionQueue14getPacketCountEv.asm.txt` |
| `IOSkywalkTxCompletionQueue` | `0xffffff800298a156` | 25 | `__ZN26IOSkywalkTxCompletionQueue15setPacketPollerEP21IOSkywalkPacketPoller` | `asm/ZN26IOSkywalkTxCompletionQueue15setPacketPollerEP21IOSkywalkPacketPoller.asm.txt` |
| `IOSkywalkTxCompletionQueue` | `0xffffff800298a19e` | 33 | `__ZN26IOSkywalkTxCompletionQueue10initializeEPv` | `asm/ZN26IOSkywalkTxCompletionQueue10initializeEPv.asm.txt` |
| `IOSkywalkTxCompletionQueue` | `0xffffff800298a20c` | 30 | `__ZN26IOSkywalkTxCompletionQueue8finalizeEv` | `asm/ZN26IOSkywalkTxCompletionQueue8finalizeEv.asm.txt` |
| `IOSkywalkTxCompletionQueue` | `0xffffff800298a276` | 39 | `__ZN26IOSkywalkTxCompletionQueue14performCommandEjPvm` | `asm/ZN26IOSkywalkTxCompletionQueue14performCommandEjPvm.asm.txt` |
| `IOSkywalkTxCompletionQueue` | `0xffffff800298a2fe` | 84 | `__ZN26IOSkywalkTxCompletionQueue12addReportersEP9IOServiceP5OSSet` | `asm/ZN26IOSkywalkTxCompletionQueue12addReportersEP9IOServiceP5OSSet.asm.txt` |
| `IOSkywalkTxCompletionQueue` | `0xffffff800298a43c` | 61 | `__ZN26IOSkywalkTxCompletionQueue21getReportChannelValueEy` | `asm/ZN26IOSkywalkTxCompletionQueue21getReportChannelValueEy.asm.txt` |
| `IOSkywalkTxCompletionQueue` | `0xffffff800298a510` | 7 | `__ZN26IOSkywalkTxCompletionQueue36_RESERVEDIOSkywalkTxCompletionQueue0Ev` | `asm/ZN26IOSkywalkTxCompletionQueue36_RESERVEDIOSkywalkTxCompletionQueue0Ev.asm.txt` |
| `IOSkywalkTxCompletionQueue` | `0xffffff800298a524` | 6 | `__ZN26IOSkywalkTxCompletionQueue36_RESERVEDIOSkywalkTxCompletionQueue1Ev` | `asm/ZN26IOSkywalkTxCompletionQueue36_RESERVEDIOSkywalkTxCompletionQueue1Ev.asm.txt` |
| `IOSkywalkTxCompletionQueue` | `0xffffff800298a53a` | 6 | `__ZN26IOSkywalkTxCompletionQueue36_RESERVEDIOSkywalkTxCompletionQueue2Ev` | `asm/ZN26IOSkywalkTxCompletionQueue36_RESERVEDIOSkywalkTxCompletionQueue2Ev.asm.txt` |
| `IOSkywalkTxCompletionQueue` | `0xffffff800298a550` | 6 | `__ZN26IOSkywalkTxCompletionQueue36_RESERVEDIOSkywalkTxCompletionQueue3Ev` | `asm/ZN26IOSkywalkTxCompletionQueue36_RESERVEDIOSkywalkTxCompletionQueue3Ev.asm.txt` |
| `IOSkywalkTxCompletionQueue` | `0xffffff800298a566` | 6 | `__ZN26IOSkywalkTxCompletionQueue36_RESERVEDIOSkywalkTxCompletionQueue4Ev` | `asm/ZN26IOSkywalkTxCompletionQueue36_RESERVEDIOSkywalkTxCompletionQueue4Ev.asm.txt` |
| `IOSkywalkTxCompletionQueue` | `0xffffff800298a57c` | 6 | `__ZN26IOSkywalkTxCompletionQueue36_RESERVEDIOSkywalkTxCompletionQueue5Ev` | `asm/ZN26IOSkywalkTxCompletionQueue36_RESERVEDIOSkywalkTxCompletionQueue5Ev.asm.txt` |
| `IOSkywalkTxCompletionQueue` | `0xffffff800298a592` | 6 | `__ZN26IOSkywalkTxCompletionQueue36_RESERVEDIOSkywalkTxCompletionQueue6Ev` | `asm/ZN26IOSkywalkTxCompletionQueue36_RESERVEDIOSkywalkTxCompletionQueue6Ev.asm.txt` |
| `IOSkywalkTxCompletionQueue` | `0xffffff800298a5a8` | 6 | `__ZN26IOSkywalkTxCompletionQueue36_RESERVEDIOSkywalkTxCompletionQueue7Ev` | `asm/ZN26IOSkywalkTxCompletionQueue36_RESERVEDIOSkywalkTxCompletionQueue7Ev.asm.txt` |
| `IOSkywalkTxCompletionQueue` | `0xffffff800298a5be` | 6 | `__ZN26IOSkywalkTxCompletionQueue36_RESERVEDIOSkywalkTxCompletionQueue8Ev` | `asm/ZN26IOSkywalkTxCompletionQueue36_RESERVEDIOSkywalkTxCompletionQueue8Ev.asm.txt` |
| `IOSkywalkTxCompletionQueue` | `0xffffff800298a5d4` | 6 | `__ZN26IOSkywalkTxCompletionQueue36_RESERVEDIOSkywalkTxCompletionQueue9Ev` | `asm/ZN26IOSkywalkTxCompletionQueue36_RESERVEDIOSkywalkTxCompletionQueue9Ev.asm.txt` |
| `IOSkywalkTxCompletionQueue` | `0xffffff800298a5ea` | 6 | `__ZN26IOSkywalkTxCompletionQueue37_RESERVEDIOSkywalkTxCompletionQueue10Ev` | `asm/ZN26IOSkywalkTxCompletionQueue37_RESERVEDIOSkywalkTxCompletionQueue10Ev.asm.txt` |
| `IOSkywalkTxCompletionQueue` | `0xffffff800298a600` | 4 | `__ZN26IOSkywalkTxCompletionQueue9MetaClassD0Ev` | `asm/ZN26IOSkywalkTxCompletionQueue9MetaClassD0Ev.asm.txt` |
| `IOSkywalkTxCompletionQueue` | `0xffffff80029a39be` | 16 | `__ZN26IOSkywalkTxCompletionQueue12checkForWorkEv` | `asm/ZN26IOSkywalkTxCompletionQueue12checkForWorkEv.asm.txt` |
| `IOSkywalkTxCompletionQueue` | `0xffffff80029a39f8` | 37 | `__ZN26IOSkywalkTxCompletionQueue25enqueueAndCompletePacketsEPv` | `asm/ZN26IOSkywalkTxCompletionQueue25enqueueAndCompletePacketsEPv.asm.txt` |
| `IOSkywalkTxCompletionQueue` | `0xffffff80029a3a6e` | 44 | `__ZN26IOSkywalkTxCompletionQueue14requestEnqueueEPvj` | `asm/ZN26IOSkywalkTxCompletionQueue14requestEnqueueEPvj.asm.txt` |
| `IOSkywalkTxCompletionQueue` | `0xffffff80029a3afc` | 55 | `__ZN26IOSkywalkTxCompletionQueue14enqueuePacketsEPKP15IOSkywalkPacketjj` | `asm/ZN26IOSkywalkTxCompletionQueue14enqueuePacketsEPKP15IOSkywalkPacketjj.asm.txt` |
| `IOSkywalkTxCompletionQueue` | `0xffffff80029a3bb4` | 114 | `__ZN26IOSkywalkTxCompletionQueue14enqueuePacketsEP15IOSkywalkPacketjj` | `asm/ZN26IOSkywalkTxCompletionQueue14enqueuePacketsEP15IOSkywalkPacketjj.asm.txt` |
| `IOSkywalkInterface` | `0xffffff8002973c72` | 44 | `__ZN18IOSkywalkInterface4initEP12OSDictionary` | `asm/ZN18IOSkywalkInterface4initEP12OSDictionary.asm.txt` |
| `IOSkywalkInterface` | `0xffffff8002973d28` | 33 | `__ZN18IOSkywalkInterface4freeEv` | `asm/ZN18IOSkywalkInterface4freeEv.asm.txt` |
| `IOSkywalkInterface` | `0xffffff8002973db0` | 32 | `__ZN18IOSkywalkInterface29deregisterInterfaceWithQueuesEv` | `asm/ZN18IOSkywalkInterface29deregisterInterfaceWithQueuesEv.asm.txt` |
| `IOSkywalkInterface` | `0xffffff8002973e1c` | 23 | `__ZN18IOSkywalkInterface10handleOpenEP9IOServicejPv` | `asm/ZN18IOSkywalkInterface10handleOpenEP9IOServicejPv.asm.txt` |
| `IOSkywalkInterface` | `0xffffff8002973e68` | 21 | `__ZN18IOSkywalkInterface11handleCloseEP9IOServicej` | `asm/ZN18IOSkywalkInterface11handleCloseEP9IOServicej.asm.txt` |
| `IOSkywalkInterface` | `0xffffff8002973eb0` | 30 | `__ZNK18IOSkywalkInterface12handleIsOpenEPK9IOService` | `asm/ZNK18IOSkywalkInterface12handleIsOpenEPK9IOService.asm.txt` |
| `IOSkywalkInterface` | `0xffffff8002973f20` | 76 | `__ZN18IOSkywalkInterface27registerInterfaceWithQueuesEPP20IOSkywalkPacketQueuejP25IOSkywalkPacketBufferPoolS4_j` | `asm/ZN18IOSkywalkInterface27registerInterfaceWithQueuesEPP20IOSkywalkPacketQueuejP25IOSkywalkPacketBufferPoolS4_j.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff8002981a64` | 40 | `__ZN25IOSkywalkNetworkInterface4initEP12OSDictionary` | `asm/ZN25IOSkywalkNetworkInterface4initEP12OSDictionary.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff8002981b1e` | 17 | `__ZN25IOSkywalkNetworkInterface4stopEP9IOService` | `asm/ZN25IOSkywalkNetworkInterface4stopEP9IOService.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff8002981b54` | 85 | `__ZN25IOSkywalkNetworkInterface26deregisterNetworkInterfaceEj` | `asm/ZN25IOSkywalkNetworkInterface26deregisterNetworkInterfaceEj.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff8002981ca6` | 48 | `__ZN25IOSkywalkNetworkInterface4freeEv` | `asm/ZN25IOSkywalkNetworkInterface4freeEv.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff8002981d7e` | 81 | `__ZN25IOSkywalkNetworkInterface24registerNetworkInterfaceEPKNS_16RegistrationInfoEPP20IOSkywalkPacketQueuejP25IOSkywalkPacketBufferPoolS7_j` | `asm/ZN25IOSkywalkNetworkInterface24registerNetworkInterfaceEPKNS_16RegistrationInfoEPP20IOSkywalkPacketQueuejP25IOSkywalkPacketBufferPoolS7_j.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff8002981eac` | 143 | `__ZN25IOSkywalkNetworkInterface24registerNetworkInterfaceEPKNS_16RegistrationInfoEP20IOSkywalkLogicalLinkP25IOSkywalkPacketBufferPoolS6_j` | `asm/ZN25IOSkywalkNetworkInterface24registerNetworkInterfaceEPKNS_16RegistrationInfoEP20IOSkywalkLogicalLinkP25IOSkywalkPacketBufferPoolS6_j.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff80029820d8` | 4 | `__ZN25IOSkywalkNetworkInterface39registerNetworkInterfaceWithLogicalLinkEPKNS_16RegistrationInfoEP20IOSkywalkLogicalLinkP25IOSkywalkPacketBufferPoolS6_j` | `asm/ZN25IOSkywalkNetworkInterface39registerNetworkInterfaceWithLogicalLinkEPKNS_16RegistrationInfoEP20IOSkywalkLogicalLinkP25IOSkywalkPacketBufferPoolS6_j.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff800298214e` | 4 | `__ZN25IOSkywalkNetworkInterface21deregisterLogicalLinkEv` | `asm/ZN25IOSkywalkNetworkInterface21deregisterLogicalLinkEv.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff80029823a0` | 41 | `__ZNK25IOSkywalkNetworkInterface25calculateRingSizeForQueueEPK20IOSkywalkPacketQueuePj` | `asm/ZNK25IOSkywalkNetworkInterface25calculateRingSizeForQueueEPK20IOSkywalkPacketQueuePj.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff8002982b86` | 15 | `__ZN25IOSkywalkNetworkInterface6enableEj` | `asm/ZN25IOSkywalkNetworkInterface6enableEj.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff8002982bae` | 26 | `__ZN25IOSkywalkNetworkInterface7disableEj` | `asm/ZN25IOSkywalkNetworkInterface7disableEj.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff8002982cb0` | 5 | `__ZN25IOSkywalkNetworkInterface9isEnabledEv` | `asm/ZN25IOSkywalkNetworkInterface9isEnabledEv.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff8002982cbc` | 5 | `__ZN25IOSkywalkNetworkInterface18setInterfaceEnableEb` | `asm/ZN25IOSkywalkNetworkInterface18setInterfaceEnableEb.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff8002982f16` | 6 | `__ZN25IOSkywalkNetworkInterface23interfaceAdvisoryEnableEb` | `asm/ZN25IOSkywalkNetworkInterface23interfaceAdvisoryEnableEb.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff8002982f7a` | 7 | `__ZN25IOSkywalkNetworkInterface17enableNetworkWakeEj` | `asm/ZN25IOSkywalkNetworkInterface17enableNetworkWakeEj.asm.txt` |
| `IOSkywalkNetworkInterface` | `0xffffff800298317e` | 13 | `__ZN25IOSkywalkNetworkInterface15getInitialMediaEv` | `asm/ZN25IOSkywalkNetworkInterface15getInitialMediaEv.asm.txt` |
| `IOSkywalkEthernetInterface` | `0xffffff8002987e14` | 20 | `__ZN26IOSkywalkEthernetInterface4initEP12OSDictionary` | `asm/ZN26IOSkywalkEthernetInterface4initEP12OSDictionary.asm.txt` |
| `IOSkywalkEthernetInterface` | `0xffffff8002987e52` | 32 | `__ZN26IOSkywalkEthernetInterface4freeEv` | `asm/ZN26IOSkywalkEthernetInterface4freeEv.asm.txt` |
| `IOSkywalkEthernetInterface` | `0xffffff8002987ed6` | 71 | `__ZN26IOSkywalkEthernetInterface20initRegistrationInfoEPNS_16RegistrationInfoEjm` | `asm/ZN26IOSkywalkEthernetInterface20initRegistrationInfoEPNS_16RegistrationInfoEjm.asm.txt` |
| `IOSkywalkEthernetInterface` | `0xffffff8002988078` | 40 | `__ZN26IOSkywalkEthernetInterface25registerEthernetInterfaceEPKNS_16RegistrationInfoEPP20IOSkywalkPacketQueuejP25IOSkywalkPacketBufferPoolS7_j` | `asm/ZN26IOSkywalkEthernetInterface25registerEthernetInterfaceEPKNS_16RegistrationInfoEPP20IOSkywalkPacketQueuejP25IOSkywalkPacketBufferPoolS7_j.asm.txt` |
| `IOSkywalkEthernetInterface` | `0xffffff80029880e8` | 28 | `__ZN26IOSkywalkEthernetInterface27deregisterEthernetInterfaceEj` | `asm/ZN26IOSkywalkEthernetInterface27deregisterEthernetInterfaceEj.asm.txt` |
| `IOSkywalkEthernetInterface` | `0xffffff800298813a` | 44 | `__ZN26IOSkywalkEthernetInterface25registerEthernetInterfaceEPKNS_16RegistrationInfoEP20IOSkywalkLogicalLinkP25IOSkywalkPacketBufferPoolS6_j` | `asm/ZN26IOSkywalkEthernetInterface25registerEthernetInterfaceEPKNS_16RegistrationInfoEP20IOSkywalkLogicalLinkP25IOSkywalkPacketBufferPoolS6_j.asm.txt` |
| `IOSkywalkEthernetInterface` | `0xffffff80029881be` | 84 | `__ZN26IOSkywalkEthernetInterface26initBSDInterfaceParametersEP18ifnet_init_eparamsPP11sockaddr_dl` | `asm/ZN26IOSkywalkEthernetInterface26initBSDInterfaceParametersEP18ifnet_init_eparamsPP11sockaddr_dl.asm.txt` |
| `IOSkywalkEthernetInterface` | `0xffffff80029883ba` | 10 | `__ZN26IOSkywalkEthernetInterface15getInitialMediaEv` | `asm/ZN26IOSkywalkEthernetInterface15getInitialMediaEv.asm.txt` |
| `IOSkywalkEthernetInterface` | `0xffffff8002988af8` | 42 | `__ZN26IOSkywalkEthernetInterface6enableEj` | `asm/ZN26IOSkywalkEthernetInterface6enableEj.asm.txt` |
| `IOSkywalkEthernetInterface` | `0xffffff8002988b7e` | 6 | `__ZN26IOSkywalkEthernetInterface24setPromiscuousModeEnableEbj` | `asm/ZN26IOSkywalkEthernetInterface24setPromiscuousModeEnableEbj.asm.txt` |
| `IOSkywalkEthernetInterface` | `0xffffff8002988c68` | 6 | `__ZN26IOSkywalkEthernetInterface25setAllMulticastModeEnableEb` | `asm/ZN26IOSkywalkEthernetInterface25setAllMulticastModeEnableEb.asm.txt` |
| `IOSkywalkEthernetInterface` | `0xffffff8002988d8e` | 57 | `__ZN26IOSkywalkEthernetInterface12initNicProxyEm` | `asm/ZN26IOSkywalkEthernetInterface12initNicProxyEm.asm.txt` |
| `IOSkywalkEthernetInterface` | `0xffffff8002988e5e` | 28 | `__ZN26IOSkywalkEthernetInterface12freeNicProxyEv` | `asm/ZN26IOSkywalkEthernetInterface12freeNicProxyEv.asm.txt` |
| `IOSkywalkEthernetInterface` | `0xffffff8002989726` | 49 | `__ZN26IOSkywalkEthernetInterface17enableNetworkWakeEj` | `asm/ZN26IOSkywalkEthernetInterface17enableNetworkWakeEj.asm.txt` |

### Source evidence snippets

**RTW88WCLSkywalkQueues.cpp:31-39**

```cpp
   31:     _allocated = false;
   32:     return true;
   33: }
   34: 
   35: IOReturn RTW88WCLSkywalkQueues::createQueues()
   36: {
   37:     if (_allocated)
   38:         return kIOReturnSuccess;
   39:     if (_txPool || _rxPool || _txSubmission || _txCompletion ||
```

**RTW88WCLSkywalkQueues.cpp:63-71**

```cpp
   63:     if (!_rxPool)
   64:         goto no_memory;
   65: 
   66:     /* These queue objects are deliberately not added to an IOWorkLoop and
   67:      * are not passed to registerEthernetInterface() yet. Skywalk owns their
   68:      * scheduling and packet lifetime only after a complete RegistrationInfo
   69:      * + ring setup transaction, which is a later stage. */
   70:     _txSubmission = IOSkywalkTxSubmissionQueue::withPool(
   71:         _txPool, kQueueCapacity, 0, this,
```

**RTW88WCLSkywalkQueues.cpp:91-132**

```cpp
   91:     if (!_rxCompletion)
   92:         goto no_memory;
   93: 
   94:     _allocated = true;
   95:     IOLog("rtl88wifi-wcl: allocated Skywalk pools and four queue objects (not registered)\n");
   96:     return kIOReturnSuccess;
   97: 
   98: no_memory:
   99:     destroyQueues();
  100:     return kIOReturnNoMemory;
  101: }
  102: 
  103: void RTW88WCLSkywalkQueues::destroyQueues()
  104: {
  105:     /* Release queues before their pools: queue implementations retain and
  106:      * reference their associated pool for packet and buffer accounting. */
  107:     if (_rxCompletion) {
  108:         _rxCompletion->release();
  109:         _rxCompletion = nullptr;
  110:     }
  111:     if (_rxSubmission) {
  112:         _rxSubmission->release();
  113:         _rxSubmission = nullptr;
  114:     }
  115:     if (_txCompletion) {
  116:         _txCompletion->release();
  117:         _txCompletion = nullptr;
  118:     }
  119:     if (_txSubmission) {
  120:         _txSubmission->release();
  121:         _txSubmission = nullptr;
  122:     }
  123:     if (_rxPool) {
  124:         _rxPool->release();
  125:         _rxPool = nullptr;
  126:     }
  127:     if (_txPool) {
  128:         _txPool->release();
  129:         _txPool = nullptr;
  130:     }
  131:     _allocated = false;
  132: }
```

**RTW88WCLSkywalkQueues.cpp:188-194**

```cpp
  188: }
  189: 
  190: void RTW88WCLSkywalkQueues::free()
  191: {
  192:     destroyQueues();
  193:     super::free();
  194: }
```

**RTW88WCLSkywalkRxAdapter.cpp:17-25**

```cpp
   17: bool RTW88WCLSkywalkRxAdapter::init(OSObject *owner, IOWorkLoop *workLoop,
   18:                                     IOSkywalkPacketBufferPool *rxPool,
   19:                                     FrameSink sink, void *context)
   20: {
   21:     if (!owner || !workLoop || !rxPool || _workLoop || _rxPool || _registered)
   22:         return false;
   23:     if (!super::init(owner, nullptr))
   24:         return false;
   25: 
```

**RTW88WCLSkywalkRxAdapter.cpp:35-50**

```cpp
   35:     __atomic_store_n(&_prepared, 0U, __ATOMIC_RELAXED);
   36: 
   37:     const IOReturn status = workLoop->addEventSource(this);
   38:     if (status != kIOReturnSuccess) {
   39:         _rxPool->release();
   40:         _rxPool = nullptr;
   41:         _workLoop = nullptr;
   42:         _sink = nullptr;
   43:         _sinkContext = nullptr;
   44:         return false;
   45:     }
   46:     _registered = true;
   47:     return true;
   48: }
   49: 
   50: bool RTW88WCLSkywalkRxAdapter::isValidMbuf(mbuf_t packet)
```

**RTW88WCLSkywalkRxAdapter.cpp:179-187**

```cpp
  179:             if (copyMbufToSkywalkPacket(_rxPool, source, &packet)) {
  180:                 __atomic_add_fetch(&_prepared, 1U, __ATOMIC_RELAXED);
  181:                 /* A true return means the sink has accepted ownership. The
  182:                  * current controller sink returns false because the RX
  183:                  * completion queue is still unregistered. */
  184:                 const bool accepted = _sink && _sink(packet, _sinkContext);
  185:                 if (!accepted) {
  186:                     (void)_rxPool->deallocatePacket(packet);
  187:                     __atomic_add_fetch(&_dropped, 1U, __ATOMIC_RELAXED);
```

**RTW88WCLSkywalkRxAdapter.cpp:208-223**

```cpp
  208:     }
  209:     return false;
  210: }
  211: 
  212: void RTW88WCLSkywalkRxAdapter::stop()
  213: {
  214:     __atomic_store_n(&_stopping, 1U, __ATOMIC_RELEASE);
  215:     if (_registered && _workLoop) {
  216:         /* Synchronous removal serializes against checkForWork(). The owner
  217:          * must stop/quiesce RTW88 RX producers before invoking stop(). */
  218:         _workLoop->removeEventSource(this);
  219:         _registered = false;
  220:     }
  221: 
  222:     mbuf_t packet = nullptr;
  223:     while (_frames.pop(&packet)) {
```

**RTW88WCLSkywalkRxAdapter.cpp:228-243**

```cpp
  228:     _sink = nullptr;
  229:     _sinkContext = nullptr;
  230:     _workLoop = nullptr;
  231:     if (_rxPool) {
  232:         _rxPool->release();
  233:         _rxPool = nullptr;
  234:     }
  235: }
  236: 
  237: void RTW88WCLSkywalkRxAdapter::free()
  238: {
  239:     stop();
  240:     super::free();
  241: }
  242: 
  243: uint32_t RTW88WCLSkywalkRxAdapter::droppedFrames() const
```

**RTW88WCLSkywalkTxAdapter.cpp:46-56**

```cpp
   46:     IOSkywalkPacketBufferPool *pool = _txPool;
   47:     _radio = nullptr;
   48:     _txPool = nullptr;
   49:     if (pool)
   50:         pool->release();
   51:     if (radio)
   52:         radio->release();
   53:     return kIOReturnSuccess;
   54: }
   55: 
   56: mbuf_t RTW88WCLSkywalkTxAdapter::copyPacketToMbuf(
```

**RTW88WCLSkywalkTxAdapter.cpp:90-98**

```cpp
   90: 
   91:     packet->retain();
   92:     TicketPool::Ticket *ticket = _tickets.reserve(packet);
   93:     if (!ticket) {
   94:         packet->release();
   95:         mbuf_freem(mbuf);
   96:         return kIOReturnBusy;
   97:     }
   98: 
```

**RTW88WCLSkywalkTxAdapter.cpp:102-110**

```cpp
  102:     const UInt32 backendResult = _radio->outputPacketWithCompletion(
  103:         mbuf, &RTW88WCLSkywalkTxAdapter::backendCompletion, this, ticket);
  104: 
  105:     /* outputPacketWithCompletion consumes the mbuf and reports exactly one
  106:      * terminal callback, including synchronous drops. Once the ticket has
  107:      * been reserved, adapter acceptance is successful; the actual transmitted
  108:      * vs dropped result is delivered later through the completion sink. */
  109:     (void)backendResult;
  110:     return kIOReturnSuccess;
```

**RTW88WCLSkywalkTxAdapter.cpp:147-159**

```cpp
  147:             sink(packet, transmitted, context);
  148: 
  149:         TicketPool::finish(ticket);
  150:         if (packet)
  151:             packet->release();
  152:         release();
  153:         ++drained;
  154:     }
  155:     release();
  156:     return drained;
  157: }
  158: 
  159: bool RTW88WCLSkywalkTxAdapter::hasOutstandingCompletions() const
```

**RTW88WCLController.cpp:55-63**

```cpp
   55:         return false;
   56:     _baseStarted = true;
   57: 
   58:     /* Stage A: the controller workloop must exist before acquiring a PCI
   59:      * backend or registering any interrupt source. */
   60:     if (!createWorkLoop()) {
   61:         IOLog("rtl88wifi-wcl: controller workloop creation failed\n");
   62:         goto fail;
   63:     }
```

**RTW88WCLController.cpp:76-84**

```cpp
   76:             IOLog("rtl88wifi-wcl: PCI backend allocation failed\n");
   77:             goto fail;
   78:         }
   79:         if (!_pciBackend->init()) {
   80:             _pciBackend->release();
   81:             _pciBackend = nullptr;
   82:             IOLog("rtl88wifi-wcl: PCI backend initialization failed\n");
   83:             goto fail;
   84:         }
```

**RTW88WCLController.cpp:104-112**

```cpp
  104:             goto fail;
  105:         }
  106:         radio->setEventDelegate(this);
  107:         const IOReturn bindStatus = bindRadioBackend(radio);
  108:         radio->release();
  109:         if (bindStatus != kIOReturnSuccess) {
  110:             IOLog("rtl88wifi-wcl: RTW88 state-machine bind failed: 0x%08x\n",
  111:                   bindStatus);
  112:             goto fail;
```

**RTW88WCLController.cpp:114-134**

```cpp
  114:     }
  115: 
  116:     /* Stage D: reserve native Skywalk queue/pool objects while the PCI and
  117:      * RTW88 owners are still available for orderly unwind. These objects are
  118:      * intentionally not registered or scheduled until packet descriptor
  119:      * conversion and hardware completion correlation are implemented. */
  120:     _skywalkQueues = new RTW88WCLSkywalkQueues;
  121:     if (!_skywalkQueues || !_skywalkQueues->init()) {
  122:         if (_skywalkQueues) {
  123:             _skywalkQueues->release();
  124:             _skywalkQueues = nullptr;
  125:         }
  126:         IOLog("rtl88wifi-wcl: Skywalk queue owner allocation failed\n");
  127:         goto fail;
  128:     }
  129:     {
  130:         const IOReturn queueStatus = _skywalkQueues->createQueues();
  131:         if (queueStatus != kIOReturnSuccess) {
  132:             IOLog("rtl88wifi-wcl: Skywalk queue/pool allocation failed: 0x%08x\n",
  133:                   queueStatus);
  134:             goto fail;
```

**RTW88WCLController.cpp:142-150**

```cpp
  142:     if (!_rxAdapter || !_rxAdapter->init(
  143:             this, _workLoop, _skywalkQueues->rxPacketPool(),
  144:             &RTW88WCLController::stagedRxFrame, this)) {
  145:         if (_rxAdapter) {
  146:             _rxAdapter->release();
  147:             _rxAdapter = nullptr;
  148:         }
  149:         IOLog("rtl88wifi-wcl: RX packet adapter initialization failed\n");
  150:         goto fail;
```

**RTW88WCLController.cpp:159-186**

```cpp
  159:     IOLog("rtl88wifi-wcl: backend lifecycle staged; refusing publication until Skywalk datapath is ready\n");
  160:     goto fail;
  161: 
  162: fail:
  163:     releaseNativeResources();
  164:     if (_baseStarted) {
  165:         super::stop(provider);
  166:         _baseStarted = false;
  167:     }
  168:     return false;
  169: }
  170: 
  171: void RTW88WCLController::stop(IOService *provider)
  172: {
  173:     releaseNativeResources();
  174:     if (_baseStarted) {
  175:         super::stop(provider);
  176:         _baseStarted = false;
  177:     }
  178: }
  179: 
  180: void RTW88WCLController::releaseNativeResources()
  181: {
  182:     const IOReturn packetPathStatus = quiescePacketPath();
  183:     if (packetPathStatus != kIOReturnSuccess) {
  184:         IOLog("rtl88wifi-wcl: packet path quiesce deferred: 0x%08x\n",
  185:               packetPathStatus);
  186:         return; // Keep the radio, interface and PCI callbacks alive.
```

**RTW88WCLController.cpp:190-206**

```cpp
  190:      * disabling PCI interrupts. The staged path currently leaves
  191:      * _radioStarted false; preserve this ordering when native radio start is
  192:      * enabled after queue registration. */
  193:     if (_radio && _radioStarted) {
  194:         _radio->stop();
  195:         _radioStarted = false;
  196:     }
  197: 
  198:     /* Remove the RX workloop source only after the RTW88 producer is stopped.
  199:      * stop() waits out an active checkForWork() and releases all staged mbufs. */
  200:     if (_rxAdapter) {
  201:         _rxAdapter->stop();
  202:         _rxAdapter->release();
  203:         _rxAdapter = nullptr;
  204:     }
  205: 
  206:     /* The RX adapter transfers accepted native packets into the controller's
```

**RTW88WCLController.cpp:216-225**

```cpp
  216: 
  217:     /* Skywalk packet pools/queues are released only after both the mbuf staging
  218:      * adapter and the prepared-packet ownership ring have been drained. */
  219:     if (_skywalkQueues) {
  220:         _skywalkQueues->destroyQueues();
  221:         _skywalkQueues->release();
  222:         _skywalkQueues = nullptr;
  223:     }
  224: 
  225:     if (_pciBackend && _pciBackend->isRadioRunning()) {
```

**RTW88WCLController.cpp:241-260**

```cpp
  241:             IOLog("rtl88wifi-wcl: PCI backend close deferred: 0x%08x\n",
  242:                   closeStatus);
  243:             return;
  244:         }
  245:         _pciBackend->release();
  246:         _pciBackend = nullptr;
  247:     }
  248: }
  249: 
  250: void RTW88WCLController::free()
  251: {
  252:     releaseNativeResources();
  253:     if (_pciBackend)
  254:         IOLog("rtl88wifi-wcl: PCI backend retained because shutdown fence did not complete\n");
  255:     if (_workLoop) {
  256:         _workLoop->release();
  257:         _workLoop = nullptr;
  258:     }
  259:     super::free();
  260: }
```

**RTW88WCLController.cpp:403-411**

```cpp
  403:     IOLog("rtl88wifi-wcl: native mbuf packet handoff enabled\n");
  404:     return kIOReturnSuccess;
  405: }
  406: 
  407: IOReturn RTW88WCLController::quiescePacketPath()
  408: {
  409:     for (;;) {
  410:         uint32_t state = __atomic_load_n(&_packetPathState, __ATOMIC_ACQUIRE);
  411:         if (state == kPacketPathDisabled)
```

**RTW88WCLController.cpp:435-443**

```cpp
  435: 
  436:     IO80211SkywalkInterface *interface = _packetPathInterface;
  437:     _packetPathInterface = nullptr;
  438:     if (interface)
  439:         interface->release();
  440:     __atomic_store_n(&_packetPathState, kPacketPathDisabled, __ATOMIC_RELEASE);
  441:     return kIOReturnSuccess;
  442: }
  443: 
```

**RTW88WCLController.cpp:495-503**

```cpp
  495:         return;
  496:     }
  497: 
  498:     /* enqueueFrame consumes the mbuf on both success and failure. The native
  499:      * RX completion queue is not registered yet, so the workloop sink below
  500:      * deliberately drops frames after staging rather than exposing them. */
  501:     (void)_rxAdapter->enqueueFrame(packet);
  502:     leavePacketPath();
  503: }
```

**RTW88WCLController.cpp:518-526**

```cpp
  518: 
  519:         const IOReturn status = pool->deallocatePacket(packet);
  520:         if (status != kIOReturnSuccess) {
  521:             /* The radio and RX event source are already quiesced, and these
  522:              * queues were never registered. If a packet cannot be returned
  523:              * individually, dispose the pool's packet set as one teardown
  524:              * operation before its memory segments are released. */
  525:             IOLog("rtl88wifi-wcl: RX packet recycle returned 0x%08x; pool disposal required\n",
  526:                   status);
```

**RTW88WCLController.cpp:570-577**

```cpp
  570: 
  571: void RTW88WCLController::unbindRadioBackend()
  572: {
  573:     if (_radio) {
  574:         _radio->release();
  575:         _radio = nullptr;
  576:     }
  577: }
```

**RTW88WCLController.hpp:26-43**

```cpp
   26: 
   27: public:
   28:     bool init(OSDictionary *properties) override;
   29:     bool start(IOService *provider) override;
   30:     void stop(IOService *provider) override;
   31:     void free() override;
   32:     bool createWorkLoop() override;
   33:     IOWorkLoop *getWorkLoop() const override;
   34: 
   35:     /* Native Ethernet mbuf handoff seam. Skywalk queue callbacks must call these
   36:      * only after their packet rings are registered and the radio is started. */
   37:     UInt32 outputPacket(mbuf_t packet, void *param) override;
   38:     IOReturn activatePacketPath(IO80211SkywalkInterface *interface);
   39:     IOReturn quiescePacketPath();
   40: 
   41:     /* Required pure virtuals in the 24H32 IO80211Controller ABI. Until the
   42:      * native protocol + Skywalk datapath are attached, operations fail closed. */
   43:     bool isCommandProhibited(int command) override;
```

**RTW88WCLController.hpp:67-91**

```cpp
   67:     void unbindRadioBackend();
   68:     RTW88IEEE80211 *radioBackend() const { return _radio; }
   69:     RTW88WCLPCIBackend *pciBackend() const { return _pciBackend; }
   70: 
   71:     /* RTW88WCLPCIBackendClient: no native TX queue is registered yet. */
   72:     void rtw88WCLResumeTransmit() override;
   73: 
   74:     /* RTW88EventDelegate: events are deliberately not published until the
   75:      * Skywalk interface has completed registration. */
   76:     void rtw88Event(RTW88Event event, void *data) override;
   77: 
   78:     /* RTW88RxDelegate: receive mbufs enter a bounded workloop staging ring,
   79:      * then become pool-backed Skywalk packets. The sink still rejects them
   80:      * until the RX completion queue is registered and verified. */
   81:     mbuf_t allocateInputPacket(uint32_t length) override;
   82:     void injectRxFrame(mbuf_t packet) override;
   83:     IOWorkLoop *getRxWorkLoop() override;
   84:     void setLinkStatus(UInt32 status) override;
   85: 
   86: private:
   87:     void releaseNativeResources();
   88:     IOReturn recycleStagedRxPackets();
   89:     static bool stagedRxFrame(IOSkywalkPacket *preparedPacket, void *context);
   90: 
   91:     enum : uint32_t {
```

**RTW88WCLController.hpp:105-113**

```cpp
  105:     IO80211SkywalkInterface *_packetPathInterface = nullptr; // retained while active
  106:     volatile uint32_t _packetPathState = kPacketPathDisabled;
  107:     volatile uint32_t _packetPathInFlight = 0;
  108:     RTW88WCLPCIBackend *_pciBackend = nullptr; // retained
  109:     RTW88WCLSkywalkQueues *_skywalkQueues = nullptr; // retained, unregistered
  110:     RTW88WCLSkywalkRxAdapter *_rxAdapter = nullptr; // retained, workloop-bound
  111:     /* Accepted RX packets remain pool-owned here until a verified completion
  112:      * queue can consume them. This ring is bounded to the RX pool packet count. */
  113:     RTW88WCLMbufRing<IOSkywalkPacket *, kStagedRxPacketCapacity> _stagedRxPackets;
```

**RTW88WCLInfraInterface.cpp:184-199**

```cpp
  184:     RTW88WCLWorkQueue *queue = new RTW88WCLWorkQueue;
  185:     if (!queue)
  186:         return kIOReturnNoMemory;
  187:     if (!queue->init(this, workLoop, this)) {
  188:         queue->release();
  189:         return kIOReturnNoResources;
  190:     }
  191: 
  192:     IOReturn status = _bridge.attach(radio, queue);
  193:     if (status != kIOReturnSuccess) {
  194:         queue->stop();
  195:         queue->release();
  196:         return status;
  197:     }
  198:     _workQueue = queue;
  199:     _stopping = false;
```

**RTW88WCLInfraInterface.cpp:206-215**

```cpp
  206:     /* Quiesce the producer first, then remove the work source. The controller
  207:      * must stop the radio before destroying its backend object. */
  208:     _bridge.detach();
  209:     if (_workQueue) {
  210:         _workQueue->stop();
  211:         _workQueue->release();
  212:         _workQueue = nullptr;
  213:     }
  214:     _scanActive = false;
  215:     _activeScanGeneration = 0;
```

**RTW88WCLInfraInterface.cpp:270-294**

```cpp
  270:     }
  271:     return false;
  272: }
  273: 
  274: void RTW88WCLInfraInterface::stop(IOService *provider)
  275: {
  276:     clearRegistrationInfo();
  277:     detachRadio();
  278:     if (provider)
  279:         provider->setProperty("RTW88WCLInfraInterfaceStopped", kOSBooleanTrue);
  280:     super::stop(provider);
  281: }
  282: 
  283: IOReturn RTW88WCLInfraInterface::enable(unsigned int options)
  284: {
  285:     (void)options;
  286:     if (_stopping || !_bridge.isAttached() || !_controller)
  287:         return kIOReturnNotReady;
  288: 
  289:     /* Bring the RTW88 station path up first. Only then may the controller's
  290:      * standard mbuf TX hook admit packets for this registered interface. */
  291:     IOReturn status = _bridge.powerOn();
  292:     if (status != kIOReturnSuccess)
  293:         return status;
  294: 
```

**RTW88WCLInfraInterface.cpp:299-315**

```cpp
  299:     }
  300:     return kIOReturnSuccess;
  301: }
  302: 
  303: IOReturn RTW88WCLInfraInterface::disable(unsigned int options)
  304: {
  305:     (void)options;
  306:     if (!_bridge.isAttached() || !_controller)
  307:         return kIOReturnNotReady;
  308: 
  309:     /* Stop new mbuf submissions and wait for synchronous TX handoffs before
  310:      * asking RTW88 to power down. A busy path leaves the radio running. */
  311:     IOReturn status = _controller->quiescePacketPath();
  312:     if (status != kIOReturnSuccess)
  313:         return status;
  314:     return _bridge.powerOff();
  315: }
```

**RTW88WCLInfraInterface.cpp:565-573**

```cpp
  565:     filter.filterBSSID = !isZeroAddress(filter.bssid, sizeof(filter.bssid));
  566:     filter.filterChannels = request.channelCount != 0;
  567:     _scanFilter = filter;
  568:     _scanActive = true;
  569:     /* The bridge writes this generation before it enters the asynchronous
  570:      * backend, so a fast completion cannot race the interface's filter state. */
  571:     _activeScanGeneration = 0;
  572:     setScanningState(request.identifier, true, nullptr, 0);
  573: 
```

### Manual questions

- [ ] Which operation prevents new submissions before synchronization begins?
- [ ] Does synchronize wait for callback exit, queue drain, or both?
- [ ] Can callbacks race with queue/pool release?
- [ ] What exact order is required when shutdown must be retried?

**Review outcome:** `UNRESOLVED — do not enable this contract`

## Activation gate

**BLOCKED — do not register queues, accept packet ownership, start the radio or publish the Ethernet interface until every contract has been manually resolved and separately tested.**

No driver source is changed by Stage 18. This stage only packages exact Stage 17 disassembly and current driver source evidence for review.
